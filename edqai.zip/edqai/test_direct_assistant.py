"""
Test the pattern matching assistant directly
"""
import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from app.pattern_matching_assistant import PatternMatchingAssistant

assistant = PatternMatchingAssistant()
intent = assistant.extract_intent('create a rule for email field should not be null in Employee Management dataset')

print('Intent extracted:')
print(f'Action: {intent["action"]}')
print(f'Dataset: {intent["dataset_name"]}')
print(f'Field: {intent["field_name"]}')
print(f'Rule Type: {intent["rule_type"]}')
print(f'Severity: {intent["severity"]}')
print(f'Confidence: {intent["confidence"]}')

# Test just the rule type extraction
message = 'should not be null'
rule_type = assistant._extract_rule_type(message.lower())
print(f'\nRule type for "{message}": {rule_type}')
