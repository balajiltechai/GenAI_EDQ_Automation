#!/usr/bin/env python3
"""
Test dataset-specific rules API
"""

import requests

API_BASE_URL = 'http://localhost:5001/api'

def test_dataset_rules():
    """Test dataset-specific rules"""
    for dataset_id in [1, 2]:
        print(f"\n=== Testing Dataset {dataset_id} ===")
        
        response = requests.get(f"{API_BASE_URL}/datasets/{dataset_id}/quality-rules")
        if response.ok:
            data = response.json()
            print(f"Dataset Name: {data['dataset_name']}")
            print(f"Total Rules: {data['total_count']}")
            print(f"Active Rules: {data['summary']['active_rules']}")
            
            print("\nRules by Field:")
            for field_name, rules in data['rules_by_field'].items():
                print(f"  {field_name}: {len(rules)} rules")
                for rule in rules:
                    print(f"    - {rule['rule_description']} ({rule['rule_type']}, {rule['severity']})")
        else:
            print(f"Failed to get rules for dataset {dataset_id}: {response.status_code}")

if __name__ == "__main__":
    test_dataset_rules()
