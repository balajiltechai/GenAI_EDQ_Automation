#!/usr/bin/env python3
"""
Free AI Configuration Setup Script
"""

import os
from pathlib import Path

def setup_free_ai_config():
    """Setup Free AI configuration for the EDQ Assistant"""
    
    print("🤖 Free AI EDQ Assistant Configuration")
    print("=" * 50)
    
    # Check if .env file exists
    env_file = Path('.env')
    env_example = Path('.env.example')
    
    if not env_file.exists() and env_example.exists():
        print("📝 Creating .env file from template...")
        with open(env_example, 'r') as f:
            content = f.read()
        with open(env_file, 'w') as f:
            f.write(content)
        print("✅ Created .env file")
    
    print("\n🆓 Free AI Configuration Options:")
    print("1. Local Pattern Matching (No API key needed - Works offline)")
    print("2. Hugging Face API (Optional - Better AI responses)")
    
    choice = input("\nChoose option (1 or 2): ").strip()
    
    if choice == '2':
        print("\n🤗 Hugging Face API Setup:")
        print("1. Go to https://huggingface.co/")
        print("2. Create a free account")
        print("3. Go to Settings > Access Tokens")
        print("4. Create a new token")
        
        hf_token = input("\n🔑 Enter your Hugging Face API token (or press Enter to skip): ").strip()
        
        if hf_token:
            # Update .env file with HF token
            if env_file.exists():
                with open(env_file, 'r') as f:
                    lines = f.readlines()
                
                # Update or add HF token
                updated = False
                for i, line in enumerate(lines):
                    if line.startswith('HUGGINGFACE_API_TOKEN='):
                        lines[i] = f'HUGGINGFACE_API_TOKEN={hf_token}\n'
                        updated = True
                        break
                
                if not updated:
                    lines.append(f'HUGGINGFACE_API_TOKEN={hf_token}\n')
                
                with open(env_file, 'w') as f:
                    f.writelines(lines)
            
            print("✅ Hugging Face token saved to .env file")
            print("📊 You'll get enhanced AI responses with Hugging Face models")
        else:
            print("⚡ No token provided - using local pattern matching")
    else:
        print("⚡ Using local pattern matching (works without internet)")
    
    print("\n🚀 Configuration complete!")
    print("\nFeatures available:")
    print("✅ Natural language rule management")
    print("✅ Intent recognition and extraction")
    print("✅ Rule creation, updating, deletion, viewing")
    print("✅ Smart suggestions and error handling")
    print("✅ No paid API keys required!")
    
    print("\nNext steps:")
    print("1. Run: python -m flask run")
    print("2. Open: http://localhost:5000")
    print("3. Click 'Free AI Assistant' to start chatting")
    
    return True

if __name__ == '__main__':
    setup_free_ai_config()
