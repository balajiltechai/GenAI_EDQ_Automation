#!/usr/bin/env python3
"""
Ollama GenAI and Pattern Matching Test Suite
Tests the specialized Ollama LLM and Pattern Matching endpoints
"""

import requests
import json
import sys

def test_ollama_genai_endpoints():
    """Test Ollama GenAI endpoints"""
    base_url = "http://localhost:5001/api/ollama-genai"
    
    print("🧠 Testing Ollama GenAI Endpoints\n")
    
    # Test 1: Check Ollama status
    print("1. Testing Ollama status...")
    try:
        response = requests.get(f"{base_url}/status")
        if response.status_code == 200:
            data = response.json()
            print(f"   ✅ Ollama service running: {data.get('ollama_service', False)}")
            print(f"   ✅ Model available: {data.get('model_available', False)}")
            print(f"   ✅ Model name: {data.get('model_name', 'unknown')}")
            print(f"   ✅ Setup required: {data.get('setup_required', True)}")
            
            if data.get('error'):
                print(f"   ⚠️  Error: {data['error']}")
        else:
            print(f"   ❌ Error: {response.status_code}")
            return False
    except Exception as e:
        print(f"   ❌ Error: {e}")
        return False
    
    # Test 2: Get setup guide
    print("\n2. Testing setup guide...")
    try:
        response = requests.get(f"{base_url}/setup-guide")
        if response.status_code == 200:
            data = response.json()
            print(f"   ✅ Setup guide loaded")
            print(f"   ✅ Ready: {data.get('ready', False)}")
            print(f"   ✅ Steps provided: {len(data.get('steps', []))}")
        else:
            print(f"   ❌ Error: {response.status_code}")
            return False
    except Exception as e:
        print(f"   ❌ Error: {e}")
        return False
    
    # Test 3: Test chat (will likely fail without Ollama)
    print("\n3. Testing Ollama chat...")
    try:
        response = requests.post(
            f"{base_url}/chat",
            json={"message": "Help me create a validation rule"},
            headers={"Content-Type": "application/json"}
        )
        
        if response.status_code == 200:
            data = response.json()
            print(f"   ✅ Chat response received")
            print(f"   ✅ Model info: {data.get('model_info', {})}")
        elif response.status_code == 503:
            data = response.json()
            print(f"   ⚠️  Expected: {data.get('error', 'Setup required')}")
            print(f"   ✅ Proper error handling working")
        else:
            print(f"   ❌ Unexpected error: {response.status_code}")
            return False
    except Exception as e:
        print(f"   ❌ Error: {e}")
        return False
    
    return True

def test_pattern_matching_endpoints():
    """Test Pattern Matching endpoints"""
    base_url = "http://localhost:5001/api/pattern-matching"
    
    print("\n🔍 Testing Pattern Matching Endpoints\n")
    
    # Test 1: Get patterns info
    print("1. Testing patterns info...")
    try:
        response = requests.get(f"{base_url}/patterns")
        if response.status_code == 200:
            data = response.json()
            print(f"   ✅ Actions: {len(data.get('actions', []))} types")
            print(f"   ✅ Rule types: {len(data.get('rule_types', []))} types")
            print(f"   ✅ Severities: {len(data.get('severities', []))} levels")
            print(f"   ✅ Capabilities: {len(data.get('capabilities', []))} features")
        else:
            print(f"   ❌ Error: {response.status_code}")
            return False
    except Exception as e:
        print(f"   ❌ Error: {e}")
        return False
    
    # Test 2: Test pattern matching chat
    print("\n2. Testing pattern matching chat...")
    test_messages = [
        "Create a NOT_NULL validation for email field in Employee dataset",
        "Update the severity of phone validation to HIGH",
        "Delete the length rule from name field",
        "Show me all rules for Customer dataset",
        "Help me understand EDQ rules"
    ]
    
    for i, message in enumerate(test_messages, 1):
        print(f"   Test {i}: '{message[:50]}...'")
        try:
            response = requests.post(
                f"{base_url}/chat",
                json={"message": message},
                headers={"Content-Type": "application/json"}
            )
            
            if response.status_code == 200:
                data = response.json()
                parsed_result = data.get('parsed_result', {})
                intent = parsed_result.get('intent', {})
                
                print(f"     ✅ Action: {intent.get('action', 'unknown')}")
                print(f"     ✅ Confidence: {intent.get('confidence', 'unknown')}")
                print(f"     ✅ Dataset: {intent.get('dataset_name', 'none')}")
                print(f"     ✅ Field: {intent.get('field_name', 'none')}")
                print(f"     ✅ Rule Type: {intent.get('rule_type', 'none')}")
            else:
                print(f"     ❌ Error: {response.status_code}")
                return False
                
        except Exception as e:
            print(f"     ❌ Error: {e}")
            return False
    
    return True

def test_ui_endpoints():
    """Test UI endpoints"""
    print("\n🖥️  Testing UI Endpoints\n")
    
    endpoints = [
        ('/', 'Main Dashboard'),
        ('/ollama-chat', 'Ollama Chat Interface'),
        ('/pattern-chat', 'Pattern Matching Chat'),
        ('/pattern-test', 'Pattern Test Page')
    ]
    
    for endpoint, name in endpoints:
        print(f"Testing {name}...")
        try:
            response = requests.get(f"http://localhost:5001{endpoint}")
            if response.status_code == 200:
                print(f"   ✅ {name} accessible")
            else:
                print(f"   ❌ {name} error: {response.status_code}")
                return False
        except Exception as e:
            print(f"   ❌ {name} error: {e}")
            return False
    
    return True

def main():
    """Main function"""
    print("Ollama GenAI & Pattern Matching Test Suite")
    print("=" * 60)
    
    # Check if Flask app is running
    try:
        response = requests.get("http://localhost:5001/api/health")
        if response.status_code != 200:
            print("❌ Flask application is not running at localhost:5001")
            print("Please start the application with: python app.py")
            sys.exit(1)
    except requests.exceptions.ConnectionError:
        print("❌ Cannot connect to Flask application at localhost:5001")
        print("Please start the application with: python app.py")
        sys.exit(1)
    
    # Run tests
    all_tests_passed = True
    
    if not test_ollama_genai_endpoints():
        all_tests_passed = False
    
    if not test_pattern_matching_endpoints():
        all_tests_passed = False
    
    if not test_ui_endpoints():
        all_tests_passed = False
    
    print("\n" + "=" * 60)
    
    if all_tests_passed:
        print("✅ All tests passed! The system is working correctly.")
        print("\n🚀 Available Features:")
        print("1. Ollama GenAI (Llama 3.2 3B) - True AI when configured")
        print("2. Pattern Matching - Reliable fallback system") 
        print("3. Dual-mode chat interface with automatic switching")
        print("4. Intelligent setup guidance and error handling")
        
        print("\n🔗 Access Points:")
        print("• Main Dashboard: http://localhost:5001")
        print("• Ollama Chat: http://localhost:5001/ollama-chat")
        print("• Pattern Matching Chat: http://localhost:5001/pattern-chat")
        print("• Pattern Test Page: http://localhost:5001/pattern-test")
        
        print("\n📋 Next Steps:")
        print("1. Install Ollama for best AI experience: https://ollama.ai/")
        print("2. Run: ollama pull llama3.2:3b")
        print("3. Start Ollama service: ollama serve")
        print("4. Enjoy true GenAI-powered EDQ rule management!")
        
    else:
        print("❌ Some tests failed. Please check the application logs.")
        sys.exit(1)

if __name__ == "__main__":
    main()
