"""
Debug field extraction for the problematic message
"""
import re

def extract_field_name_debug(message: str):
    """Extract field name from message"""
    patterns = [
        r'for\s+(?:the\s+)?([a-zA-Z_][a-zA-Z0-9_]*)\s+field',
        r'([a-zA-Z_][a-zA-Z0-9_]*)\s+field',
        r'field[:\s]+([a-zA-Z_][a-zA-Z0-9_]*)',
        r'([a-zA-Z_][a-zA-Z0-9_]*)[:\s]+field',
        r'column[:\s]+([a-zA-Z_][a-zA-Z0-9_]*)',
        r'([a-zA-Z_][a-zA-Z0-9_]*)[:\s]+column',
        r'from\s+(?:the\s+)?([a-zA-Z_][a-zA-Z0-9_]*)\s+field',
        # Additional patterns for complex sentences
        r'field\s+name\s+(?:is\s+)?([a-zA-Z_][a-zA-Z0-9_]*)',
        r'with\s+field\s+name\s+([a-zA-Z_][a-zA-Z0-9_]*)',
        r'field\s+([a-zA-Z_][a-zA-Z0-9_]*)\s+(?:is|rule|type)'
    ]
    
    print(f"Testing message: '{message}'")
    
    for i, pattern in enumerate(patterns):
        match = re.search(pattern, message, re.IGNORECASE)
        if match:
            print(f"✓ Pattern {i+1} matched: {pattern}")
            print(f"  Extracted field: '{match.group(1)}'")
            return match.group(1).strip()
        else:
            print(f"✗ Pattern {i+1} no match: {pattern}")
            
    print("No field name found")
    return None

# Test the problematic message
message = "Update rule for the Employee Management dataset with field name is_active rule type NOT_NULL"
result = extract_field_name_debug(message)
print(f"\nFinal result: {result}")
