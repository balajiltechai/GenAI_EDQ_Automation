from app import create_app
import os

# Create Flask application instance
app = create_app()

if __name__ == '__main__':
    # Create database tables
    with app.app_context():
        from app import db
        db.create_all()
    
    # Run the application
    debug_mode = os.environ.get('FLASK_DEBUG', 'True').lower() == 'true'
    port = int(os.environ.get('PORT', 5001))  # Changed to port 5001
    
    app.run(
        host='0.0.0.0',
        port=port,
        debug=debug_mode
    )
