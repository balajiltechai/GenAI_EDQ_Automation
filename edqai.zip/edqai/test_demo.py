#!/usr/bin/env python3
"""
Simple test script to demonstrate the Dataset Registration API
"""
import requests
import json

BASE_URL = "http://localhost:5001/api"

def test_api():
    """Test the Dataset Registration API"""
    print("Testing Dataset Registration and Fields Management API")
    print("=" * 60)
    
    # Test health check
    try:
        response = requests.get(f"{BASE_URL}/health")
        if response.status_code == 200:
            print("✓ API Health Check: PASSED")
        else:
            print("✗ API Health Check: FAILED")
            return
    except requests.exceptions.ConnectionError:
        print("✗ Cannot connect to API. Make sure the Flask app is running on localhost:5000")
        return
    
    # Test dataset creation
    dataset_data = {
        "dataset_name": "Customer Database",
        "description": "Main customer information dataset"
    }
    
    response = requests.post(f"{BASE_URL}/datasets", json=dataset_data)
    if response.status_code == 201:
        print("✓ Dataset Creation: PASSED")
        dataset = response.json()["dataset"]
        dataset_id = dataset["id"]
        print(f"  Created dataset with ID: {dataset_id}")
        print(f"  Unique Dataset ID: {dataset['unique_dataset_id']}")
    else:
        print("✗ Dataset Creation: FAILED")
        print(f"  Response: {response.text}")
        return
    
    # Test field creation
    fields_data = [
        {
            "field_name": "customer_id",
            "data_type": "INTEGER",
            "length": 11,
            "is_nullable": False,
            "is_primary_key": True,
            "description": "Unique customer identifier"
        },
        {
            "field_name": "customer_name",
            "data_type": "VARCHAR",
            "length": 255,
            "is_nullable": False,
            "description": "Customer full name"
        },
        {
            "field_name": "email",
            "data_type": "VARCHAR",
            "length": 255,
            "is_nullable": True,
            "is_unique": True,
            "description": "Customer email address"
        },
        {
            "field_name": "registration_date",
            "data_type": "DATE",
            "is_nullable": False,
            "description": "Customer registration date"
        }
    ]
    
    print("\n✓ Adding fields to dataset:")
    for field_data in fields_data:
        response = requests.post(f"{BASE_URL}/datasets/{dataset_id}/fields", json=field_data)
        if response.status_code == 201:
            field = response.json()["field"]
            print(f"  ✓ Added field: {field['field_name']} ({field['data_type']})")
        else:
            print(f"  ✗ Failed to add field: {field_data['field_name']}")
            print(f"    Response: {response.text}")
    
    # Test getting dataset with fields
    response = requests.get(f"{BASE_URL}/datasets/{dataset_id}")
    if response.status_code == 200:
        print("\n✓ Dataset Retrieval: PASSED")
        dataset = response.json()["dataset"]
        print(f"  Dataset: {dataset['dataset_name']}")
        print(f"  Fields count: {len(dataset['fields'])}")
        
        print("\n  Field Details:")
        for field in dataset["fields"]:
            nullable = "NULL" if field["is_nullable"] else "NOT NULL"
            pk = " (PK)" if field["is_primary_key"] else ""
            unique = " (UNIQUE)" if field["is_unique"] else ""
            length_info = f"({field['length']})" if field["length"] else ""
            print(f"    {field['field_name']}: {field['data_type']}{length_info} {nullable}{pk}{unique}")
    else:
        print("✗ Dataset Retrieval: FAILED")
    
    # Test getting all datasets
    response = requests.get(f"{BASE_URL}/datasets")
    if response.status_code == 200:
        print(f"\n✓ All Datasets Retrieved: {len(response.json()['datasets'])} dataset(s)")
    else:
        print("✗ Failed to retrieve all datasets")
    
    print("\n" + "=" * 60)
    print("API Testing Complete!")

if __name__ == "__main__":
    test_api()
