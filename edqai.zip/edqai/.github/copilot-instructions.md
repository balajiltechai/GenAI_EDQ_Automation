<!-- Use this file to provide workspace-specific custom instructions to Copilot. For more details, visit https://code.visualstudio.com/docs/copilot/copilot-customization#_use-a-githubcopilotinstructionsmd-file -->

# Dataset Registration and Fields Management System

This is a Flask-based Python web application for managing dataset registration and field schemas.

## Key Components

- **Flask**: Web framework for API development
- **SQLAlchemy**: ORM for database operations
- **SQLite**: Database for data persistence
- **Flask-Migrate**: Database migration management

## Code Style Guidelines

- Follow PEP 8 Python style guidelines
- Use descriptive variable and function names
- Add docstrings to all functions and classes
- Handle exceptions appropriately with try-catch blocks
- Use type hints where appropriate

## Database Models

- **Dataset**: Stores dataset metadata with unique identifiers
- **Field**: Stores field schema information linked to datasets

## API Design

- RESTful API design principles
- JSON request/response format
- Proper HTTP status codes
- Error handling with meaningful messages

## Testing

- Use pytest for unit testing
- Test all API endpoints
- Include edge cases and error scenarios
- Mock database operations when needed
