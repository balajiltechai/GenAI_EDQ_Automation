#!/usr/bin/env python3
"""
Sample data loader for demonstrating the Dataset Registration UI
"""
import requests
import json

BASE_URL = "http://localhost:5001/api"

def create_sample_data():
    """Create sample datasets and fields for demonstration"""
    print("🚀 Loading sample data for Dataset Registration UI Demo")
    print("=" * 60)
    
    # Sample datasets
    datasets = [
        {
            "dataset_name": "Employee Management",
            "description": "Employee information and HR data management system"
        },
        {
            "dataset_name": "Inventory Tracking",
            "description": "Product inventory and warehouse management data"
        },
        {
            "dataset_name": "Sales Analytics",
            "description": "Sales transactions and customer analytics data"
        }
    ]
    
    # Sample fields for each dataset
    dataset_fields = {
        "Employee Management": [
            {
                "field_name": "employee_id",
                "data_type": "INTEGER",
                "length": 11,
                "is_nullable": False,
                "is_primary_key": True,
                "description": "Unique employee identifier"
            },
            {
                "field_name": "first_name",
                "data_type": "VARCHAR",
                "length": 100,
                "is_nullable": False,
                "description": "Employee first name"
            },
            {
                "field_name": "last_name",
                "data_type": "VARCHAR",
                "length": 100,
                "is_nullable": False,
                "description": "Employee last name"
            },
            {
                "field_name": "email",
                "data_type": "VARCHAR",
                "length": 255,
                "is_nullable": False,
                "is_unique": True,
                "description": "Employee email address"
            },
            {
                "field_name": "hire_date",
                "data_type": "DATE",
                "is_nullable": False,
                "description": "Employee hire date"
            },
            {
                "field_name": "salary",
                "data_type": "DECIMAL",
                "precision": 10,
                "scale": 2,
                "is_nullable": True,
                "description": "Employee salary"
            },
            {
                "field_name": "is_active",
                "data_type": "BOOLEAN",
                "is_nullable": False,
                "default_value": "true",
                "description": "Employee active status"
            }
        ],
        "Inventory Tracking": [
            {
                "field_name": "product_id",
                "data_type": "INTEGER",
                "length": 11,
                "is_nullable": False,
                "is_primary_key": True,
                "description": "Unique product identifier"
            },
            {
                "field_name": "product_code",
                "data_type": "VARCHAR",
                "length": 50,
                "is_nullable": False,
                "is_unique": True,
                "description": "Product SKU code"
            },
            {
                "field_name": "product_name",
                "data_type": "VARCHAR",
                "length": 255,
                "is_nullable": False,
                "description": "Product name"
            },
            {
                "field_name": "category",
                "data_type": "VARCHAR",
                "length": 100,
                "is_nullable": True,
                "description": "Product category"
            },
            {
                "field_name": "quantity_in_stock",
                "data_type": "INTEGER",
                "is_nullable": False,
                "default_value": "0",
                "description": "Current stock quantity"
            },
            {
                "field_name": "unit_price",
                "data_type": "DECIMAL",
                "precision": 8,
                "scale": 2,
                "is_nullable": False,
                "description": "Unit price"
            },
            {
                "field_name": "last_updated",
                "data_type": "DATETIME",
                "is_nullable": False,
                "description": "Last inventory update timestamp"
            }
        ],
        "Sales Analytics": [
            {
                "field_name": "transaction_id",
                "data_type": "INTEGER",
                "length": 11,
                "is_nullable": False,
                "is_primary_key": True,
                "description": "Unique transaction identifier"
            },
            {
                "field_name": "customer_id",
                "data_type": "INTEGER",
                "length": 11,
                "is_nullable": False,
                "description": "Customer identifier"
            },
            {
                "field_name": "transaction_date",
                "data_type": "DATETIME",
                "is_nullable": False,
                "description": "Transaction timestamp"
            },
            {
                "field_name": "total_amount",
                "data_type": "DECIMAL",
                "precision": 12,
                "scale": 2,
                "is_nullable": False,
                "description": "Total transaction amount"
            },
            {
                "field_name": "payment_method",
                "data_type": "VARCHAR",
                "length": 50,
                "is_nullable": True,
                "description": "Payment method used"
            },
            {
                "field_name": "discount_applied",
                "data_type": "DECIMAL",
                "precision": 5,
                "scale": 2,
                "is_nullable": True,
                "default_value": "0.00",
                "description": "Discount percentage applied"
            }
        ]
    }
    
    created_datasets = {}
    
    # Create datasets
    for dataset_info in datasets:
        try:
            response = requests.post(f"{BASE_URL}/datasets", json=dataset_info)
            if response.status_code == 201:
                dataset = response.json()["dataset"]
                created_datasets[dataset_info["dataset_name"]] = dataset["id"]
                print(f"✅ Created dataset: {dataset_info['dataset_name']} (ID: {dataset['id']})")
            else:
                print(f"❌ Failed to create dataset: {dataset_info['dataset_name']} - {response.text}")
        except Exception as e:
            print(f"❌ Error creating dataset {dataset_info['dataset_name']}: {e}")
    
    # Create fields for each dataset
    for dataset_name, dataset_id in created_datasets.items():
        if dataset_name in dataset_fields:
            print(f"\n📋 Adding fields to {dataset_name}:")
            for field_info in dataset_fields[dataset_name]:
                try:
                    response = requests.post(f"{BASE_URL}/datasets/{dataset_id}/fields", json=field_info)
                    if response.status_code == 201:
                        print(f"  ✅ Added field: {field_info['field_name']} ({field_info['data_type']})")
                    else:
                        print(f"  ❌ Failed to add field: {field_info['field_name']} - {response.text}")
                except Exception as e:
                    print(f"  ❌ Error adding field {field_info['field_name']}: {e}")
    
    print("\n" + "=" * 60)
    print("🎉 Sample data loading complete!")
    print("\n📱 Open the UI at: http://localhost:5001")
    print("🔍 You can now explore the interface with sample datasets and fields")

if __name__ == "__main__":
    create_sample_data()
