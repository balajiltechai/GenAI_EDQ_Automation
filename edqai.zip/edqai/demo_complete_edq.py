#!/usr/bin/env python3
"""
Complete EDQ Framework Demonstration
====================================

This script demonstrates the complete EDQ Framework workflow:
1. Dataset registration and field management
2. YAML-driven rule setup through APIs
3. Data quality validation
4. Quality reporting

Author: EDQ AI Team
Date: July 30, 2025
"""

import requests
import json
import time
from pathlib import Path
from edq_framework import EDQFramework

def print_section(title):
    """Print a formatted section header"""
    print("\n" + "="*60)
    print(f"🔍 {title}")
    print("="*60)

def print_step(step, description):
    """Print a formatted step"""
    print(f"\n📌 Step {step}: {description}")
    print("-" * 40)

def demo_api_endpoints():
    """Demonstrate basic API endpoints"""
    print_section("API ENDPOINTS DEMONSTRATION")
    
    base_url = "http://localhost:5001/api"
    
    print_step(1, "Testing Health Check")
    response = requests.get(f"{base_url}/health")
    print(f"✅ Health Check: {response.json()}")
    
    print_step(2, "Listing Available Datasets")
    response = requests.get(f"{base_url}/datasets")
    datasets = response.json()['datasets']
    print(f"📊 Found {len(datasets)} datasets:")
    for dataset in datasets:
        print(f"   • ID: {dataset['id']} | Name: {dataset['dataset_name']} | Fields: {dataset['fields_count']}")

def demo_yaml_rule_setup():
    """Demonstrate YAML-driven rule setup"""
    print_section("YAML-DRIVEN RULE SETUP")
    
    print_step(1, "Loading EDQ Framework")
    framework = EDQFramework("config/edq_config.yaml")
    print("✅ EDQ Framework initialized with configuration")
    
    print_step(2, "Setting up Employee Management Rules")
    print("📝 Reading rules from: config/employee_rules.yaml")
    results = framework.apply_rules_from_config("config/employee_rules.yaml")
    
    print(f"📊 Rules Setup Results:")
    print(f"   Total rules: {results['total_rules']}")
    print(f"   ✅ Successful: {results['successful_rules']}")
    print(f"   ❌ Failed: {results['failed_rules']}")
    
    print("\n📋 Rule Details:")
    for result in results['rule_results']:
        status_icon = "✅" if result['status'] == 'success' else "❌"
        print(f"   {status_icon} {result['rule_name']}")
        if result['status'] == 'failed':
            print(f"      ⚠️  Error: {result['error']}")

def demo_data_validation():
    """Demonstrate data validation against rules"""
    print_section("DATA QUALITY VALIDATION")
    
    framework = EDQFramework("config/edq_config.yaml")
    
    print_step(1, "Validating Employee Dataset (ID: 1)")
    validation_config = framework.config.get('validation', {})
    results = framework.validate_dataset(1, validation_config)
    
    print(f"🔍 Validation Results:")
    print(f"   Dataset: {results['dataset_name']} (ID: {results['dataset_id']})")
    print(f"   Overall Status: {results['overall_status']}")
    print(f"   Validation Time: {results['validation_timestamp']}")
    
    passed_fields = len([f for f in results['field_validations'] if f['status'] == 'PASS'])
    total_fields = len(results['field_validations'])
    
    print(f"\n📊 Field Summary:")
    print(f"   Total fields: {total_fields}")
    print(f"   ✅ Passed: {passed_fields}")
    print(f"   ❌ Failed: {total_fields - passed_fields}")
    
    print(f"\n📋 Field Details:")
    for field in results['field_validations']:
        status_icon = "✅" if field['status'] == 'PASS' else "❌"
        print(f"   {status_icon} {field['field_name']} ({field['field_type']})")

def demo_quality_reporting():
    """Demonstrate quality report generation"""
    print_section("QUALITY REPORT GENERATION")
    
    framework = EDQFramework("config/edq_config.yaml")
    
    print_step(1, "Generating Quality Report for Employee Dataset")
    report_file = "reports/demo_quality_report.json"
    report = framework.generate_quality_report(1, report_file)
    
    print(f"📊 Quality Report Generated:")
    print(f"   Report ID: {report['report_id']}")
    print(f"   Dataset: {report['dataset_info']['dataset_name']}")
    print(f"   Quality Score: {report['summary']['overall_score']:.1f}%")
    print(f"   💾 Saved to: {report_file}")
    
    print(f"\n📈 Summary Statistics:")
    print(f"   Total fields: {report['summary']['total_fields']}")
    print(f"   ✅ Passed: {report['summary']['passed_fields']}")
    print(f"   ❌ Failed: {report['summary']['failed_fields']}")
    
    print(f"\n📋 Quality Score Breakdown:")
    thresholds = framework.config.get('quality_thresholds', {})
    score = report['summary']['overall_score']
    
    if score >= thresholds.get('excellent', 95):
        grade = "EXCELLENT 🌟"
    elif score >= thresholds.get('good', 85):
        grade = "GOOD ✅"
    elif score >= thresholds.get('acceptable', 70):
        grade = "ACCEPTABLE ⚠️"
    else:
        grade = "NEEDS IMPROVEMENT ❌"
    
    print(f"   Quality Grade: {grade}")

def demo_multiple_datasets():
    """Demonstrate working with multiple datasets"""
    print_section("MULTIPLE DATASETS DEMONSTRATION")
    
    framework = EDQFramework("config/edq_config.yaml")
    
    print_step(1, "Setting up Inventory Rules")
    print("📝 Reading rules from: config/inventory_rules.yaml")
    results = framework.apply_rules_from_config("config/inventory_rules.yaml")
    print(f"   ✅ Applied {results['successful_rules']} inventory rules")
    
    print_step(2, "Validating Multiple Datasets")
    datasets_to_validate = [1, 2]  # Employee and Inventory
    
    for dataset_id in datasets_to_validate:
        validation_config = framework.config.get('validation', {})
        results = framework.validate_dataset(dataset_id, validation_config)
        
        passed = len([f for f in results['field_validations'] if f['status'] == 'PASS'])
        total = len(results['field_validations'])
        score = (passed / total) * 100 if total > 0 else 0
        
        print(f"   📊 Dataset {dataset_id} ({results['dataset_name']}): {score:.1f}% ({passed}/{total} fields)")

def demo_yaml_configuration():
    """Show the power of YAML configuration"""
    print_section("YAML CONFIGURATION SHOWCASE")
    
    print_step(1, "EDQ Configuration Structure")
    print("📝 Main config file: config/edq_config.yaml")
    print("   • API endpoints and timeouts")
    print("   • Logging configuration")
    print("   • Validation rules and thresholds")
    print("   • Report output settings")
    print("   • Predefined rule templates")
    
    print_step(2, "Rules Configuration Structure")
    print("📝 Rules files (e.g., config/employee_rules.yaml):")
    print("   • Metadata (version, author, description)")
    print("   • Target dataset information")
    print("   • Rule definitions with:")
    print("     - Rule name and type")
    print("     - API method and endpoint")
    print("     - Payload template with parameters")
    print("     - Priority and severity levels")
    
    print_step(3, "Supported Rule Types")
    rule_types = [
        "NOT_NULL - Ensure fields are not empty",
        "LENGTH_CHECK - Validate string lengths",
        "RANGE_CHECK - Validate numeric ranges",
        "FORMAT_VALIDATION - Pattern matching (email, phone, etc.)",
        "DATA_TYPE_CHECK - Ensure correct data types",
        "UNIQUENESS - Check for duplicate values",
        "CUSTOM - Business-specific validations"
    ]
    
    for rule_type in rule_types:
        print(f"   ✅ {rule_type}")

def main():
    """Run the complete EDQ demonstration"""
    print("🚀 COMPLETE EDQ FRAMEWORK DEMONSTRATION")
    print("=====================================")
    print("Welcome to the Enterprise Data Quality Framework demo!")
    print("This demo will showcase all EDQ capabilities...\n")
    
    try:
        # Check if Flask app is running
        response = requests.get("http://localhost:5001/api/health", timeout=5)
        if response.status_code != 200:
            print("❌ Flask application is not running. Please start it first:")
            print("   python app.py")
            return
            
    except requests.exceptions.RequestException:
        print("❌ Flask application is not accessible. Please start it first:")
        print("   python app.py")
        return
    
    # Run demonstration steps
    demo_api_endpoints()
    time.sleep(1)
    
    demo_yaml_configuration()
    time.sleep(1)
    
    demo_yaml_rule_setup()
    time.sleep(1)
    
    demo_data_validation()
    time.sleep(1)
    
    demo_quality_reporting()
    time.sleep(1)
    
    demo_multiple_datasets()
    
    print_section("DEMONSTRATION COMPLETE")
    print("🎉 EDQ Framework demonstration completed successfully!")
    print("\n🔗 Next Steps:")
    print("   • Explore the Web UI at: http://localhost:5001")
    print("   • Use CLI commands: python edq_cli.py --help")
    print("   • Create custom YAML rule configurations")
    print("   • Integrate with your data pipelines")
    print("   • Set up automated quality monitoring")
    
    print("\n📚 Key Features Demonstrated:")
    features = [
        "✅ YAML-driven rule configuration",
        "✅ REST API integration for rule setup",
        "✅ Automated data quality validation",
        "✅ Comprehensive quality reporting",
        "✅ Multi-dataset support",
        "✅ CLI interface for automation",
        "✅ Web UI for management",
        "✅ Configurable validation rules",
        "✅ Quality score calculation",
        "✅ Report generation and export"
    ]
    
    for feature in features:
        print(f"   {feature}")

if __name__ == "__main__":
    main()
