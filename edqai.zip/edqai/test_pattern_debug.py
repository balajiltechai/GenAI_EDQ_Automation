"""
Test pattern matching for NOT_NULL rule type
"""
import re

# Current NOT_NULL patterns from the code
not_null_patterns = [
    r'\b(not_null|not null|required|mandatory|must have|cannot be empty)\b',
    r'\b(null|empty|blank)\b.*\b(check|validation)\b',
    r'\b(should not be|must not be|cannot be|not be)\b.*\b(null|empty|blank)\b',
    r'\b(should not|must not|cannot)\b.*\b(null|empty|blank)\b',
    r'\b(no null|no empty|non.null|non.empty)\b'
]

test_messages = [
    "should not be null",
    "name field should not be null",
    "create a rule for name field should not be null",
    "email cannot be null",
    "phone must not be empty",
    "id field is required",
    "mandatory field check"
]

print("Testing NOT_NULL pattern matching:")
print("=" * 50)

for message in test_messages:
    print(f"\nMessage: '{message}'")
    message_lower = message.lower()
    
    for i, pattern in enumerate(not_null_patterns):
        match = re.search(pattern, message_lower, re.IGNORECASE)
        if match:
            print(f"  ✓ Pattern {i+1} matched: {pattern}")
            print(f"    Matched text: '{match.group()}'")
            break
    else:
        print("  ✗ No patterns matched")

# Test the specific issue
print("\n\nDetailed analysis for 'should not be null':")
print("=" * 50)
test_msg = "should not be null"
print(f"Testing: '{test_msg}'")

for i, pattern in enumerate(not_null_patterns):
    print(f"\nPattern {i+1}: {pattern}")
    match = re.search(pattern, test_msg, re.IGNORECASE)
    if match:
        print(f"  ✓ MATCHED: '{match.group()}'")
    else:
        print(f"  ✗ No match")

# Let's test a simpler version
print("\n\nTesting simpler patterns:")
simple_patterns = [
    r'should not be null',
    r'should not.*null',
    r'should.*not.*null',
    r'\bshould\b.*\bnot\b.*\bnull\b'
]

for i, pattern in enumerate(simple_patterns):
    print(f"Pattern {i+1}: {pattern}")
    match = re.search(pattern, test_msg, re.IGNORECASE)
    if match:
        print(f"  ✓ MATCHED: '{match.group()}'")
    else:
        print(f"  ✗ No match")
