"""
Test the field name extraction in isolation
"""
import re

def extract_field_name_test(message: str):
    """Extract field name from message"""
    patterns = [
        r'for\s+(?:the\s+)?([a-zA-Z_][a-zA-Z0-9_]*)\s+field',
        r'([a-zA-Z_][a-zA-Z0-9_]*)\s+field',
        r'field[:\s]+([a-zA-Z_][a-zA-Z0-9_]*)',
        r'([a-zA-Z_][a-zA-Z0-9_]*)[:\s]+field',
        r'column[:\s]+([a-zA-Z_][a-zA-Z0-9_]*)',
        r'([a-zA-Z_][a-zA-Z0-9_]*)[:\s]+column',
        r'from\s+(?:the\s+)?([a-zA-Z_][a-zA-Z0-9_]*)\s+field'
    ]
    
    print(f"Testing message: '{message}'")
    
    for i, pattern in enumerate(patterns):
        match = re.search(pattern, message, re.IGNORECASE)
        if match:
            print(f"✓ Pattern {i+1} matched: {pattern}")
            print(f"  Extracted field: '{match.group(1)}'")
            return match.group(1).strip()
        else:
            print(f"✗ Pattern {i+1} no match: {pattern}")
            
    print("No field name found")
    return None

# Test various messages
test_messages = [
    "Create new rule for the employee dataset location field should not be null",
    "email field should not be null",
    "location field validation",
    "for the location field",
    "name field must be required"
]

for msg in test_messages:
    print("=" * 60)
    result = extract_field_name_test(msg)
    print(f"Final result: {result}")
    print()
