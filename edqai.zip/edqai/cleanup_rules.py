#!/usr/bin/env python3
"""
EDQ Rules Cleanup Script
Clean up duplicate rules and update rule names
"""

import requests
import json

API_BASE_URL = 'http://localhost:5001/api'

def get_all_rules():
    """Get all existing rules"""
    response = requests.get(f"{API_BASE_URL}/data-quality-rules")
    if response.ok:
        return response.json()['rules']
    return []

def delete_rule(rule_id):
    """Delete a specific rule"""
    response = requests.delete(f"{API_BASE_URL}/data-quality-rules/{rule_id}")
    return response.ok

def update_rule_name(rule_id, new_name):
    """Update rule name"""
    data = {'rule_description': new_name}
    response = requests.put(f"{API_BASE_URL}/data-quality-rules/{rule_id}", 
                          json=data, 
                          headers={'Content-Type': 'application/json'})
    return response.ok

def cleanup_duplicate_rules():
    """Remove duplicate rules, keeping only the most recent one"""
    print("🧹 Starting duplicate rule cleanup...")
    
    rules = get_all_rules()
    print(f"📊 Found {len(rules)} total rules")
    
    # Group rules by dataset_id, field_name, and rule_type
    rule_groups = {}
    for rule in rules:
        key = (rule['dataset_id'], rule['field_name'], rule['rule_type'])
        if key not in rule_groups:
            rule_groups[key] = []
        rule_groups[key].append(rule)
    
    deleted_count = 0
    updated_count = 0
    
    for key, group_rules in rule_groups.items():
        dataset_id, field_name, rule_type = key
        
        if len(group_rules) > 1:
            print(f"\n🔍 Found {len(group_rules)} duplicate rules for {field_name}.{rule_type} in dataset {dataset_id}")
            
            # Sort by creation date (keep newest)
            group_rules.sort(key=lambda x: x['created_at'], reverse=True)
            newest_rule = group_rules[0]
            duplicates = group_rules[1:]
            
            # Delete duplicates
            for duplicate in duplicates:
                print(f"❌ Deleting duplicate rule ID {duplicate['id']} (created: {duplicate['created_at']})")
                if delete_rule(duplicate['id']):
                    deleted_count += 1
                    print(f"   ✅ Successfully deleted rule ID {duplicate['id']}")
                else:
                    print(f"   ❌ Failed to delete rule ID {duplicate['id']}")
            
            # Update the remaining rule name if it's "Unnamed Rule" or generic
            if not newest_rule.get('rule_description') or newest_rule.get('rule_description') in ['Unnamed Rule', 'No description available']:
                new_name = generate_rule_name(field_name, rule_type)
                print(f"📝 Updating rule name for ID {newest_rule['id']} to: {new_name}")
                if update_rule_name(newest_rule['id'], new_name):
                    updated_count += 1
                    print(f"   ✅ Successfully updated rule name")
                else:
                    print(f"   ❌ Failed to update rule name")
    
    print(f"\n🎉 Cleanup complete!")
    print(f"   ❌ Deleted {deleted_count} duplicate rules")
    print(f"   📝 Updated {updated_count} rule names")
    
    return deleted_count, updated_count

def generate_rule_name(field_name, rule_type):
    """Generate meaningful rule names based on field and type"""
    rule_name_templates = {
        'NOT_NULL': f"{field_name.replace('_', ' ').title()} Must Not Be Null",
        'LENGTH_VALIDATION': f"{field_name.replace('_', ' ').title()} Length Validation",
        'NUMERIC_VALIDATION': f"{field_name.replace('_', ' ').title()} Numeric Validation", 
        'FORMAT_VALIDATION': f"{field_name.replace('_', ' ').title()} Format Validation",
        'DATE_VALIDATION': f"{field_name.replace('_', ' ').title()} Date Validation",
        'BOOLEAN_VALIDATION': f"{field_name.replace('_', ' ').title()} Boolean Validation",
        'UNIQUENESS_VALIDATION': f"{field_name.replace('_', ' ').title()} Uniqueness Validation",
        'RANGE_CHECK': f"{field_name.replace('_', ' ').title()} Range Check"
    }
    
    return rule_name_templates.get(rule_type, f"{field_name.replace('_', ' ').title()} {rule_type} Rule")

def update_all_rule_names():
    """Update all remaining rules to have proper names"""
    print("\n📝 Updating all rule names...")
    
    rules = get_all_rules()
    updated_count = 0
    
    for rule in rules:
        current_name = rule.get('rule_description', '')
        if not current_name or current_name in ['Unnamed Rule', 'No description available']:
            new_name = generate_rule_name(rule['field_name'], rule['rule_type'])
            print(f"📝 Updating rule ID {rule['id']}: {rule['rule_type']} on {rule['field_name']} -> {new_name}")
            
            if update_rule_name(rule['id'], new_name):
                updated_count += 1
                print(f"   ✅ Updated successfully")
            else:
                print(f"   ❌ Update failed")
    
    print(f"\n✅ Updated {updated_count} rule names")
    return updated_count

def main():
    """Main cleanup function"""
    print("🚀 EDQ Rules Cleanup and Name Update")
    print("=" * 50)
    
    try:
        # Test API connection
        response = requests.get(f"{API_BASE_URL}/health")
        if not response.ok:
            print("❌ Cannot connect to API. Please ensure the Flask app is running.")
            return
        
        print("✅ API connection successful")
        
        # Cleanup duplicates
        deleted, updated_names = cleanup_duplicate_rules()
        
        # Update remaining rule names
        additional_updates = update_all_rule_names()
        
        total_updates = updated_names + additional_updates
        
        print("\n" + "=" * 50)
        print("🎉 CLEANUP SUMMARY")
        print("=" * 50)
        print(f"❌ Duplicate rules deleted: {deleted}")
        print(f"📝 Rule names updated: {total_updates}")
        print("✅ Cleanup completed successfully!")
        
        # Show final statistics
        final_rules = get_all_rules()
        print(f"\n📊 Final rule count: {len(final_rules)}")
        
        # Group by dataset for summary
        dataset_counts = {}
        for rule in final_rules:
            dataset_id = rule['dataset_id']
            if dataset_id not in dataset_counts:
                dataset_counts[dataset_id] = 0
            dataset_counts[dataset_id] += 1
        
        print("📋 Rules by dataset:")
        for dataset_id, count in dataset_counts.items():
            print(f"   Dataset {dataset_id}: {count} rules")
            
    except Exception as e:
        print(f"❌ Error during cleanup: {e}")

if __name__ == "__main__":
    main()
