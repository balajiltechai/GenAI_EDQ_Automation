"""
Debug rule type extraction for numeric validation
"""
import re

# Current patterns from the code
rule_type_patterns = {
    'NUMERIC_VALIDATION': [
        r'\b(numeric|number|integer|decimal|digit|range)\b',
        r'\b(must be|should be)\b.*\b(number|numeric|digit)\b'
    ],
    'RANGE_CHECK': [
        r'\b(range|between|from|to|within)\b',
        r'\b(minimum|maximum|min|max)\b.*\b(value|amount)\b'
    ]
}

def test_rule_type_extraction(message: str):
    message_lower = message.lower()
    print(f"Testing message: '{message}'")
    
    # Test RANGE_CHECK patterns first (current order)
    print("\nTesting RANGE_CHECK patterns:")
    for i, pattern in enumerate(rule_type_patterns['RANGE_CHECK']):
        match = re.search(pattern, message_lower, re.IGNORECASE)
        if match:
            print(f"  ✓ Pattern {i+1} matched: {pattern}")
            print(f"    Matched text: '{match.group()}'")
        else:
            print(f"  ✗ Pattern {i+1} no match: {pattern}")
    
    # Test NUMERIC_VALIDATION patterns
    print("\nTesting NUMERIC_VALIDATION patterns:")
    for i, pattern in enumerate(rule_type_patterns['NUMERIC_VALIDATION']):
        match = re.search(pattern, message_lower, re.IGNORECASE)
        if match:
            print(f"  ✓ Pattern {i+1} matched: {pattern}")
            print(f"    Matched text: '{match.group()}'")
        else:
            print(f"  ✗ Pattern {i+1} no match: {pattern}")

# Test messages
test_messages = [
    "update rule to the dataset Inventory Tracking, field category, rule type with numeric validation",
    "numeric validation",
    "range check",
    "numeric range validation",
    "number validation"
]

for msg in test_messages:
    print("=" * 80)
    test_rule_type_extraction(msg)
    print()
