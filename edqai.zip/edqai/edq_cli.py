#!/usr/bin/env python3
"""
EDQ Framework CLI
Command-line interface for Enterprise Data Quality Framework
"""

import argparse
import sys
import json
from pathlib import Path
from edq_framework import EDQFramework

def setup_rules_command(args):
    """Setup data quality rules from configuration file"""
    try:
        framework = EDQFramework(args.config)
        results = framework.apply_rules_from_config(args.rules_file)
        
        print(f"📊 Rules Setup Summary:")
        print(f"   Total rules processed: {results['total_rules']}")
        print(f"   ✅ Successful: {results['successful_rules']}")
        print(f"   ❌ Failed: {results['failed_rules']}")
        
        if args.verbose:
            print("\n📋 Detailed Results:")
            for result in results['rule_results']:
                status_icon = "✅" if result['status'] == 'success' else "❌"
                print(f"   {status_icon} {result['rule_name']}: {result['status']}")
                if result['status'] == 'failed':
                    print(f"      Error: {result['error']}")
        
        return 0 if results['failed_rules'] == 0 else 1
        
    except Exception as e:
        print(f"❌ Error setting up rules: {e}")
        return 1

def validate_dataset_command(args):
    """Validate dataset against quality rules"""
    try:
        framework = EDQFramework(args.config)
        
        # Load validation configuration
        validation_config = framework.config.get('validation', {})
        results = framework.validate_dataset(args.dataset_id, validation_config)
        
        print(f"🔍 Dataset Validation Results:")
        print(f"   Dataset: {results['dataset_name']} (ID: {results['dataset_id']})")
        print(f"   Overall Status: {results['overall_status']}")
        print(f"   Validation Time: {results['validation_timestamp']}")
        
        passed_fields = len([f for f in results['field_validations'] if f['status'] == 'PASS'])
        total_fields = len(results['field_validations'])
        
        print(f"\n📊 Field Validation Summary:")
        print(f"   Total fields: {total_fields}")
        print(f"   ✅ Passed: {passed_fields}")
        print(f"   ❌ Failed: {total_fields - passed_fields}")
        
        if args.verbose:
            print(f"\n📋 Field Details:")
            for field in results['field_validations']:
                status_icon = "✅" if field['status'] == 'PASS' else "❌"
                print(f"   {status_icon} {field['field_name']} ({field['field_type']})")
                for violation in field.get('violations', []):
                    print(f"      ⚠️  {violation}")
        
        return 0 if results['overall_status'] == 'PASS' else 1
        
    except Exception as e:
        print(f"❌ Error validating dataset: {e}")
        return 1

def generate_report_command(args):
    """Generate quality report for dataset"""
    try:
        framework = EDQFramework(args.config)
        report = framework.generate_quality_report(args.dataset_id, args.output)
        
        print(f"📊 Quality Report Generated:")
        print(f"   Report ID: {report['report_id']}")
        print(f"   Dataset: {report['dataset_info']['dataset_name']}")
        print(f"   Quality Score: {report['summary']['overall_score']:.1f}%")
        
        if args.output:
            print(f"   💾 Saved to: {args.output}")
        
        print(f"\n📈 Summary Statistics:")
        print(f"   Total fields: {report['summary']['total_fields']}")
        print(f"   ✅ Passed: {report['summary']['passed_fields']}")
        print(f"   ❌ Failed: {report['summary']['failed_fields']}")
        
        return 0
        
    except Exception as e:
        print(f"❌ Error generating report: {e}")
        return 1

def list_datasets_command(args):
    """List available datasets"""
    try:
        framework = EDQFramework(args.config)
        response = framework._make_api_call('GET', 'datasets')
        datasets = response.get('datasets', [])
        
        print(f"📂 Available Datasets ({len(datasets)}):")
        for dataset in datasets:
            print(f"   ID: {dataset['id']} | Name: {dataset['dataset_name']} | Fields: {dataset['fields_count']}")
            if args.verbose:
                print(f"      Description: {dataset.get('description', 'No description')}")
                print(f"      UUID: {dataset['unique_dataset_id']}")
        
        return 0
        
    except Exception as e:
        print(f"❌ Error listing datasets: {e}")
        return 1

def create_sample_config_command(args):
    """Create sample configuration files"""
    try:
        config_dir = Path("config")
        config_dir.mkdir(exist_ok=True)
        
        # Create sample EDQ config if it doesn't exist
        edq_config_file = config_dir / "edq_config.yaml"
        if not edq_config_file.exists() or args.overwrite:
            print(f"📝 Creating EDQ configuration: {edq_config_file}")
            # The file already exists in our project
        
        # Create sample rules config
        sample_rules_file = config_dir / "sample_rules.yaml"
        if not sample_rules_file.exists() or args.overwrite:
            sample_rules = {
                'metadata': {
                    'config_version': '1.0',
                    'created_by': 'EDQ CLI',
                    'description': 'Sample data quality rules'
                },
                'target_dataset': {
                    'dataset_id': 1,
                    'dataset_name': 'Sample Dataset'
                },
                'rules': [
                    {
                        'rule_name': 'Sample Not Null Rule',
                        'rule_type': 'not_null',
                        'description': 'Ensure field cannot be null',
                        'priority': 'HIGH',
                        'api': {
                            'method': 'POST',
                            'endpoint': 'data-quality-rules'
                        },
                        'payload': {
                            'rule_type': 'NOT_NULL',
                            'dataset_id': '${dataset_id}',
                            'field_name': '${field_name}',
                            'rule_description': 'Field must not be null',
                            'severity': 'HIGH',
                            'is_active': True
                        },
                        'parameters': {
                            'dataset_id': 1,
                            'field_name': 'id'
                        }
                    }
                ]
            }
            
            with open(sample_rules_file, 'w') as f:
                import yaml
                yaml.dump(sample_rules, f, default_flow_style=False, indent=2)
            print(f"📝 Created sample rules configuration: {sample_rules_file}")
        
        print(f"✅ Configuration files ready in {config_dir}")
        return 0
        
    except Exception as e:
        print(f"❌ Error creating sample config: {e}")
        return 1

def main():
    """Main CLI entry point"""
    parser = argparse.ArgumentParser(
        description="EDQ Framework - Enterprise Data Quality Management",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s setup-rules --rules-file config/employee_rules.yaml
  %(prog)s validate --dataset-id 1 --verbose
  %(prog)s report --dataset-id 1 --output reports/quality_report.json
  %(prog)s list-datasets
        """
    )
    
    parser.add_argument(
        '--config', '-c',
        default='config/edq_config.yaml',
        help='Path to EDQ configuration file (default: config/edq_config.yaml)'
    )
    
    subparsers = parser.add_subparsers(dest='command', help='Available commands')
    
    # Setup rules command
    setup_parser = subparsers.add_parser('setup-rules', help='Setup data quality rules from configuration')
    setup_parser.add_argument('--rules-file', '-r', required=True, help='Path to rules configuration file')
    setup_parser.add_argument('--verbose', '-v', action='store_true', help='Enable verbose output')
    
    # Validate dataset command
    validate_parser = subparsers.add_parser('validate', help='Validate dataset against quality rules')
    validate_parser.add_argument('--dataset-id', '-d', type=int, required=True, help='Dataset ID to validate')
    validate_parser.add_argument('--verbose', '-v', action='store_true', help='Enable verbose output')
    
    # Generate report command
    report_parser = subparsers.add_parser('report', help='Generate quality report for dataset')
    report_parser.add_argument('--dataset-id', '-d', type=int, required=True, help='Dataset ID for report')
    report_parser.add_argument('--output', '-o', help='Output file path for report')
    
    # List datasets command
    list_parser = subparsers.add_parser('list-datasets', help='List available datasets')
    list_parser.add_argument('--verbose', '-v', action='store_true', help='Enable verbose output')
    
    # Create sample config command
    config_parser = subparsers.add_parser('create-config', help='Create sample configuration files')
    config_parser.add_argument('--overwrite', action='store_true', help='Overwrite existing files')
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return 1
    
    # Execute command
    command_map = {
        'setup-rules': setup_rules_command,
        'validate': validate_dataset_command,
        'report': generate_report_command,
        'list-datasets': list_datasets_command,
        'create-config': create_sample_config_command
    }
    
    return command_map[args.command](args)

if __name__ == '__main__':
    sys.exit(main())
