#!/usr/bin/env python3
"""
Quick setup script for the Dat    print("\n" + "=" * 60)
    print("🎉 Setup Complete!")
    print("\n📝 Next Steps:")
    print("1. Start the application:")
    print(f'   {python_exe} app.py')
    print("\n2. Open the Web UI:")
    print("   🌐 Go to: http://localhost:5001")
    print("   📊 Interactive dashboard for managing datasets and fields")
    print("\n3. Load sample data (optional):")
    print(f"   {python_exe} load_sample_data.py")
    print("\n4. Test the API:")
    print("   curl http://localhost:5001/api/health")
    print("\n5. View usage examples:")
    print("   📖 See USAGE.md for detailed API and UI examples")
    print("\n6. Run the demo script:")
    print(f"   {python_exe} test_demo.py")ation and Fields Management System
"""
import os
import sys
import subprocess
from pathlib import Path

def run_command(command, description):
    """Run a command and handle errors"""
    print(f"📋 {description}...")
    try:
        result = subprocess.run(command, shell=True, check=True, capture_output=True, text=True)
        print(f"✅ {description} - Success")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ {description} - Failed")
        print(f"Error: {e.stderr}")
        return False

def main():
    """Main setup function"""
    print("🚀 Dataset Registration and Fields Management System Setup")
    print("=" * 60)
    
    # Check if we're in the right directory
    if not Path("app.py").exists():
        print("❌ Please run this script from the project root directory")
        sys.exit(1)
    
    # Check if virtual environment exists
    venv_path = Path(".venv")
    if not venv_path.exists():
        print("📦 Creating virtual environment...")
        if not run_command("python -m venv .venv", "Create virtual environment"):
            sys.exit(1)
    
    # Determine the correct Python executable path
    if os.name == 'nt':  # Windows
        python_exe = str(Path(".venv/Scripts/python.exe").resolve())
        pip_exe = str(Path(".venv/Scripts/pip.exe").resolve())
    else:  # Unix/Linux/Mac
        python_exe = str(Path(".venv/bin/python").resolve())
        pip_exe = str(Path(".venv/bin/pip").resolve())
    
    # Install dependencies
    if not run_command(f'"{pip_exe}" install -r requirements.txt', "Install dependencies"):
        sys.exit(1)
    
    # Initialize database
    init_db_command = f'"{python_exe}" -c "from app import create_app, db; app = create_app(); app.app_context().push(); db.create_all(); print(\'Database initialized successfully!\')"'
    if not run_command(init_db_command, "Initialize database"):
        sys.exit(1)
    
    # Run tests
    if not run_command(f'"{python_exe}" -m pytest tests/ -v', "Run tests"):
        print("⚠️  Tests failed, but the application should still work")
    
    print("\n" + "=" * 60)
    print("🎉 Setup Complete!")
    print("\n📝 Next Steps:")
    print("1. Start the application:")
    print(f'   {python_exe} app.py')
    print("\n2. The API will be available at: http://localhost:5000")
    print("\n3. Test the API:")
    print("   curl http://localhost:5000/api/health")
    print("\n4. View usage examples:")
    print("   See USAGE.md for detailed API examples")
    print("\n5. Run the demo script:")
    print(f"   {python_exe} test_demo.py")

if __name__ == "__main__":
    main()
