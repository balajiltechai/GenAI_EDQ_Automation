# Dataset Registration and Fields Management System

A Python Flask application for Product Managers to register datasets and manage field schemas in a database.

## ✨ Features

- **Dataset Registration**: Register datasets with unique identifiers and metadata
- **Field Management**: Add and manage fields for registered datasets with datatype and length specifications
- **GenAI Assistant**: Conversational AI interface for managing EDQ rules using natural language
- **REST API**: Complete RESTful API for dataset and field operations
- **Database Persistence**: SQLite database for reliable data storage
- **Comprehensive Testing**: Unit tests with pytest
- **Type Safety**: Proper data validation and error handling

## 🚀 Quick Start

1. **Run the setup script**:
   ```bash
   python setup.py
   ```

2. **Start the application**:
   ```bash
   python app.py
   ```

3. **Test the API**:
   ```bash
   curl http://localhost:5000/api/health
   ```

4. **Access the Ollama Assistant**:
   - Web interface: `http://localhost:5001`
   - Ollama chat: `http://localhost:5001/ollama-chat`

## 📁 Project Structure

```
edqai/
├── app/
│   ├── __init__.py          # Flask app factory
│   ├── models.py            # Database models (Dataset, Field)
│   ├── routes.py            # API routes
│   └── config.py            # Configuration settings
├── tests/                   # Unit tests
│   ├── __init__.py
│   └── test_api.py         # API endpoint tests
├── .github/
│   └── copilot-instructions.md  # GitHub Copilot instructions
├── .vscode/
│   └── tasks.json          # VS Code tasks
├── requirements.txt         # Python dependencies
├── app.py                   # Application entry point
├── setup.py                # Quick setup script
├── test_demo.py            # API demonstration script
├── USAGE.md                # Detailed usage examples
└── README.md               # This file
```

## Installation

1. **Clone the repository**:
   ```bash
   git clone <repository-url>
   cd edqai
   ```

2. **Create virtual environment**:
   ```bash
   python -m venv venv
   venv\Scripts\activate  # On Windows
   ```

3. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

4. **Initialize database**:
   ```bash
   flask db init
   flask db migrate -m "Initial migration"
   flask db upgrade
   ```

5. **Run the application**:
   ```bash
   python app.py
   ```

## API Endpoints

### Datasets

- **POST /api/datasets** - Register a new dataset
- **GET /api/datasets** - Get all datasets
- **GET /api/datasets/{id}** - Get specific dataset
- **PUT /api/datasets/{id}** - Update dataset
- **DELETE /api/datasets/{id}** - Delete dataset

### Fields

- **POST /api/datasets/{dataset_id}/fields** - Add field to dataset
- **GET /api/datasets/{dataset_id}/fields** - Get all fields for dataset
- **PUT /api/fields/{field_id}** - Update field
- **DELETE /api/fields/{field_id}** - Delete field

## Usage Examples

### Register a Dataset

```bash
curl -X POST http://localhost:5000/api/datasets \
  -H "Content-Type: application/json" \
  -d '{
    "dataset_name": "Customer Data",
    "description": "Customer information dataset"
  }'
```

### Add Field to Dataset

```bash
curl -X POST http://localhost:5000/api/datasets/1/fields \
  -H "Content-Type: application/json" \
  -d '{
    "field_name": "customer_id",
    "data_type": "INTEGER",
    "length": 11,
    "is_nullable": false,
    "description": "Unique customer identifier"
  }'
```

## Database Schema

### Dataset Table
- `id` (Primary Key)
- `unique_dataset_id` (Unique identifier)
- `dataset_name`
- `description`
- `created_at`
- `updated_at`

### Field Table
- `id` (Primary Key)
- `dataset_id` (Foreign Key)
- `field_name`
- `data_type`
- `length`
- `is_nullable`
- `description`
- `created_at`
- `updated_at`

## 🤖 **Ollama GenAI EDQ Assistant**

The application features a conversational AI assistant powered by **Llama 3.2 3B** via Ollama for managing EDQ (Enterprise Data Quality) rules using natural language.

### **AI Modes:**
- **Ollama GenAI**: Llama 3.2 3B model for true AI understanding
- **Pattern Matching**: Reliable rule-based fallback system

### **Capabilities:**
- 📝 **Create Rules**: "Set up validation rules for email field in Employee dataset"
- ✏️ **Update Rules**: "Change the email validation severity to CRITICAL"
- 🗑️ **Delete Rules**: "Remove the salary range validation rule"
- 📊 **View Rules**: "Show me all rules for the Inventory dataset"

### **Quick Setup:**
1. **Install Ollama** (recommended):
   ```bash
   # Install Ollama from https://ollama.ai/
   ollama pull llama3.2:3b
   ollama serve
   ```

2. **Access the assistant**: `http://localhost:5001/ollama-chat`

See `OLLAMA_IMPLEMENTATION_COMPLETE.md` for detailed information.

## 🖥️ **Web UI Interface**

The application now includes a modern, responsive web interface for managing datasets and fields:

### **Features:**
- **Dashboard View**: Overview of all registered datasets with statistics
- **Dataset Management**: Create, view, and manage datasets through intuitive forms
- **Field Management**: Add and configure fields with data types, constraints, and descriptions
- **Real-time Updates**: Live data refresh and instant feedback
- **Responsive Design**: Works on desktop, tablet, and mobile devices

### **Access the UI:**
1. Start the application: `python app.py`
2. Open your browser and go to: `http://localhost:5001`
3. Use the interface to:
   - View all registered datasets
   - Add new datasets with descriptions
   - Add fields to existing datasets
   - Configure field properties (data types, constraints, etc.)
   - View detailed field schemas

### **UI Screenshots Walkthrough:**
- **Main Dashboard**: Shows dataset overview with statistics
- **Add Dataset**: Modal form for creating new datasets
- **Add Field**: Comprehensive form for field configuration
- **Field View**: Expandable table showing all field details with constraints

## 🎯 **Quick UI Demo**

To see the UI in action with sample data:

1. **Start the application**:
   ```bash
   python app.py
   ```

2. **Load sample data** (optional):
   ```bash
   python load_sample_data.py
   ```

3. **Open the web interface**:
   - Go to: `http://localhost:5001`
   - The UI will show:
     - 3 sample datasets (Employee Management, Inventory Tracking, Sales Analytics)
     - 20 total fields across all datasets
     - Interactive forms to add new datasets and fields

### **UI Features:**

- **📊 Dashboard**: Real-time statistics showing total datasets and fields
- **➕ Add Dataset**: Modern modal form with validation
- **🔧 Add Fields**: Comprehensive field configuration with:
  - Data types (INTEGER, VARCHAR, DATE, DECIMAL, etc.)
  - Length specifications
  - Constraints (Primary Key, Unique, Nullable)
  - Default values and descriptions
- **👁️ View Fields**: Expandable field viewer with constraint badges
- **🔄 Auto-refresh**: Real-time updates when data changes
- **📱 Responsive**: Works on desktop, tablet, and mobile devices

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests for new functionality
5. Submit a pull request

## License

This project is licensed under the MIT License.
