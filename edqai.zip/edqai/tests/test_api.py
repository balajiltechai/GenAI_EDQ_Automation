import pytest
import json
from app import create_app, db
from app.models import Dataset, Field

@pytest.fixture
def app():
    """Create application for testing"""
    app = create_app()
    app.config['TESTING'] = True
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
    
    with app.app_context():
        db.create_all()
        yield app
        db.drop_all()

@pytest.fixture
def client(app):
    """Create test client"""
    return app.test_client()

@pytest.fixture
def sample_dataset(app):
    """Create a sample dataset for testing"""
    with app.app_context():
        dataset = Dataset(
            dataset_name="Test Dataset",
            description="A test dataset"
        )
        db.session.add(dataset)
        db.session.commit()
        # Refresh the dataset to ensure it's attached to the session
        db.session.refresh(dataset)
        dataset_id = dataset.id
        db.session.expunge(dataset)  # Detach from session
        # Return just the ID instead of the object
        return {'id': dataset_id, 'dataset_name': 'Test Dataset'}

class TestDatasetAPI:
    """Test cases for Dataset API endpoints"""
    
    def test_create_dataset(self, client):
        """Test creating a new dataset"""
        data = {
            "dataset_name": "Customer Data",
            "description": "Customer information dataset"
        }
        
        response = client.post('/api/datasets', 
                             data=json.dumps(data),
                             content_type='application/json')
        
        assert response.status_code == 201
        response_data = json.loads(response.data)
        assert response_data['message'] == 'Dataset created successfully'
        assert response_data['dataset']['dataset_name'] == 'Customer Data'
        assert 'unique_dataset_id' in response_data['dataset']
    
    def test_create_dataset_duplicate_name(self, client, sample_dataset):
        """Test creating a dataset with duplicate name"""
        data = {
            "dataset_name": sample_dataset['dataset_name'],
            "description": "Another test dataset"
        }
        
        response = client.post('/api/datasets',
                             data=json.dumps(data),
                             content_type='application/json')
        
        assert response.status_code == 409
        response_data = json.loads(response.data)
        assert 'already exists' in response_data['error']
    
    def test_get_datasets(self, client, sample_dataset):
        """Test getting all datasets"""
        response = client.get('/api/datasets')
        
        assert response.status_code == 200
        response_data = json.loads(response.data)
        assert len(response_data['datasets']) == 1
        assert response_data['datasets'][0]['dataset_name'] == 'Test Dataset'
    
    def test_get_dataset_by_id(self, client, sample_dataset):
        """Test getting a specific dataset"""
        response = client.get(f'/api/datasets/{sample_dataset["id"]}')
        
        assert response.status_code == 200
        response_data = json.loads(response.data)
        assert response_data['dataset']['dataset_name'] == 'Test Dataset'
        assert 'fields' in response_data['dataset']

class TestFieldAPI:
    """Test cases for Field API endpoints"""
    
    def test_create_field(self, client, sample_dataset):
        """Test creating a new field"""
        data = {
            "field_name": "customer_id",
            "data_type": "INTEGER",
            "length": 11,
            "is_nullable": False,
            "description": "Unique customer identifier"
        }
        
        response = client.post(f'/api/datasets/{sample_dataset["id"]}/fields',
                             data=json.dumps(data),
                             content_type='application/json')
        
        assert response.status_code == 201
        response_data = json.loads(response.data)
        assert response_data['message'] == 'Field added successfully'
        assert response_data['field']['field_name'] == 'customer_id'
        assert response_data['field']['data_type'] == 'INTEGER'
    
    def test_create_field_duplicate_name(self, client, sample_dataset):
        """Test creating a field with duplicate name in same dataset"""
        # Create first field
        data = {
            "field_name": "customer_id",
            "data_type": "INTEGER"
        }
        client.post(f'/api/datasets/{sample_dataset["id"]}/fields',
                   data=json.dumps(data),
                   content_type='application/json')
        
        # Try to create duplicate field
        response = client.post(f'/api/datasets/{sample_dataset["id"]}/fields',
                             data=json.dumps(data),
                             content_type='application/json')
        
        assert response.status_code == 409
        response_data = json.loads(response.data)
        assert 'already exists' in response_data['error']
    
    def test_get_dataset_fields(self, client, sample_dataset):
        """Test getting all fields for a dataset"""
        # Create a field first
        data = {
            "field_name": "customer_name",
            "data_type": "VARCHAR",
            "length": 255
        }
        client.post(f'/api/datasets/{sample_dataset["id"]}/fields',
                   data=json.dumps(data),
                   content_type='application/json')
        
        response = client.get(f'/api/datasets/{sample_dataset["id"]}/fields')
        
        assert response.status_code == 200
        response_data = json.loads(response.data)
        assert len(response_data['fields']) == 1
        assert response_data['fields'][0]['field_name'] == 'customer_name'
