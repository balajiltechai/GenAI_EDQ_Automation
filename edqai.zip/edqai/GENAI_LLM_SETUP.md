# GenAI LLM Assistant Setup Guide

This guide helps you set up free LLM providers for the GenAI EDQ Assistant.

## Supported Free LLM Providers

The GenAI EDQ Assistant supports three free LLM providers:

### 1. Ollama (Local - Recommended)
- **Pros**: Completely free, private, fast, no API limits
- **Cons**: Requires local installation and model download

**Setup:**
1. Install Ollama from https://ollama.ai/
2. Start Ollama service
3. Pull a compatible model:
   ```bash
   ollama pull llama3.2:3b
   ```
4. Verify installation:
   ```bash
   ollama list
   ```

### 2. Groq (Cloud API)
- **Pros**: Fast inference, good free tier
- **Cons**: Requires API key, rate limits

**Setup:**
1. Go to https://console.groq.com/
2. Create a free account
3. Generate an API key
4. Add to your `.env` file:
   ```
   GROQ_API_KEY=your_groq_api_key_here
   ```

### 3. HuggingFace (Cloud API)
- **Pros**: Many model options, generous free tier
- **Cons**: Can be slower, requires API token

**Setup:**
1. Go to https://huggingface.co/
2. Create a free account
3. Generate an access token at https://huggingface.co/settings/tokens
4. Add to your `.env` file:
   ```
   HUGGINGFACE_API_TOKEN=your_hf_token_here
   ```

## Environment Configuration

Create a `.env` file in your project root:

```bash
# Optional: Groq API (for cloud-based LLM)
GROQ_API_KEY=your_groq_api_key_here

# Optional: HuggingFace API (for cloud-based LLM)
HUGGINGFACE_API_TOKEN=your_hf_token_here

# Flask configuration
FLASK_ENV=development
SECRET_KEY=your-secret-key-here
```

## Provider Priority

The system automatically selects the best available provider:

1. **Ollama** (if running locally) - Highest priority
2. **Groq** (if API key provided) - Medium priority  
3. **HuggingFace** (if token provided) - Low priority
4. **Pattern Matching** (fallback) - No LLM required

## Testing Your Setup

1. Start the Flask application:
   ```bash
   python app.py
   ```

2. Open the GenAI chat interface: http://localhost:5000/genai-chat

3. Check the status indicator in the chat header to see which AI model is active

4. Test with a simple query: "Help me create a validation rule"

## Troubleshooting

### Ollama Issues
- **Port conflict**: Ollama runs on port 11434 by default
- **Model not found**: Make sure you've pulled the correct model
- **Service not running**: Start Ollama with `ollama serve`

### API Issues
- **Invalid API key**: Verify your keys are correct and active
- **Rate limits**: Free tiers have usage limits
- **Network errors**: Check your internet connection

### Fallback Mode
If no LLM providers are available, the system falls back to pattern matching mode, which still provides basic functionality but with less intelligent responses.

## Model Performance

| Provider | Speed | Quality | Cost | Privacy |
|----------|-------|---------|------|---------|
| Ollama | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | Free | ⭐⭐⭐⭐⭐ |
| Groq | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | Free Tier | ⭐⭐⭐ |
| HuggingFace | ⭐⭐⭐ | ⭐⭐⭐ | Free Tier | ⭐⭐⭐ |

## Recommended Setup

For the best experience:

1. Install Ollama locally for primary use
2. Configure Groq as a backup for when Ollama is unavailable
3. Keep HuggingFace as a final fallback option

This gives you a robust, multi-layered setup with excellent performance and reliability.
