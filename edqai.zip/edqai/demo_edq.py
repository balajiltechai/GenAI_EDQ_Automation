#!/usr/bin/env python3
"""
EDQ Framework Demonstration Script
==================================

This script demonstrates the Enterprise Data Quality Framework functionality
including rule setup, validation, and reporting.
"""

import sys
import json
from pathlib import Path
from edq_framework import EDQFramework

def demo_edq_framework():
    """Demonstrate EDQ Framework capabilities"""
    print("🚀 EDQ Framework Demonstration")
    print("=" * 60)
    
    try:
        # Initialize the framework
        print("📋 Initializing EDQ Framework...")
        framework = EDQFramework("config/edq_config.yaml")
        print("✅ Framework initialized successfully")
        
        # List available datasets
        print("\n📂 Available Datasets:")
        datasets_response = framework._make_api_call('GET', 'datasets')
        datasets = datasets_response.get('datasets', [])
        
        for dataset in datasets:
            print(f"   ID: {dataset['id']} | {dataset['dataset_name']} ({dataset['fields_count']} fields)")
        
        if not datasets:
            print("   No datasets found. Please load sample data first.")
            return
        
        # Demonstrate rule setup for Employee Management dataset
        print(f"\n🔧 Setting up quality rules for Employee Management dataset...")
        
        # Apply rules from configuration file
        if Path("config/employee_rules.yaml").exists():
            results = framework.apply_rules_from_config("config/employee_rules.yaml")
            
            print(f"📊 Rule Setup Results:")
            print(f"   Total rules: {results['total_rules']}")
            print(f"   ✅ Successful: {results['successful_rules']}")
            print(f"   ❌ Failed: {results['failed_rules']}")
            
            # Show rule details
            print(f"\n📋 Rule Details:")
            for result in results['rule_results']:
                status_icon = "✅" if result['status'] == 'success' else "❌"
                print(f"   {status_icon} {result['rule_name']}")
                if result['status'] == 'failed':
                    print(f"      Error: {result['error']}")
        else:
            print("   Employee rules configuration not found")
        
        # Demonstrate dataset validation
        print(f"\n🔍 Validating dataset against quality rules...")
        dataset_id = 1  # Employee Management dataset
        
        try:
            dataset_info = framework.get_dataset_info(dataset_id)
            print(f"   Dataset: {dataset_info['dataset']['dataset_name']}")
            print(f"   Fields: {len(dataset_info['dataset']['fields'])}")
            
            # Perform validation
            validation_config = framework.config.get('validation', {})
            validation_results = framework.validate_dataset(dataset_id, validation_config)
            
            print(f"\n📊 Validation Results:")
            print(f"   Overall Status: {validation_results['overall_status']}")
            
            passed_fields = len([f for f in validation_results['field_validations'] if f['status'] == 'PASS'])
            total_fields = len(validation_results['field_validations'])
            
            print(f"   Field Summary: {passed_fields}/{total_fields} passed")
            
            # Show field validation details
            print(f"\n📋 Field Validation Details:")
            for field in validation_results['field_validations']:
                status_icon = "✅" if field['status'] == 'PASS' else "❌"
                rules_count = len(field['rules_applied'])
                print(f"   {status_icon} {field['field_name']} ({field['field_type']}) - {rules_count} rules")
                
                for violation in field.get('violations', []):
                    print(f"      ⚠️  {violation}")
        
        except Exception as e:
            print(f"   Validation error: {e}")
        
        # Generate quality report
        print(f"\n📊 Generating quality report...")
        try:
            report_file = "reports/demo_quality_report.json"
            Path("reports").mkdir(exist_ok=True)
            
            report = framework.generate_quality_report(dataset_id, report_file)
            
            print(f"   Report ID: {report['report_id']}")
            print(f"   Quality Score: {report['summary']['overall_score']:.1f}%")
            print(f"   💾 Report saved to: {report_file}")
            
        except Exception as e:
            print(f"   Report generation error: {e}")
        
        # Demonstrate API calls for rules
        print(f"\n🔧 Testing Data Quality Rules API...")
        try:
            # Get existing rules
            rules_response = framework._make_api_call('GET', 'data-quality-rules?dataset_id=1')
            rules = rules_response.get('rules', [])
            print(f"   Found {len(rules)} existing rules")
            
            for rule in rules[:3]:  # Show first 3 rules
                print(f"   📝 {rule['rule_type']} for {rule['field_name']} ({rule['severity']})")
            
        except Exception as e:
            print(f"   API call error: {e}")
        
        print(f"\n" + "=" * 60)
        print("🎉 EDQ Framework demonstration completed!")
        print("\n📖 Next Steps:")
        print("   1. Use the CLI: python edq_cli.py --help")
        print("   2. Create custom rule configurations")
        print("   3. Set up automated quality monitoring")
        print("   4. Integrate with your data pipelines")
        
    except Exception as e:
        print(f"❌ Demonstration failed: {e}")
        return 1
    
    return 0

if __name__ == "__main__":
    sys.exit(demo_edq_framework())
