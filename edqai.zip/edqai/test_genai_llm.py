#!/usr/bin/env python3
"""
GenAI LLM Assistant Test Script
Tests the integration of GenAI LLM models with the EDQ assistant.
"""

import requests
import json
import sys

def test_genai_llm_assistant():
    """Test the GenAI LLM assistant endpoints"""
    base_url = "http://localhost:5001/api/genai-llm"
    
    print("🧪 Testing GenAI LLM Assistant Integration\n")
    
    # Test 1: Check provider status
    print("1. Testing provider status...")
    try:
        response = requests.get(f"{base_url}/providers")
        if response.status_code == 200:
            data = response.json()
            print(f"   ✅ Active provider: {data.get('active_provider', 'none')}")
            
            providers = data.get('providers', {})
            for provider, details in providers.items():
                status = "✅ Available" if details.get('available', False) else "❌ Not available"
                print(f"   - {provider.upper()}: {status}")
        else:
            print(f"   ❌ Error: {response.status_code}")
            return False
    except Exception as e:
        print(f"   ❌ Error: {e}")
        return False
    
    # Test 2: Test chat functionality
    print("\n2. Testing chat functionality...")
    test_messages = [
        "Help me understand EDQ rules",
        "Create a validation rule for email field in Employee dataset",
        "Show me all datasets",
        "I want to delete a rule"
    ]
    
    for i, message in enumerate(test_messages, 1):
        print(f"   Test {i}: '{message}'")
        try:
            response = requests.post(
                f"{base_url}/chat",
                json={"message": message},
                headers={"Content-Type": "application/json"}
            )
            
            if response.status_code == 200:
                data = response.json()
                ai_response = data.get('ai_response', '')
                model_info = data.get('model_info', {})
                
                print(f"   ✅ Response received (length: {len(ai_response)})")
                print(f"   📡 Model: {model_info.get('provider', 'unknown')} - {model_info.get('model', 'unknown')}")
                
                # Check if response contains expected elements
                if 'parsed_result' in data and 'execution_result' in data:
                    intent = data.get('parsed_result', {}).get('intent', {})
                    action = intent.get('action', 'unknown')
                    confidence = intent.get('confidence', 'unknown')
                    print(f"   🎯 Intent: {action} (confidence: {confidence})")
                else:
                    print("   ⚠️  Missing expected response structure")
                    
            else:
                print(f"   ❌ Error: {response.status_code}")
                return False
                
        except Exception as e:
            print(f"   ❌ Error: {e}")
            return False
    
    # Test 3: Test rule description generation
    print("\n3. Testing rule description generation...")
    try:
        response = requests.post(
            f"{base_url}/generate-description",
            json={
                "field_name": "email",
                "rule_type": "FORMAT_VALIDATION",
                "severity": "HIGH"
            },
            headers={"Content-Type": "application/json"}
        )
        
        if response.status_code == 200:
            data = response.json()
            description = data.get('description', '')
            print(f"   ✅ Generated description: {description[:100]}...")
        else:
            print(f"   ❌ Error: {response.status_code}")
            return False
    except Exception as e:
        print(f"   ❌ Error: {e}")
        return False
    
    print("\n🎉 All tests passed! GenAI LLM assistant is working correctly.")
    return True

def main():
    """Main function"""
    print("GenAI LLM Assistant Test Suite")
    print("=" * 50)
    
    # Check if Flask app is running
    try:
        response = requests.get("http://localhost:5001/api/health")
        if response.status_code != 200:
            print("❌ Flask application is not running at localhost:5001")
            print("Please start the application with: python app.py")
            sys.exit(1)
    except requests.exceptions.ConnectionError:
        print("❌ Cannot connect to Flask application at localhost:5001")
        print("Please start the application with: python app.py")
        sys.exit(1)
    
    # Run tests
    success = test_genai_llm_assistant()
    
    if success:
        print("\n✅ GenAI LLM Assistant is fully functional!")
        print("\n🚀 Next steps:")
        print("1. Set up a free LLM provider (see GENAI_LLM_SETUP.md)")
        print("2. Access the chat interface: http://localhost:5001/genai-chat")
        print("3. Try natural language EDQ rule management!")
    else:
        print("\n❌ Some tests failed. Please check the application logs.")
        sys.exit(1)

if __name__ == "__main__":
    main()
