"""
Free AI-powered EDQ Assistant using Hugging Face Inference API
"""

import requests
import json
import os
from typing import Dict, Any, Optional
from flask import Blueprint, request, jsonify
from app import db
from app.models import Dataset, Field
from app.edq_models import DataQualityRule
from datetime import datetime
import uuid
import re

free_ai_bp = Blueprint('free_ai_assistant', __name__)

class FreeAIEDQAssistant:
    """Free AI-powered EDQ Assistant using Hugging Face Inference API"""
    
    def __init__(self):
        # Use Hugging Face's free inference API
        self.api_url = "https://api-inference.huggingface.co/models/microsoft/DialoGPT-medium"
        self.hf_token = os.getenv('HUGGINGFACE_API_TOKEN', '')
        
        # Fallback to local pattern matching if no API token
        self.use_local_processing = not self.hf_token
        
        # System instructions for rule management
        self.system_instructions = """
You are an intelligent EDQ (Enterprise Data Quality) assistant helping Product Managers manage data quality rules.

Your capabilities:
1. CREATE rules: Generate data validation rules for fields
2. UPDATE rules: Modify existing rule properties  
3. DELETE rules: Remove validation rules
4. VIEW rules: Display and analyze existing rules

Available rule types:
- NOT_NULL: Ensures field is not empty
- LENGTH_VALIDATION: Validates field length constraints
- NUMERIC_VALIDATION: Validates numeric data and ranges
- FORMAT_VALIDATION: Validates field format patterns (email, phone, etc.)
- DATE_VALIDATION: Validates date/time fields
- BOOLEAN_VALIDATION: Validates true/false values
- UNIQUENESS_VALIDATION: Ensures field values are unique
- RANGE_CHECK: Validates values within specified ranges

Severity levels: CRITICAL, HIGH, MEDIUM, LOW
"""

    def parse_user_message(self, message: str, context: Dict = None) -> Dict[str, Any]:
        """Parse user message and extract intent"""
        
        if self.use_local_processing:
            return self._parse_message_locally(message, context)
        else:
            return self._parse_message_with_hf_api(message, context)

    def _parse_message_locally(self, message: str, context: Dict = None) -> Dict[str, Any]:
        """Parse message using local pattern matching (free alternative)"""
        
        message_lower = message.lower()
        
        # Determine action intent
        action = self._extract_action(message_lower)
        
        # Extract entities
        dataset_name = self._extract_dataset(message_lower, context)
        field_name = self._extract_field(message_lower)
        rule_type = self._extract_rule_type(message_lower)
        severity = self._extract_severity(message_lower)
        
        # Generate response based on extracted information
        intent = {
            'action': action,
            'dataset_name': dataset_name,
            'field_name': field_name,
            'rule_type': rule_type,
            'severity': severity or 'MEDIUM',
            'confidence': 'high' if action != 'unknown' else 'low'
        }
        
        # Generate AI-like response
        response = self._generate_local_response(intent, message)
        
        # Check for missing information
        missing_info = self._check_missing_info(intent)
        
        # Generate suggestions
        suggestions = self._generate_suggestions(intent, context)
        
        return {
            'intent': intent,
            'response': response,
            'missing_info': missing_info,
            'suggestions': suggestions,
            'model_used': 'local_pattern_matching'
        }

    def _parse_message_with_hf_api(self, message: str, context: Dict = None) -> Dict[str, Any]:
        """Parse message using Hugging Face API (when token available)"""
        
        try:
            headers = {"Authorization": f"Bearer {self.hf_token}"}
            
            # Create a prompt for intent extraction
            prompt = f"""
            {self.system_instructions}
            
            User message: "{message}"
            
            Extract the following information and respond in JSON format:
            - action: create, update, delete, view, or help
            - dataset_name: name of the dataset mentioned
            - field_name: name of the field mentioned
            - rule_type: type of validation rule
            - severity: CRITICAL, HIGH, MEDIUM, or LOW
            
            Response:"""
            
            payload = {
                "inputs": prompt,
                "parameters": {
                    "max_new_tokens": 200,
                    "temperature": 0.3,
                    "return_full_text": False
                }
            }
            
            response = requests.post(self.api_url, headers=headers, json=payload)
            
            if response.status_code == 200:
                result = response.json()
                # Process HF API response
                return self._process_hf_response(result, message, context)
            else:
                # Fallback to local processing
                return self._parse_message_locally(message, context)
                
        except Exception as e:
            print(f"HF API error: {e}")
            # Fallback to local processing
            return self._parse_message_locally(message, context)

    def _extract_action(self, message: str) -> str:
        """Extract action from message"""
        create_keywords = ['create', 'add', 'setup', 'set up', 'new', 'make', 'establish']
        update_keywords = ['update', 'modify', 'change', 'edit', 'alter']
        delete_keywords = ['delete', 'remove', 'drop', 'eliminate']
        view_keywords = ['show', 'view', 'list', 'display', 'see', 'get']
        help_keywords = ['help', 'how', 'what', 'explain']
        
        if any(keyword in message for keyword in create_keywords):
            return 'create'
        elif any(keyword in message for keyword in update_keywords):
            return 'update'
        elif any(keyword in message for keyword in delete_keywords):
            return 'delete'
        elif any(keyword in message for keyword in view_keywords):
            return 'view'
        elif any(keyword in message for keyword in help_keywords):
            return 'help'
        else:
            return 'unknown'

    def _extract_dataset(self, message: str, context: Dict = None) -> Optional[str]:
        """Extract dataset name from message"""
        # Look for dataset patterns
        dataset_patterns = [
            r'dataset[:\s]+([a-zA-Z\s]+)',
            r'for[:\s]+([a-zA-Z\s]+)[:\s]+dataset',
            r'in[:\s]+([a-zA-Z\s]+)[:\s]+dataset',
            r'([a-zA-Z]+)[:\s]+dataset'
        ]
        
        for pattern in dataset_patterns:
            match = re.search(pattern, message, re.IGNORECASE)
            if match:
                return match.group(1).strip()
        
        # Check against available datasets if context provided
        if context and 'datasets' in context:
            for dataset in context['datasets']:
                if dataset['dataset_name'].lower() in message:
                    return dataset['dataset_name']
        
        return None

    def _extract_field(self, message: str) -> Optional[str]:
        """Extract field name from message"""
        field_patterns = [
            r'field[:\s]+([a-zA-Z_]+)',
            r'([a-zA-Z_]+)[:\s]+field',
            r'for[:\s]+([a-zA-Z_]+)[:\s]+field'
        ]
        
        for pattern in field_patterns:
            match = re.search(pattern, message, re.IGNORECASE)
            if match:
                return match.group(1).strip()
        
        # Look for common field names
        common_fields = ['email', 'phone', 'name', 'id', 'age', 'date', 'price', 'salary']
        for field in common_fields:
            if field in message:
                return field
        
        return None

    def _extract_rule_type(self, message: str) -> Optional[str]:
        """Extract rule type from message"""
        rule_mappings = {
            'not null': 'NOT_NULL',
            'required': 'NOT_NULL',
            'mandatory': 'NOT_NULL',
            'length': 'LENGTH_VALIDATION',
            'size': 'LENGTH_VALIDATION',
            'email': 'FORMAT_VALIDATION',
            'format': 'FORMAT_VALIDATION',
            'pattern': 'FORMAT_VALIDATION',
            'phone': 'FORMAT_VALIDATION',
            'numeric': 'NUMERIC_VALIDATION',
            'number': 'NUMERIC_VALIDATION',
            'integer': 'NUMERIC_VALIDATION',
            'decimal': 'NUMERIC_VALIDATION',
            'date': 'DATE_VALIDATION',
            'time': 'DATE_VALIDATION',
            'timestamp': 'DATE_VALIDATION',
            'boolean': 'BOOLEAN_VALIDATION',
            'true': 'BOOLEAN_VALIDATION',
            'false': 'BOOLEAN_VALIDATION',
            'unique': 'UNIQUENESS_VALIDATION',
            'distinct': 'UNIQUENESS_VALIDATION',
            'range': 'RANGE_CHECK'
        }
        
        for keyword, rule_type in rule_mappings.items():
            if keyword in message:
                return rule_type
        
        return None

    def _extract_severity(self, message: str) -> Optional[str]:
        """Extract severity from message"""
        severities = ['critical', 'high', 'medium', 'low']
        
        for severity in severities:
            if severity in message:
                return severity.upper()
        
        # Look for importance indicators
        if any(word in message for word in ['important', 'crucial', 'essential']):
            return 'HIGH'
        elif any(word in message for word in ['optional', 'nice', 'prefer']):
            return 'LOW'
        
        return None

    def _generate_local_response(self, intent: Dict, original_message: str) -> str:
        """Generate AI-like response based on intent"""
        
        action = intent.get('action')
        dataset = intent.get('dataset_name')
        field = intent.get('field_name')
        rule_type = intent.get('rule_type')
        severity = intent.get('severity')
        
        if action == 'create':
            if dataset and field and rule_type:
                return f"I'll create a {rule_type.replace('_', ' ').lower()} rule for the {field} field in the {dataset} dataset with {severity} severity. This will ensure data quality standards are maintained."
            else:
                return "I'd be happy to help you create a data quality rule! I need a bit more information to proceed effectively."
        
        elif action == 'update':
            if dataset and field:
                return f"I'll help you update the validation rule for the {field} field in the {dataset} dataset. What changes would you like to make?"
            else:
                return "I can help you update an existing rule. Could you specify which dataset and field you'd like to modify?"
        
        elif action == 'delete':
            if dataset and field:
                return f"I'll remove the validation rule for the {field} field in the {dataset} dataset. Please confirm this action as it cannot be undone."
            else:
                return "I can help you delete a validation rule. Which dataset and field rule would you like to remove?"
        
        elif action == 'view':
            if dataset:
                return f"I'll show you all the data quality rules for the {dataset} dataset. Let me retrieve that information for you."
            else:
                return "I'll display the data quality rules. Would you like to see rules for a specific dataset or all datasets?"
        
        elif action == 'help':
            return "I'm here to help you manage data quality rules! You can ask me to create, update, delete, or view validation rules. Just describe what you need in natural language."
        
        else:
            return "I understand you want to work with data quality rules. Could you be more specific about what you'd like to do? For example, 'create email validation for customer dataset' or 'show all rules'."

    def _check_missing_info(self, intent: Dict) -> list:
        """Check what information is missing for the operation"""
        missing = []
        action = intent.get('action')
        
        if action in ['create', 'update', 'delete']:
            if not intent.get('dataset_name'):
                missing.append("Dataset name")
            if not intent.get('field_name'):
                missing.append("Field name")
            if action == 'create' and not intent.get('rule_type'):
                missing.append("Rule type (e.g., email validation, not null, etc.)")
        
        return missing

    def _generate_suggestions(self, intent: Dict, context: Dict = None) -> list:
        """Generate helpful suggestions"""
        suggestions = []
        action = intent.get('action')
        
        if action == 'create':
            suggestions.extend([
                "Create email validation for customer dataset",
                "Add not null rule for employee_id field",
                "Set up length validation for product_name"
            ])
        elif action == 'view':
            suggestions.extend([
                "Show all rules for Customer dataset",
                "Display critical rules only",
                "List all datasets with rule counts"
            ])
        elif action == 'help':
            suggestions.extend([
                "How to create validation rules?",
                "What rule types are available?",
                "Show me some examples"
            ])
        else:
            suggestions.extend([
                "Create a validation rule",
                "View existing rules",
                "Help with data quality"
            ])
        
        return suggestions[:3]  # Limit to 3 suggestions

    def execute_rule_operation(self, intent: Dict) -> Dict[str, Any]:
        """Execute the rule operation based on parsed intent"""
        
        action = intent.get('action')
        dataset_name = intent.get('dataset_name')
        field_name = intent.get('field_name')
        rule_type = intent.get('rule_type')
        severity = intent.get('severity', 'MEDIUM')
        
        try:
            if action == 'create':
                return self._create_rule(dataset_name, field_name, rule_type, severity)
            elif action == 'update':
                return self._update_rule(dataset_name, field_name, rule_type, severity)
            elif action == 'delete':
                return self._delete_rule(dataset_name, field_name, rule_type)
            elif action == 'view':
                return self._view_rules(dataset_name)
            else:
                return {'success': False, 'error': 'Unknown action'}
                
        except Exception as e:
            return {'success': False, 'error': f'Operation failed: {str(e)}'}

    def _create_rule(self, dataset_name: str, field_name: str, rule_type: str, severity: str) -> Dict[str, Any]:
        """Create a new data quality rule"""
        
        if not all([dataset_name, field_name, rule_type]):
            return {'success': False, 'error': 'Missing required information for rule creation'}
        
        # Find dataset
        dataset = Dataset.query.filter_by(dataset_name=dataset_name).first()
        if not dataset:
            return {'success': False, 'error': f'Dataset "{dataset_name}" not found'}
        
        # Check if field exists
        field = Field.query.filter_by(dataset_id=dataset.id, field_name=field_name).first()
        if not field:
            return {'success': False, 'error': f'Field "{field_name}" not found in dataset "{dataset_name}"'}
        
        # Check for existing rule
        existing_rule = DataQualityRule.query.filter_by(
            dataset_id=dataset.id,
            field_name=field_name,
            rule_type=rule_type
        ).first()
        
        if existing_rule:
            return {'success': False, 'error': f'Rule of type {rule_type} already exists for field {field_name}'}
        
        # Create new rule
        new_rule = DataQualityRule(
            id=str(uuid.uuid4()),
            dataset_id=dataset.id,
            field_name=field_name,
            rule_type=rule_type,
            rule_description=self._generate_rule_description(field_name, rule_type, severity),
            severity=severity,
            is_active=True,
            created_at=datetime.utcnow(),
            updated_at=datetime.utcnow()
        )
        
        db.session.add(new_rule)
        db.session.commit()
        
        return {
            'success': True,
            'message': f'Successfully created {rule_type.replace("_", " ").lower()} rule for {field_name} field',
            'rule_id': new_rule.id
        }

    def _update_rule(self, dataset_name: str, field_name: str, rule_type: str, severity: str) -> Dict[str, Any]:
        """Update an existing data quality rule"""
        
        if not all([dataset_name, field_name]):
            return {'success': False, 'error': 'Missing required information for rule update'}
        
        # Find dataset
        dataset = Dataset.query.filter_by(dataset_name=dataset_name).first()
        if not dataset:
            return {'success': False, 'error': f'Dataset "{dataset_name}" not found'}
        
        # Find existing rule
        query = DataQualityRule.query.filter_by(dataset_id=dataset.id, field_name=field_name)
        if rule_type:
            query = query.filter_by(rule_type=rule_type)
        
        rule = query.first()
        if not rule:
            return {'success': False, 'error': f'No rule found for field "{field_name}"'}
        
        # Update rule
        if severity:
            rule.severity = severity
        rule.updated_at = datetime.utcnow()
        
        db.session.commit()
        
        return {
            'success': True,
            'message': f'Successfully updated rule for {field_name} field',
            'rule_id': rule.id
        }

    def _delete_rule(self, dataset_name: str, field_name: str, rule_type: str = None) -> Dict[str, Any]:
        """Delete a data quality rule"""
        
        if not all([dataset_name, field_name]):
            return {'success': False, 'error': 'Missing required information for rule deletion'}
        
        # Find dataset
        dataset = Dataset.query.filter_by(dataset_name=dataset_name).first()
        if not dataset:
            return {'success': False, 'error': f'Dataset "{dataset_name}" not found'}
        
        # Find rule to delete
        query = DataQualityRule.query.filter_by(dataset_id=dataset.id, field_name=field_name)
        if rule_type:
            query = query.filter_by(rule_type=rule_type)
        
        rule = query.first()
        if not rule:
            return {'success': False, 'error': f'No rule found for field "{field_name}"'}
        
        # Delete rule
        db.session.delete(rule)
        db.session.commit()
        
        return {
            'success': True,
            'message': f'Successfully deleted rule for {field_name} field'
        }

    def _view_rules(self, dataset_name: str = None) -> Dict[str, Any]:
        """View data quality rules"""
        
        if dataset_name:
            # View rules for specific dataset
            dataset = Dataset.query.filter_by(dataset_name=dataset_name).first()
            if not dataset:
                return {'success': False, 'error': f'Dataset "{dataset_name}" not found'}
            
            rules = DataQualityRule.query.filter_by(dataset_id=dataset.id).all()
            
            rules_data = []
            for rule in rules:
                rules_data.append({
                    'id': rule.id,
                    'field_name': rule.field_name,
                    'rule_type': rule.rule_type,
                    'rule_description': rule.rule_description,
                    'severity': rule.severity,
                    'is_active': rule.is_active,
                    'created_at': rule.created_at.isoformat() if rule.created_at else None
                })
            
            return {
                'success': True,
                'dataset_name': dataset_name,
                'rules': rules_data,
                'total_count': len(rules_data)
            }
        else:
            # View all rules
            all_rules = DataQualityRule.query.all()
            datasets = Dataset.query.all()
            
            rules_data = []
            for rule in all_rules:
                dataset = next((d for d in datasets if d.id == rule.dataset_id), None)
                rules_data.append({
                    'id': rule.id,
                    'dataset_name': dataset.dataset_name if dataset else 'Unknown',
                    'field_name': rule.field_name,
                    'rule_type': rule.rule_type,
                    'rule_description': rule.rule_description,
                    'severity': rule.severity,
                    'is_active': rule.is_active
                })
            
            return {
                'success': True,
                'rules': rules_data,
                'total_count': len(rules_data)
            }

    def _generate_rule_description(self, field_name: str, rule_type: str, severity: str) -> str:
        """Generate a human-readable rule description"""
        
        rule_descriptions = {
            'NOT_NULL': f'Ensures {field_name} field is not empty or null',
            'LENGTH_VALIDATION': f'Validates the length of {field_name} field',
            'FORMAT_VALIDATION': f'Validates the format pattern of {field_name} field',
            'NUMERIC_VALIDATION': f'Ensures {field_name} contains valid numeric values',
            'DATE_VALIDATION': f'Validates {field_name} as a proper date/time value',
            'BOOLEAN_VALIDATION': f'Ensures {field_name} contains valid boolean values',
            'UNIQUENESS_VALIDATION': f'Ensures {field_name} values are unique across records',
            'RANGE_CHECK': f'Validates {field_name} values are within acceptable range'
        }
        
        base_description = rule_descriptions.get(rule_type, f'Validates {field_name} field')
        return f"{base_description} ({severity} severity)"


# Initialize the Free AI assistant
free_ai_assistant = FreeAIEDQAssistant()

@free_ai_bp.route('/chat', methods=['POST'])
def free_ai_chat():
    """Free AI-powered chat endpoint"""
    try:
        data = request.get_json()
        if not data or 'message' not in data:
            return jsonify({'error': 'Message is required'}), 400

        message = data['message'].strip()
        if not message:
            return jsonify({'error': 'Message cannot be empty'}), 400

        # Get context information
        datasets = Dataset.query.all()
        context = {
            'datasets': [{'id': d.id, 'dataset_name': d.dataset_name} for d in datasets]
        }

        # Parse message using Free AI
        parsed_result = free_ai_assistant.parse_user_message(message, context)
        
        # Execute the operation if intent is clear
        result = {'success': False, 'message': 'No operation performed'}
        intent = parsed_result.get('intent', {})
        
        if intent.get('confidence') in ['high', 'medium'] and intent.get('action') in ['create', 'update', 'delete', 'view']:
            result = free_ai_assistant.execute_rule_operation(intent)

        response = {
            'parsed_result': parsed_result,
            'execution_result': result,
            'ai_response': parsed_result.get('response', ''),
            'suggestions': parsed_result.get('suggestions', []),
            'missing_info': parsed_result.get('missing_info', []),
            'model_info': {
                'type': 'free_ai',
                'processing': 'local_pattern_matching' if free_ai_assistant.use_local_processing else 'huggingface_api'
            }
        }

        return jsonify(response), 200

    except Exception as e:
        return jsonify({'error': f'Server error: {str(e)}'}), 500

@free_ai_bp.route('/generate-description', methods=['POST'])
def generate_rule_description():
    """Generate rule description using Free AI"""
    try:
        data = request.get_json()
        field_name = data.get('field_name')
        rule_type = data.get('rule_type')
        severity = data.get('severity', 'MEDIUM')

        if not field_name or not rule_type:
            return jsonify({'error': 'field_name and rule_type are required'}), 400

        description = free_ai_assistant._generate_rule_description(field_name, rule_type, severity)
        
        return jsonify({
            'description': description,
            'field_name': field_name,
            'rule_type': rule_type,
            'severity': severity,
            'model_info': 'free_ai_generator'
        }), 200

    except Exception as e:
        return jsonify({'error': f'Error generating description: {str(e)}'}), 500
