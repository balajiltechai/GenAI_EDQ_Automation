"""
GenAI EDQ Assistant using Free LLM Models
Supports: Ollama (local), Groq (free API), HuggingFace Transformers
"""

import requests
import json
import os
from typing import Dict, Any, Optional, List
from flask import Blueprint, request, jsonify
from app import db
from app.models import Dataset, Field
from app.edq_models import DataQualityRule
from datetime import datetime
import uuid
import re

genai_llm_bp = Blueprint('genai_llm_assistant', __name__)

class GenAIEDQAssistant:
    """GenAI EDQ Assistant using Free LLM Models"""
    
    def __init__(self):
        # Configuration for different free LLM providers
        self.providers = {
            'ollama': {
                'url': 'http://localhost:11434/api/generate',
                'model': 'llama3.2:3b',  # Free local model
                'available': self._check_ollama_availability()
            },
            'groq': {
                'url': 'https://api.groq.com/openai/v1/chat/completions',
                'model': 'llama3-8b-8192',  # Free Groq model
                'api_key': os.getenv('GROQ_API_KEY', ''),
                'available': bool(os.getenv('GROQ_API_KEY', ''))
            },
            'huggingface': {
                'url': 'https://api-inference.huggingface.co/models/microsoft/DialoGPT-large',
                'model': 'microsoft/DialoGPT-large',
                'api_key': os.getenv('HUGGINGFACE_API_TOKEN', ''),
                'available': bool(os.getenv('HUGGINGFACE_API_TOKEN', ''))
            }
        }
        
        # Select the best available provider
        self.active_provider = self._select_best_provider()
        
        # System prompt for EDQ operations
        self.system_prompt = """You are an intelligent EDQ (Enterprise Data Quality) assistant helping Product Managers manage data quality rules using natural language.

Your capabilities:
1. CREATE rules: Generate data validation rules for fields
2. UPDATE rules: Modify existing rule properties
3. DELETE rules: Remove validation rules
4. VIEW rules: Display and analyze existing rules

Available rule types:
- NOT_NULL: Ensures field is not empty
- LENGTH_VALIDATION: Validates field length constraints
- NUMERIC_VALIDATION: Validates numeric data and ranges
- FORMAT_VALIDATION: Validates field format patterns (email, phone, etc.)
- DATE_VALIDATION: Validates date/time fields
- BOOLEAN_VALIDATION: Validates true/false values
- UNIQUENESS_VALIDATION: Ensures field values are unique
- RANGE_CHECK: Validates values within specified ranges

Severity levels: CRITICAL, HIGH, MEDIUM, LOW

IMPORTANT: Always respond with a JSON object containing:
{
    "intent": {
        "action": "create|update|delete|view|help",
        "dataset_name": "extracted dataset name or null",
        "field_name": "extracted field name or null", 
        "rule_type": "extracted rule type or null",
        "severity": "CRITICAL|HIGH|MEDIUM|LOW or null",
        "confidence": "high|medium|low"
    },
    "response": "Natural language response to user",
    "missing_info": ["list of missing required information"],
    "suggestions": ["list of helpful suggestions"],
    "reasoning": "Brief explanation of your understanding"
}

Analyze the user's message and extract the intent while providing helpful, conversational responses."""

    def _check_ollama_availability(self) -> bool:
        """Check if Ollama is running locally"""
        try:
            response = requests.get('http://localhost:11434/api/tags', timeout=2)
            return response.status_code == 200
        except:
            return False

    def _select_best_provider(self) -> str:
        """Select the best available LLM provider"""
        # Priority: Ollama (local) > Groq (fast free API) > HuggingFace (free API)
        if self.providers['ollama']['available']:
            return 'ollama'
        elif self.providers['groq']['available']:
            return 'groq'
        elif self.providers['huggingface']['available']:
            return 'huggingface'
        else:
            return 'none'

    def parse_user_message(self, message: str, context: Dict = None) -> Dict[str, Any]:
        """Parse user message using GenAI LLM"""
        
        if self.active_provider == 'none':
            return self._fallback_pattern_matching(message, context)
        
        try:
            # Prepare context information
            context_str = ""
            if context and 'datasets' in context:
                datasets_list = [d['dataset_name'] for d in context['datasets']]
                context_str = f"\nAvailable datasets: {', '.join(datasets_list)}"
            
            # Create the prompt
            user_prompt = f"""User message: "{message}"{context_str}

Please analyze this message and extract the intent for data quality rule management."""

            # Call the selected LLM provider
            if self.active_provider == 'ollama':
                result = self._call_ollama(user_prompt)
            elif self.active_provider == 'groq':
                result = self._call_groq(user_prompt)
            elif self.active_provider == 'huggingface':
                result = self._call_huggingface(user_prompt)
            else:
                return self._fallback_pattern_matching(message, context)
            
            # Parse the LLM response
            return self._parse_llm_response(result, message, context)
            
        except Exception as e:
            print(f"LLM error: {e}")
            # Fallback to pattern matching
            return self._fallback_pattern_matching(message, context)

    def _call_ollama(self, prompt: str) -> str:
        """Call Ollama local LLM"""
        payload = {
            "model": self.providers['ollama']['model'],
            "prompt": f"{self.system_prompt}\n\n{prompt}",
            "stream": False,
            "options": {
                "temperature": 0.3,
                "top_p": 0.9
            }
        }
        
        response = requests.post(
            self.providers['ollama']['url'],
            json=payload,
            timeout=30
        )
        
        if response.status_code == 200:
            return response.json().get('response', '')
        else:
            raise Exception(f"Ollama API error: {response.status_code}")

    def _call_groq(self, prompt: str) -> str:
        """Call Groq free API"""
        headers = {
            "Authorization": f"Bearer {self.providers['groq']['api_key']}",
            "Content-Type": "application/json"
        }
        
        payload = {
            "model": self.providers['groq']['model'],
            "messages": [
                {"role": "system", "content": self.system_prompt},
                {"role": "user", "content": prompt}
            ],
            "temperature": 0.3,
            "max_tokens": 1000
        }
        
        response = requests.post(
            self.providers['groq']['url'],
            headers=headers,
            json=payload,
            timeout=30
        )
        
        if response.status_code == 200:
            return response.json()['choices'][0]['message']['content']
        else:
            raise Exception(f"Groq API error: {response.status_code}")

    def _call_huggingface(self, prompt: str) -> str:
        """Call HuggingFace Inference API"""
        headers = {
            "Authorization": f"Bearer {self.providers['huggingface']['api_key']}"
        }
        
        payload = {
            "inputs": f"{self.system_prompt}\n\n{prompt}",
            "parameters": {
                "max_new_tokens": 500,
                "temperature": 0.3,
                "return_full_text": False
            }
        }
        
        response = requests.post(
            self.providers['huggingface']['url'],
            headers=headers,
            json=payload,
            timeout=30
        )
        
        if response.status_code == 200:
            result = response.json()
            if isinstance(result, list) and len(result) > 0:
                return result[0].get('generated_text', '')
            return str(result)
        else:
            raise Exception(f"HuggingFace API error: {response.status_code}")

    def _parse_llm_response(self, llm_response: str, original_message: str, context: Dict = None) -> Dict[str, Any]:
        """Parse LLM response to extract structured data"""
        
        try:
            # Try to extract JSON from the response
            json_match = re.search(r'\{.*\}', llm_response, re.DOTALL)
            if json_match:
                parsed_json = json.loads(json_match.group(0))
                
                # Validate and clean the parsed response
                result = {
                    'intent': parsed_json.get('intent', {}),
                    'response': parsed_json.get('response', ''),
                    'missing_info': parsed_json.get('missing_info', []),
                    'suggestions': parsed_json.get('suggestions', []),
                    'reasoning': parsed_json.get('reasoning', ''),
                    'model_used': self.active_provider,
                    'llm_raw_response': llm_response
                }
                
                # Ensure intent has required fields
                intent = result['intent']
                intent.setdefault('action', self._extract_action_fallback(original_message))
                intent.setdefault('confidence', 'medium')
                
                return result
            else:
                # If no JSON found, extract information manually
                return self._extract_from_text_response(llm_response, original_message, context)
                
        except json.JSONDecodeError:
            # Fallback to text parsing
            return self._extract_from_text_response(llm_response, original_message, context)

    def _extract_from_text_response(self, text_response: str, original_message: str, context: Dict = None) -> Dict[str, Any]:
        """Extract information from free-form text response"""
        
        # Use pattern matching to extract intent from LLM text response
        action = self._extract_action_fallback(original_message)
        
        # Try to find mentioned datasets and fields in the response
        dataset_name = self._find_dataset_in_text(text_response, context)
        field_name = self._find_field_in_text(text_response)
        rule_type = self._find_rule_type_in_text(text_response)
        severity = self._find_severity_in_text(text_response)
        
        intent = {
            'action': action,
            'dataset_name': dataset_name,
            'field_name': field_name,
            'rule_type': rule_type,
            'severity': severity,
            'confidence': 'medium'
        }
        
        # Generate missing info
        missing_info = []
        if action in ['create', 'update', 'delete']:
            if not dataset_name:
                missing_info.append("Dataset name")
            if not field_name:
                missing_info.append("Field name")
            if action == 'create' and not rule_type:
                missing_info.append("Rule type")
        
        return {
            'intent': intent,
            'response': text_response,
            'missing_info': missing_info,
            'suggestions': self._generate_suggestions(intent),
            'reasoning': f'Extracted from {self.active_provider} LLM response',
            'model_used': self.active_provider,
            'llm_raw_response': text_response
        }

    def _extract_action_fallback(self, message: str) -> str:
        """Fallback action extraction using keywords"""
        message_lower = message.lower()
        
        if any(word in message_lower for word in ['create', 'add', 'setup', 'new', 'make']):
            return 'create'
        elif any(word in message_lower for word in ['update', 'modify', 'change', 'edit']):
            return 'update'
        elif any(word in message_lower for word in ['delete', 'remove', 'drop']):
            return 'delete'
        elif any(word in message_lower for word in ['show', 'view', 'list', 'display']):
            return 'view'
        elif any(word in message_lower for word in ['help', 'how', 'what']):
            return 'help'
        else:
            return 'unknown'

    def _find_dataset_in_text(self, text: str, context: Dict = None) -> Optional[str]:
        """Find dataset name in text"""
        # Check against available datasets if context provided
        if context and 'datasets' in context:
            for dataset in context['datasets']:
                if dataset['dataset_name'].lower() in text.lower():
                    return dataset['dataset_name']
        
        # Pattern matching for dataset mentions
        dataset_patterns = [
            r'dataset[:\s]+([a-zA-Z\s]+)',
            r'([a-zA-Z]+)[:\s]+dataset'
        ]
        
        for pattern in dataset_patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                return match.group(1).strip()
        
        return None

    def _find_field_in_text(self, text: str) -> Optional[str]:
        """Find field name in text"""
        field_patterns = [
            r'field[:\s]+([a-zA-Z_]+)',
            r'([a-zA-Z_]+)[:\s]+field'
        ]
        
        for pattern in field_patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                return match.group(1).strip()
        
        # Look for common field names
        common_fields = ['email', 'phone', 'name', 'id', 'age', 'date', 'price', 'salary']
        for field in common_fields:
            if field in text.lower():
                return field
        
        return None

    def _find_rule_type_in_text(self, text: str) -> Optional[str]:
        """Find rule type in text"""
        rule_mappings = {
            'not null': 'NOT_NULL',
            'required': 'NOT_NULL',
            'email': 'FORMAT_VALIDATION',
            'format': 'FORMAT_VALIDATION',
            'length': 'LENGTH_VALIDATION',
            'numeric': 'NUMERIC_VALIDATION',
            'date': 'DATE_VALIDATION',
            'unique': 'UNIQUENESS_VALIDATION',
            'range': 'RANGE_CHECK'
        }
        
        text_lower = text.lower()
        for keyword, rule_type in rule_mappings.items():
            if keyword in text_lower:
                return rule_type
        
        return None

    def _find_severity_in_text(self, text: str) -> Optional[str]:
        """Find severity in text"""
        severities = ['critical', 'high', 'medium', 'low']
        
        text_lower = text.lower()
        for severity in severities:
            if severity in text_lower:
                return severity.upper()
        
        return None

    def _generate_suggestions(self, intent: Dict) -> List[str]:
        """Generate helpful suggestions based on intent"""
        action = intent.get('action')
        
        if action == 'create':
            return [
                "Create email validation for customer dataset",
                "Add not null rule for employee_id field",
                "Set up length validation for product_name"
            ]
        elif action == 'view':
            return [
                "Show all rules for Customer dataset",
                "Display critical rules only", 
                "List all datasets with rule counts"
            ]
        elif action == 'help':
            return [
                "How to create validation rules?",
                "What rule types are available?",
                "Show me some examples"
            ]
        else:
            return [
                "Create a validation rule",
                "View existing rules",
                "Help with data quality"
            ]

    def _fallback_pattern_matching(self, message: str, context: Dict = None) -> Dict[str, Any]:
        """Fallback to simple pattern matching when no LLM is available"""
        
        action = self._extract_action_fallback(message)
        dataset_name = self._find_dataset_in_text(message, context)
        field_name = self._find_field_in_text(message)
        rule_type = self._find_rule_type_in_text(message)
        severity = self._find_severity_in_text(message) or 'MEDIUM'
        
        intent = {
            'action': action,
            'dataset_name': dataset_name,
            'field_name': field_name,
            'rule_type': rule_type,
            'severity': severity,
            'confidence': 'medium' if action != 'unknown' else 'low'
        }
        
        # Generate response
        if action == 'create' and dataset_name and field_name:
            response = f"I'll create a {rule_type or 'validation'} rule for the {field_name} field in the {dataset_name} dataset with {severity} severity."
        elif action == 'view':
            response = f"I'll show you the data quality rules" + (f" for the {dataset_name} dataset" if dataset_name else "") + "."
        else:
            response = "I understand you want to manage data quality rules. Could you provide more details about what you'd like to do?"
        
        # Check missing info
        missing_info = []
        if action in ['create', 'update', 'delete']:
            if not dataset_name:
                missing_info.append("Dataset name")
            if not field_name:
                missing_info.append("Field name")
            if action == 'create' and not rule_type:
                missing_info.append("Rule type")
        
        return {
            'intent': intent,
            'response': response,
            'missing_info': missing_info,
            'suggestions': self._generate_suggestions(intent),
            'reasoning': 'Pattern matching fallback (no LLM available)',
            'model_used': 'pattern_matching'
        }

    def execute_rule_operation(self, intent: Dict) -> Dict[str, Any]:
        """Execute the rule operation based on parsed intent"""
        
        action = intent.get('action')
        dataset_name = intent.get('dataset_name')
        field_name = intent.get('field_name')
        rule_type = intent.get('rule_type')
        severity = intent.get('severity', 'MEDIUM')
        
        try:
            if action == 'create':
                return self._create_rule(dataset_name, field_name, rule_type, severity)
            elif action == 'update':
                return self._update_rule(dataset_name, field_name, rule_type, severity)
            elif action == 'delete':
                return self._delete_rule(dataset_name, field_name, rule_type)
            elif action == 'view':
                return self._view_rules(dataset_name)
            else:
                return {'success': False, 'error': 'Unknown action'}
                
        except Exception as e:
            return {'success': False, 'error': f'Operation failed: {str(e)}'}

    def _create_rule(self, dataset_name: str, field_name: str, rule_type: str, severity: str) -> Dict[str, Any]:
        """Create a new data quality rule"""
        
        if not all([dataset_name, field_name, rule_type]):
            return {'success': False, 'error': 'Missing required information for rule creation'}
        
        # Find dataset
        dataset = Dataset.query.filter_by(dataset_name=dataset_name).first()
        if not dataset:
            return {'success': False, 'error': f'Dataset "{dataset_name}" not found'}
        
        # Check if field exists
        field = Field.query.filter_by(dataset_id=dataset.id, field_name=field_name).first()
        if not field:
            return {'success': False, 'error': f'Field "{field_name}" not found in dataset "{dataset_name}"'}
        
        # Check for existing rule
        existing_rule = DataQualityRule.query.filter_by(
            dataset_id=dataset.id,
            field_name=field_name,
            rule_type=rule_type
        ).first()
        
        if existing_rule:
            return {'success': False, 'error': f'Rule of type {rule_type} already exists for field {field_name}'}
        
        # Create new rule
        new_rule = DataQualityRule(
            id=str(uuid.uuid4()),
            dataset_id=dataset.id,
            field_name=field_name,
            rule_type=rule_type,
            rule_description=self._generate_rule_description(field_name, rule_type, severity),
            severity=severity,
            is_active=True,
            created_at=datetime.utcnow(),
            updated_at=datetime.utcnow()
        )
        
        db.session.add(new_rule)
        db.session.commit()
        
        return {
            'success': True,
            'message': f'Successfully created {rule_type.replace("_", " ").lower()} rule for {field_name} field',
            'rule_id': new_rule.id
        }

    def _update_rule(self, dataset_name: str, field_name: str, rule_type: str, severity: str) -> Dict[str, Any]:
        """Update an existing data quality rule"""
        
        if not all([dataset_name, field_name]):
            return {'success': False, 'error': 'Missing required information for rule update'}
        
        # Find dataset
        dataset = Dataset.query.filter_by(dataset_name=dataset_name).first()
        if not dataset:
            return {'success': False, 'error': f'Dataset "{dataset_name}" not found'}
        
        # Find existing rule
        query = DataQualityRule.query.filter_by(dataset_id=dataset.id, field_name=field_name)
        if rule_type:
            query = query.filter_by(rule_type=rule_type)
        
        rule = query.first()
        if not rule:
            return {'success': False, 'error': f'No rule found for field "{field_name}"'}
        
        # Update rule
        if severity:
            rule.severity = severity
        rule.updated_at = datetime.utcnow()
        
        db.session.commit()
        
        return {
            'success': True,
            'message': f'Successfully updated rule for {field_name} field',
            'rule_id': rule.id
        }

    def _delete_rule(self, dataset_name: str, field_name: str, rule_type: str = None) -> Dict[str, Any]:
        """Delete a data quality rule"""
        
        if not all([dataset_name, field_name]):
            return {'success': False, 'error': 'Missing required information for rule deletion'}
        
        # Find dataset
        dataset = Dataset.query.filter_by(dataset_name=dataset_name).first()
        if not dataset:
            return {'success': False, 'error': f'Dataset "{dataset_name}" not found'}
        
        # Find rule to delete
        query = DataQualityRule.query.filter_by(dataset_id=dataset.id, field_name=field_name)
        if rule_type:
            query = query.filter_by(rule_type=rule_type)
        
        rule = query.first()
        if not rule:
            return {'success': False, 'error': f'No rule found for field "{field_name}"'}
        
        # Delete rule
        db.session.delete(rule)
        db.session.commit()
        
        return {
            'success': True,
            'message': f'Successfully deleted rule for {field_name} field'
        }

    def _view_rules(self, dataset_name: str = None) -> Dict[str, Any]:
        """View data quality rules"""
        
        if dataset_name:
            # View rules for specific dataset
            dataset = Dataset.query.filter_by(dataset_name=dataset_name).first()
            if not dataset:
                return {'success': False, 'error': f'Dataset "{dataset_name}" not found'}
            
            rules = DataQualityRule.query.filter_by(dataset_id=dataset.id).all()
            
            rules_data = []
            for rule in rules:
                rules_data.append({
                    'id': rule.id,
                    'field_name': rule.field_name,
                    'rule_type': rule.rule_type,
                    'rule_description': rule.rule_description,
                    'severity': rule.severity,
                    'is_active': rule.is_active,
                    'created_at': rule.created_at.isoformat() if rule.created_at else None
                })
            
            return {
                'success': True,
                'dataset_name': dataset_name,
                'rules': rules_data,
                'total_count': len(rules_data)
            }
        else:
            # View all rules
            all_rules = DataQualityRule.query.all()
            datasets = Dataset.query.all()
            
            rules_data = []
            for rule in all_rules:
                dataset = next((d for d in datasets if d.id == rule.dataset_id), None)
                rules_data.append({
                    'id': rule.id,
                    'dataset_name': dataset.dataset_name if dataset else 'Unknown',
                    'field_name': rule.field_name,
                    'rule_type': rule.rule_type,
                    'rule_description': rule.rule_description,
                    'severity': rule.severity,
                    'is_active': rule.is_active
                })
            
            return {
                'success': True,
                'rules': rules_data,
                'total_count': len(rules_data)
            }

    def _generate_rule_description(self, field_name: str, rule_type: str, severity: str) -> str:
        """Generate a human-readable rule description"""
        
        rule_descriptions = {
            'NOT_NULL': f'Ensures {field_name} field is not empty or null',
            'LENGTH_VALIDATION': f'Validates the length of {field_name} field',
            'FORMAT_VALIDATION': f'Validates the format pattern of {field_name} field',
            'NUMERIC_VALIDATION': f'Ensures {field_name} contains valid numeric values',
            'DATE_VALIDATION': f'Validates {field_name} as a proper date/time value',
            'BOOLEAN_VALIDATION': f'Ensures {field_name} contains valid boolean values',
            'UNIQUENESS_VALIDATION': f'Ensures {field_name} values are unique across records',
            'RANGE_CHECK': f'Validates {field_name} values are within acceptable range'
        }
        
        base_description = rule_descriptions.get(rule_type, f'Validates {field_name} field')
        return f"{base_description} ({severity} severity)"

    def get_provider_status(self) -> Dict[str, Any]:
        """Get status of all LLM providers"""
        return {
            'active_provider': self.active_provider,
            'providers': self.providers,
            'capabilities': {
                'ollama': 'Local LLM (Llama 3.2 3B) - Fastest, Privacy-first',
                'groq': 'Groq Cloud API (Llama 3 8B) - Fast, Free tier',
                'huggingface': 'HuggingFace API (DialoGPT Large) - Free tier',
                'none': 'Pattern matching fallback - Always available'
            }
        }


# Initialize the GenAI assistant
genai_assistant = GenAIEDQAssistant()

@genai_llm_bp.route('/chat', methods=['POST'])
def genai_llm_chat():
    """GenAI LLM-powered chat endpoint"""
    try:
        data = request.get_json()
        if not data or 'message' not in data:
            return jsonify({'error': 'Message is required'}), 400

        message = data['message'].strip()
        if not message:
            return jsonify({'error': 'Message cannot be empty'}), 400

        # Get context information
        datasets = Dataset.query.all()
        context = {
            'datasets': [{'id': d.id, 'dataset_name': d.dataset_name} for d in datasets]
        }

        # Parse message using GenAI LLM
        parsed_result = genai_assistant.parse_user_message(message, context)
        
        # Execute the operation if intent is clear
        result = {'success': False, 'message': 'No operation performed'}
        intent = parsed_result.get('intent', {})
        
        if intent.get('confidence') in ['high', 'medium'] and intent.get('action') in ['create', 'update', 'delete', 'view']:
            result = genai_assistant.execute_rule_operation(intent)

        response = {
            'parsed_result': parsed_result,
            'execution_result': result,
            'ai_response': parsed_result.get('response', ''),
            'suggestions': parsed_result.get('suggestions', []),
            'missing_info': parsed_result.get('missing_info', []),
            'model_info': {
                'type': 'genai_llm',
                'provider': genai_assistant.active_provider,
                'model': genai_assistant.providers.get(genai_assistant.active_provider, {}).get('model', 'unknown')
            }
        }

        return jsonify(response), 200

    except Exception as e:
        return jsonify({'error': f'Server error: {str(e)}'}), 500

@genai_llm_bp.route('/providers', methods=['GET'])
def get_providers():
    """Get status of all LLM providers"""
    try:
        status = genai_assistant.get_provider_status()
        return jsonify(status), 200
    except Exception as e:
        return jsonify({'error': f'Error getting provider status: {str(e)}'}), 500

@genai_llm_bp.route('/generate-description', methods=['POST'])
def generate_rule_description():
    """Generate rule description using GenAI LLM"""
    try:
        data = request.get_json()
        field_name = data.get('field_name')
        rule_type = data.get('rule_type')
        severity = data.get('severity', 'MEDIUM')

        if not field_name or not rule_type:
            return jsonify({'error': 'field_name and rule_type are required'}), 400

        description = genai_assistant._generate_rule_description(field_name, rule_type, severity)
        
        return jsonify({
            'description': description,
            'field_name': field_name,
            'rule_type': rule_type,
            'severity': severity,
            'model_info': f'genai_llm_{genai_assistant.active_provider}'
        }), 200

    except Exception as e:
        return jsonify({'error': f'Error generating description: {str(e)}'}), 500
