"""
Pattern Matching EDQ Assistant
Provides rule-based intent extraction for EDQ rule management
"""

import re
from typing import Dict, Any, Optional, List
from flask import Blueprint, request, jsonify
from app import db
from app.models import Dataset, Field
from app.edq_models import DataQualityRule
from datetime import datetime
import uuid

pattern_matching_bp = Blueprint('pattern_matching_assistant', __name__)

class PatternMatchingAssistant:
    """Pattern-based EDQ Assistant for reliable fallback functionality"""
    
    def __init__(self):
        # Define pattern matching rules for intent extraction
        self.action_patterns = {
            'create': [
                r'\b(create|add|setup|set up|new|make|establish|generate)\b.*\b(rule|validation|check)\b',
                r'\b(rule|validation)\b.*\b(for|on)\b.*\b(field|column)\b',
                r'\b(validate|check)\b.*\b(field|data)\b'
            ],
            'update': [
                r'\b(update|modify|change|edit|alter)\b.*\b(rule|validation|severity)\b',
                r'\b(change|set)\b.*\b(severity|priority)\b',
                r'\b(make|turn)\b.*\b(critical|high|medium|low)\b'
            ],
            'delete': [
                r'\b(delete|remove|drop|eliminate|disable)\b.*\b(rule|validation)\b',
                r'\b(turn off|deactivate)\b.*\b(rule|validation)\b'
            ],
            'view': [
                r'\b(show|showing|view|viewing|list|listing|display|displaying|see|seeing|get|getting)\b.*\b(rule|validation|dataset)\b',
                r'\b(what|which)\b.*\b(rule|validation)\b',
                r'\b(all|existing)\b.*\b(rule|validation)\b',
                r'\b(show|showing|list|listing|view|viewing)\b.*\b(all|rules|for)\b',
                r'\b(view|show|list)\b\s+(rules?|validations?)\b',
                r'\b(show|list|view)\b.*\b(rules?|validations?)\b\s+for\b'
            ],
            'help': [
                r'\b(help|how|what|explain|guide|assist)\b',
                r'\b(can you|could you)\b.*\b(help|assist)\b',
                r'^\?|^help$'
            ]
        }
        
        # Rule type patterns
        self.rule_type_patterns = {
            'NOT_NULL': [
                r'\b(not_null|not null|required|mandatory|must have|cannot be empty)\b',
                r'\b(null|empty|blank)\b.*\b(check|validation)\b',
                r'\b(should not be|must not be|cannot be|not be)\b.*\b(null|empty|blank)\b',
                r'\b(should not|must not|cannot)\b.*\b(null|empty|blank)\b',
                r'\b(no null|no empty|non.null|non.empty)\b'
            ],
            'LENGTH_VALIDATION': [
                r'\b(length|size|character|min|max|minimum|maximum)\b',
                r'\b(must be|should be)\b.*\b(characters|chars|long)\b'
            ],
            'FORMAT_VALIDATION': [
                r'\b(format|pattern|regex|structure)\b',
                r'\b(valid|validate)\b.*\b(format|pattern)\b',
                r'\b(email format|phone format|date format)\b'
            ],
            'NUMERIC_VALIDATION': [
                r'\b(numeric\s+validation|number\s+validation|integer\s+validation|decimal\s+validation|digit\s+validation)\b',
                r'\b(numeric|number|integer|decimal|digit)\b(?!\s+(range|check))',
                r'\b(must be|should be)\b.*\b(number|numeric|digit)\b'
            ],
            'DATE_VALIDATION': [
                r'\b(date|time|timestamp|datetime)\b',
                r'\b(valid|validate)\b.*\b(date|time)\b'
            ],
            'BOOLEAN_VALIDATION': [
                r'\b(boolean|true|false|yes|no)\b',
                r'\b(must be|should be)\b.*\b(true|false|boolean)\b'
            ],
            'UNIQUENESS_VALIDATION': [
                r'\b(unique|uniqueness|distinct|duplicate|one of a kind)\b',
                r'\b(no duplicate|prevent duplicate|avoid duplicate)\b',
                r'\b(must be unique|should be unique|unique constraint)\b'
            ],
            'RANGE_CHECK': [
                r'\b(range\s+check|range\s+validation)\b',
                r'\b(between|within)\b.*\b(range|values?)\b',
                r'\b(minimum|maximum|min|max)\b.*\b(value|amount|range)\b',
                r'\bfrom\b.*\bto\b.*\b(range|values?)\b'
            ]
        }
        
        # Severity patterns
        self.severity_patterns = {
            'CRITICAL': [r'\b(critical|urgent|severe|blocker)\b'],
            'HIGH': [r'\b(high|important|major)\b'],
            'MEDIUM': [r'\b(medium|normal|standard|moderate)\b'],
            'LOW': [r'\b(low|minor|trivial|optional)\b']
        }

    def extract_intent(self, message: str) -> Dict[str, Any]:
        """Extract intent from user message using pattern matching"""
        message_lower = message.lower()
        
        # Extract action
        action = self._extract_action(message_lower)
        
        # Extract entities
        dataset_name = self._extract_dataset_name(message)
        field_name = self._extract_field_name(message)
        rule_type = self._extract_rule_type(message_lower)
        severity = self._extract_severity(message_lower)
        
        # Determine confidence based on extracted information
        confidence = self._calculate_confidence(action, dataset_name, field_name, rule_type)
        
        return {
            'action': action,
            'dataset_name': dataset_name,
            'field_name': field_name,
            'rule_type': rule_type,
            'severity': severity,
            'confidence': confidence,
            'parameters': {}
        }

    def _extract_action(self, message: str) -> str:
        """Extract action from message with improved priority order"""
        # Check delete first as it's most specific
        if any(re.search(pattern, message, re.IGNORECASE) for pattern in self.action_patterns['delete']):
            return 'delete'
        
        # Check update patterns
        if any(re.search(pattern, message, re.IGNORECASE) for pattern in self.action_patterns['update']):
            return 'update'
        
        # Check view patterns
        if any(re.search(pattern, message, re.IGNORECASE) for pattern in self.action_patterns['view']):
            return 'view'
        
        # Check create patterns
        if any(re.search(pattern, message, re.IGNORECASE) for pattern in self.action_patterns['create']):
            return 'create'
        
        # Check help patterns
        if any(re.search(pattern, message, re.IGNORECASE) for pattern in self.action_patterns['help']):
            return 'help'
            
        return 'help'

    def _extract_dataset_name(self, message: str) -> Optional[str]:
        """Extract dataset name from message with fuzzy matching"""
        # Look for common dataset patterns
        patterns = [
            r'in\s+(?:the\s+)?([a-zA-Z_][a-zA-Z0-9_\s]+?)\s+dataset',
            r'for\s+(?:the\s+)?([a-zA-Z_][a-zA-Z0-9_\s]+?)\s+dataset',
            r'from\s+(?:the\s+)?([a-zA-Z_][a-zA-Z0-9_\s]+?)\s+dataset',
            r'dataset[:\s]+([a-zA-Z_][a-zA-Z0-9_\s]+?)(?:\s|$|field|with)',
            r'in[:\s]+([a-zA-Z_][a-zA-Z0-9_\s]+?)[:\s]+dataset',
            r'for[:\s]+([a-zA-Z_][a-zA-Z0-9_\s]+?)[:\s]+dataset',
            r'from[:\s]+([a-zA-Z_][a-zA-Z0-9_\s]+?)[:\s]+(?:dataset|table)'
        ]
        
        extracted_name = None
        for pattern in patterns:
            match = re.search(pattern, message, re.IGNORECASE)
            if match:
                dataset_name = match.group(1).strip()
                # Filter out common articles and short words
                if dataset_name.lower() not in ['the', 'a', 'an', 'this', 'that'] and len(dataset_name) > 2:
                    extracted_name = dataset_name
                    break
        
        # Get all datasets from database for matching
        datasets = Dataset.query.all()
        dataset_names = [d.dataset_name for d in datasets]
        
        # If we extracted a name from patterns, try to match it
        if extracted_name:
            # First try exact match (case insensitive)
            for dataset_name in dataset_names:
                if extracted_name.lower() == dataset_name.lower():
                    return dataset_name
            
            # Then try partial match - check if extracted name is contained in any dataset name
            for dataset_name in dataset_names:
                if extracted_name.lower() in dataset_name.lower():
                    return dataset_name
            
            # Finally try reverse - check if any dataset name is contained in extracted name
            for dataset_name in dataset_names:
                if dataset_name.lower() in extracted_name.lower():
                    return dataset_name
        
        # Look for known dataset names directly in the message (exact match)
        for dataset_name in dataset_names:
            if dataset_name.lower() in message.lower():
                return dataset_name
        
        # Look for partial matches of known dataset names in the message
        for dataset_name in dataset_names:
            # Split dataset name into words and check if any significant word appears
            words = dataset_name.lower().split()
            for word in words:
                if len(word) > 3 and word in message.lower():  # Only match words longer than 3 chars
                    return dataset_name
                    
        return extracted_name  # Return the extracted name even if no database match found

    def _extract_field_name(self, message: str) -> Optional[str]:
        """Extract field name from message"""
        patterns = [
            # High priority patterns for explicit field name syntax
            r'field\s+name\s+(?:is\s+)?([a-zA-Z_][a-zA-Z0-9_]*)',
            r'with\s+field\s+name\s+([a-zA-Z_][a-zA-Z0-9_]*)',
            r'field\s+([a-zA-Z_][a-zA-Z0-9_]*)\s+(?:is|rule|type)',
            # Standard patterns
            r'for\s+(?:the\s+)?([a-zA-Z_][a-zA-Z0-9_]*)\s+field',
            r'([a-zA-Z_][a-zA-Z0-9_]*)\s+field',
            r'field[:\s]+([a-zA-Z_][a-zA-Z0-9_]*)',
            r'([a-zA-Z_][a-zA-Z0-9_]*)[:\s]+field',
            r'column[:\s]+([a-zA-Z_][a-zA-Z0-9_]*)',
            r'([a-zA-Z_][a-zA-Z0-9_]*)[:\s]+column',
            r'from\s+(?:the\s+)?([a-zA-Z_][a-zA-Z0-9_]*)\s+field'
        ]
        
        for pattern in patterns:
            match = re.search(pattern, message, re.IGNORECASE)
            if match:
                return match.group(1).strip()
                
        return None

    def _extract_rule_type(self, message: str) -> Optional[str]:
        """Extract rule type from message with improved priority order"""
        message_lower = message.lower()
        
        # Check for more specific patterns first to avoid false matches
        
        # Check for uniqueness patterns first (most specific)
        for pattern in self.rule_type_patterns['UNIQUENESS_VALIDATION']:
            if re.search(pattern, message_lower, re.IGNORECASE):
                return 'UNIQUENESS_VALIDATION'
        
        # Check for NOT_NULL patterns
        for pattern in self.rule_type_patterns['NOT_NULL']:
            if re.search(pattern, message_lower, re.IGNORECASE):
                return 'NOT_NULL'
        
        # Check for NUMERIC_VALIDATION patterns (before RANGE_CHECK to prioritize specific numeric validation)
        for pattern in self.rule_type_patterns['NUMERIC_VALIDATION']:
            if re.search(pattern, message_lower, re.IGNORECASE):
                return 'NUMERIC_VALIDATION'
        
        # Check for LENGTH_VALIDATION patterns
        for pattern in self.rule_type_patterns['LENGTH_VALIDATION']:
            if re.search(pattern, message_lower, re.IGNORECASE):
                return 'LENGTH_VALIDATION'
        
        # Check for RANGE_CHECK patterns (after NUMERIC_VALIDATION)
        for pattern in self.rule_type_patterns['RANGE_CHECK']:
            if re.search(pattern, message_lower, re.IGNORECASE):
                return 'RANGE_CHECK'
        
        # Check for DATE_VALIDATION patterns
        for pattern in self.rule_type_patterns['DATE_VALIDATION']:
            if re.search(pattern, message_lower, re.IGNORECASE):
                return 'DATE_VALIDATION'
        
        # Check for BOOLEAN_VALIDATION patterns
        for pattern in self.rule_type_patterns['BOOLEAN_VALIDATION']:
            if re.search(pattern, message_lower, re.IGNORECASE):
                return 'BOOLEAN_VALIDATION'
        
        # Check for FORMAT_VALIDATION patterns last (most general)
        for pattern in self.rule_type_patterns['FORMAT_VALIDATION']:
            if re.search(pattern, message_lower, re.IGNORECASE):
                return 'FORMAT_VALIDATION'
        
        return None

    def _extract_severity(self, message: str) -> Optional[str]:
        """Extract severity from message"""
        for severity, patterns in self.severity_patterns.items():
            for pattern in patterns:
                if re.search(pattern, message, re.IGNORECASE):
                    return severity
        return 'MEDIUM'  # Default severity

    def _calculate_confidence(self, action: str, dataset: str, field: str, rule_type: str) -> str:
        """Calculate confidence level based on extracted information"""
        score = 0
        
        if action != 'help':
            score += 1
        
        # Special handling for view operations
        if action == 'view':
            if dataset:
                score += 3  # High confidence if dataset specified for view
            else:
                score += 2  # Medium confidence even without dataset to show available datasets
        else:
            # For other operations, we need more information
            if dataset:
                score += 2
            if field:
                score += 2
            if rule_type:
                score += 1
        
        # Special handling for different actions
        if action == 'view':
            # For view actions, dataset is often sufficient
            if dataset:
                score += 1  # Bonus point for view with dataset
        elif action in ['create', 'update']:
            # For create/update actions, we typically need more information
            pass  # Keep standard scoring
        elif action == 'delete':
            # For delete actions, field information is often sufficient
            if field:
                score += 1  # Bonus point for delete with field
            
        if score >= 4:
            return 'high'
        elif score >= 2:
            return 'medium'
        else:
            return 'low'

    def generate_response(self, intent: Dict[str, Any], message: str) -> Dict[str, Any]:
        """Generate structured response based on intent"""
        action = intent['action']
        confidence = intent['confidence']
        
        # Generate appropriate response based on action and confidence
        if action == 'help':
            response = self._generate_help_response()
        elif confidence == 'high':
            response = self._generate_high_confidence_response(intent)
        elif confidence == 'medium':
            response = self._generate_medium_confidence_response(intent)
        else:
            response = self._generate_low_confidence_response(intent)
        
        return {
            'intent': intent,
            'response': response['message'],
            'missing_info': response['missing_info'],
            'suggestions': response['suggestions'],
            'reasoning': f'Pattern matching analysis - confidence: {confidence}'
        }

    def _generate_help_response(self) -> Dict[str, Any]:
        """Generate help response"""
        return {
            'message': """I can help you manage EDQ (Enterprise Data Quality) rules using natural language! Here's what I can do:

📝 **Create Rules**: "Create a NOT_NULL validation for the email field in Employee dataset"
✏️ **Update Rules**: "Change the email validation severity to HIGH" 
🗑️ **Delete Rules**: "Remove the length validation from the name field"
📊 **View Rules**: "Show me all rules for the Customer dataset"

I understand various rule types:
• NOT_NULL, LENGTH_VALIDATION, FORMAT_VALIDATION
• NUMERIC_VALIDATION, DATE_VALIDATION, UNIQUENESS_VALIDATION
• BOOLEAN_VALIDATION, RANGE_CHECK

Just tell me what you want to do in natural language!""",
            'missing_info': [],
            'suggestions': [
                'Show me all datasets',
                'Create a validation rule for email field',
                'View all existing rules',
                'Help me set up uniqueness validation'
            ]
        }

    def _generate_high_confidence_response(self, intent: Dict[str, Any]) -> Dict[str, Any]:
        """Generate response for high confidence intent"""
        action = intent['action']
        dataset = intent['dataset_name']
        field = intent['field_name']
        rule_type = intent['rule_type']
        severity = intent['severity']
        
        if action == 'create':
            message = f"I'll create a {rule_type} validation rule for the {field} field in the {dataset} dataset with {severity} severity."
        elif action == 'update':
            if severity:
                message = f"I'll update the {rule_type or ''} rule for the {field} field in the {dataset} dataset to {severity} severity."
            else:
                message = f"I'll update the {rule_type or 'validation'} rule for the {field} field in the {dataset} dataset."
        elif action == 'delete':
            message = f"I'll delete the {rule_type or 'validation'} rule from the {field} field in the {dataset} dataset."
        elif action == 'view':
            if dataset and field:
                message = f"Showing rules for the {field} field in the {dataset} dataset."
            elif dataset:
                message = f"Showing all rules for the {dataset} dataset."
            else:
                message = "Showing all available rules."
        else:
            message = f"I understand you want to {action} a rule. Let me process that for you."
        
        return {
            'message': message,
            'missing_info': [],
            'suggestions': []
        }

    def _generate_medium_confidence_response(self, intent: Dict[str, Any]) -> Dict[str, Any]:
        """Generate response for medium confidence intent"""
        missing = []
        suggestions = []
        action = intent['action']
        
        if not intent['dataset_name']:
            missing.append('Dataset name')
            if action == 'view':
                suggestions.append('Try: "Show all rules for [DatasetName] dataset"')
                suggestions.append('Or: "List rules for Customer dataset"')
            else:
                suggestions.append('Specify which dataset you want to work with')
        
        if not intent['field_name'] and intent['action'] in ['create', 'update', 'delete']:
            missing.append('Field name')
            suggestions.append('Specify which field needs the rule')
        
        if not intent['rule_type'] and intent['action'] in ['create', 'update']:
            missing.append('Rule type')
            suggestions.append('Specify the type of validation rule')
        
        if action == 'view' and not intent['dataset_name']:
            message = "I'd like to show you rules, but which dataset would you like to see? Please specify the dataset name."
        else:
            message = f"I understand you want to {action} a rule. To proceed, I need some additional information."
        
        return {
            'message': message,
            'missing_info': missing,
            'suggestions': suggestions
        }

    def _generate_low_confidence_response(self, intent: Dict[str, Any]) -> Dict[str, Any]:
        """Generate response for low confidence intent"""
        return {
            'message': """I'd like to help you with EDQ rules, but I need more specific information. Could you please clarify:

• What action do you want to perform? (create, update, delete, or view rules)
• Which dataset are you working with?
• Which field needs attention?
• What type of validation rule is needed?

For example: "Create a NOT_NULL validation for the email field in Employee dataset" """,
            'missing_info': [
                'Specific action (create/update/delete/view)',
                'Dataset name',
                'Field name',
                'Rule type (if creating/updating)'
            ],
            'suggestions': [
                'Be more specific about what you want to do',
                'Mention the dataset and field names',
                'Specify the type of validation rule needed'
            ]
        }

    def execute_view_operation(self, intent: Dict[str, Any]) -> Dict[str, Any]:
        """Execute view operation with real database data"""
        dataset_name = intent.get('dataset_name')
        field_name = intent.get('field_name')
        
        # If no dataset specified, show available datasets and ask user to choose
        if not dataset_name:
            datasets = Dataset.query.all()
            if not datasets:
                return {
                    'success': False,
                    'message': 'No datasets found in the database',
                    'note': 'Please create datasets first before setting up rules',
                    'suggestions': ['Create a new dataset', 'Contact administrator to set up datasets']
                }
            
            dataset_list = []
            for dataset in datasets:
                # Get rule count for each dataset
                rule_count = DataQualityRule.query.filter_by(dataset_id=dataset.id).count()
                active_rule_count = DataQualityRule.query.filter_by(dataset_id=dataset.id, is_active=True).count()
                
                dataset_list.append({
                    'name': dataset.dataset_name,
                    'description': dataset.description or 'No description available',
                    'total_rules': rule_count,
                    'active_rules': active_rule_count,
                    'fields_count': Field.query.filter_by(dataset_id=dataset.id).count()
                })
            
            return {
                'success': True,
                'message': f'Please choose from {len(datasets)} available dataset(s). Which dataset would you like to see rules for?',
                'data': dataset_list,
                'summary': {
                    'action_needed': 'dataset_selection',
                    'total_datasets': len(datasets),
                    'datasets_with_rules': len([d for d in dataset_list if d['total_rules'] > 0])
                },
                'suggestions': [
                    f'Show rules for {dataset.dataset_name} dataset' for dataset in datasets[:3]
                ],
                'note': 'Available datasets with rule summary'
            }
        
        # Find the dataset using fuzzy matching
        dataset = self._find_dataset_by_name(dataset_name)
        if not dataset:
            # Show available datasets when specified dataset not found
            datasets = Dataset.query.all()
            dataset_list = [{'name': d.dataset_name, 'description': d.description or 'No description'} for d in datasets]
            
            return {
                'success': False,
                'message': f'Dataset "{dataset_name}" not found. Please choose from the available datasets below:',
                'data': dataset_list,
                'summary': {
                    'action_needed': 'dataset_selection',
                    'searched_for': dataset_name,
                    'available_datasets': len(datasets)
                },
                'suggestions': [
                    f'Show rules for {d.dataset_name} dataset' for d in datasets[:3]
                ],
                'note': 'Choose from available datasets'
            }
        
        # Get rules for the dataset
        rules_query = DataQualityRule.query.filter_by(dataset_id=dataset.id)
        
        # Filter by field if specified
        if field_name:
            rules_query = rules_query.filter_by(field_name=field_name)
        
        # Get all rules (active and inactive)
        all_rules = rules_query.all()
        active_rules = [rule for rule in all_rules if rule.is_active]
        inactive_rules = [rule for rule in all_rules if not rule.is_active]
        
        if not all_rules:
            if field_name:
                message = f'No rules found for field "{field_name}" in dataset "{dataset.dataset_name}"'
            else:
                message = f'No rules found for dataset "{dataset.dataset_name}"'
            return {
                'success': True,
                'message': message,
                'data': [],
                'summary': {
                    'dataset_name': dataset.dataset_name,
                    'total_rules': 0,
                    'active_rules': 0,
                    'inactive_rules': 0,
                    'fields_with_rules': []
                },
                'note': 'Pattern matching with database integration'
            }
        
        # Group rules by field for better organization
        rules_by_field = {}
        for rule in active_rules:
            if rule.field_name not in rules_by_field:
                rules_by_field[rule.field_name] = []
            rules_by_field[rule.field_name].append({
                'id': rule.id,
                'rule_type': rule.rule_type,
                'severity': rule.severity,
                'description': rule.rule_description,
                'created_at': rule.created_at.strftime('%Y-%m-%d %H:%M:%S') if rule.created_at else 'Unknown',
                'created_by': rule.created_by or 'Unknown'
            })
        
        # Format all rules data for detailed view
        all_rules_data = []
        for rule in all_rules:
            all_rules_data.append({
                'id': rule.id,
                'rule_type': rule.rule_type,
                'field_name': rule.field_name,
                'severity': rule.severity,
                'is_active': rule.is_active,
                'description': rule.rule_description,
                'created_at': rule.created_at.strftime('%Y-%m-%d %H:%M:%S') if rule.created_at else 'Unknown',
                'created_by': rule.created_by or 'Unknown'
            })
        
        # Create summary
        summary = {
            'dataset_name': dataset.dataset_name,
            'total_rules': len(all_rules),
            'active_rules': len(active_rules),
            'inactive_rules': len(inactive_rules),
            'fields_with_rules': list(rules_by_field.keys()),
            'rules_by_field': rules_by_field
        }
        
        # Generate appropriate message
        if field_name:
            message = f'Found {len(all_rules)} rule(s) for field "{field_name}" in dataset "{dataset.dataset_name}" ({len(active_rules)} active, {len(inactive_rules)} inactive)'
        else:
            message = f'Found {len(all_rules)} rule(s) for dataset "{dataset.dataset_name}" ({len(active_rules)} active, {len(inactive_rules)} inactive) across {len(rules_by_field)} field(s)'
        
        return {
            'success': True,
            'message': message,
            'data': all_rules_data,
            'summary': summary,
            'note': 'Pattern matching with database integration - Active rules organized by field'
        }

    def execute_create_operation(self, intent: Dict[str, Any]) -> Dict[str, Any]:
        """Execute create operation with real database integration"""
        dataset_name = intent.get('dataset_name')
        field_name = intent.get('field_name')
        rule_type = intent.get('rule_type')
        severity = intent.get('severity', 'MEDIUM')
        
        # Validate required fields
        if not all([dataset_name, field_name, rule_type]):
            missing = []
            if not dataset_name:
                missing.append('dataset name')
            if not field_name:
                missing.append('field name')
            if not rule_type:
                missing.append('rule type')
            
            return {
                'success': False,
                'message': f'Missing required information: {", ".join(missing)}',
                'note': 'Pattern matching with database integration'
            }
        
        # Find the dataset using fuzzy matching
        dataset = self._find_dataset_by_name(dataset_name)
        if not dataset:
            return {
                'success': False,
                'message': f'Dataset "{dataset_name}" not found in the database',
                'note': self._get_available_datasets_message()
            }
        
        # Check if field exists in dataset
        field = Field.query.filter_by(dataset_id=dataset.id, field_name=field_name).first()
        if not field:
            return {
                'success': False,
                'message': f'Field "{field_name}" not found in dataset "{dataset.dataset_name}"',
                'note': 'Available fields: ' + ', '.join([f.field_name for f in Field.query.filter_by(dataset_id=dataset.id).all()])
            }
        
        # Check if rule already exists
        existing_rule = DataQualityRule.query.filter_by(
            dataset_id=dataset.id,
            field_name=field_name,
            rule_type=rule_type
        ).first()
        
        if existing_rule:
            return {
                'success': False,
                'message': f'Rule of type "{rule_type}" already exists for field "{field_name}" in dataset "{dataset_name}"',
                'note': 'Use update operation to modify existing rules'
            }
        
        # Generate rule description
        rule_description = self._generate_rule_description(field_name, rule_type, severity)
        
        # Create new rule
        new_rule = DataQualityRule(
            dataset_id=dataset.id,
            rule_type=rule_type,
            field_name=field_name,
            rule_description=rule_description,
            severity=severity,
            is_active=True,
            created_by='Pattern Matching Assistant'
        )
        
        db.session.add(new_rule)
        db.session.commit()
        
        return {
            'success': True,
            'message': f'Successfully created {rule_type} rule for field "{field_name}" in dataset "{dataset_name}"',
            'data': [new_rule.to_dict()],
            'note': 'Pattern matching with database integration'
        }

    def execute_update_operation(self, intent: Dict[str, Any]) -> Dict[str, Any]:
        """Execute update operation with real database integration"""
        dataset_name = intent.get('dataset_name')
        field_name = intent.get('field_name')
        rule_type = intent.get('rule_type')
        severity = intent.get('severity')
        
        # Validate required fields
        if not dataset_name:
            return {
                'success': False,
                'message': 'Missing required information: dataset name',
                'note': 'Please specify which dataset contains the rules you want to update'
            }
        
        # Find the dataset using fuzzy matching
        dataset = self._find_dataset_by_name(dataset_name)
        if not dataset:
            return {
                'success': False,
                'message': f'Dataset "{dataset_name}" not found in the database',
                'note': self._get_available_datasets_message()
            }
        
        # Build query for finding rules to update
        query = DataQualityRule.query.filter_by(dataset_id=dataset.id)
        
        # Add field filter if specified
        if field_name:
            query = query.filter_by(field_name=field_name)
        
        # Add rule type filter if specified
        if rule_type:
            query = query.filter_by(rule_type=rule_type)
        
        rules = query.all()
        
        # Check if rules exist
        if not rules:
            # Provide helpful error message based on what was specified
            if field_name and rule_type:
                rule_desc = f'{rule_type} rule for field "{field_name}"'
            elif field_name:
                rule_desc = f'rules for field "{field_name}"'
            elif rule_type:
                rule_desc = f'{rule_type} rules'
            else:
                rule_desc = 'rules'
                
            # Show what rules are available
            all_rules = DataQualityRule.query.filter_by(dataset_id=dataset.id).all()
            if all_rules:
                available_info = f"Available rules in dataset: {', '.join(set([f'{r.field_name}({r.rule_type})' for r in all_rules]))}"
            else:
                available_info = "No rules exist in this dataset"
                
            return {
                'success': False,
                'message': f'No {rule_desc} found in dataset "{dataset.dataset_name}"',
                'note': available_info
            }
        
        # Determine what to update
        updates_made = []
        updated_count = 0
        updated_rules = []
        
        for rule in rules:
            original_values = {
                'severity': rule.severity,
                'is_active': rule.is_active
            }
            updated = False
            
            # Update severity if specified and different
            if severity and rule.severity != severity:
                rule.severity = severity
                updates_made.append(f"severity changed from {original_values['severity']} to {severity}")
                updated = True
            
            # If no specific changes specified but we found rules, show what can be updated
            if not severity and not updated:
                continue
            
            if updated:
                rule.updated_at = datetime.utcnow()
                updated_count += 1
                updated_rules.append({
                    **rule.to_dict(),
                    'changes_made': updates_made.copy()
                })
                updates_made.clear()
        
        if updated_count > 0:
            db.session.commit()
            
            # Create detailed success message
            rule_desc = f"{updated_count} rule(s)"
            if field_name and rule_type:
                rule_desc = f'{rule_type} rule for field "{field_name}"'
            elif field_name:
                rule_desc = f'{updated_count} rule(s) for field "{field_name}"'
            elif rule_type:
                rule_desc = f'{updated_count} {rule_type} rule(s)'
                
            return {
                'success': True,
                'message': f'Successfully updated {rule_desc} in dataset "{dataset.dataset_name}"',
                'data': updated_rules,
                'summary': {
                    'updated_count': updated_count,
                    'total_found': len(rules),
                    'dataset_name': dataset.dataset_name
                },
                'note': 'Pattern matching with database integration'
            }
        else:
            # Show what can be updated
            available_updates = []
            if not severity:
                available_updates.append("severity (e.g., CRITICAL, HIGH, MEDIUM, LOW)")
            
            return {
                'success': False,
                'message': f'No changes specified for the {len(rules)} rule(s) found',
                'note': f'You can update: {", ".join(available_updates)}. Example: "Change severity to HIGH"',
                'data': [rule.to_dict() for rule in rules]
            }

    def execute_delete_operation(self, intent: Dict[str, Any]) -> Dict[str, Any]:
        """Execute delete operation with real database integration"""
        dataset_name = intent.get('dataset_name')
        field_name = intent.get('field_name')
        rule_type = intent.get('rule_type')
        
        # Validate required fields
        if not dataset_name:
            return {
                'success': False,
                'message': 'Missing required information: dataset name',
                'note': 'Please specify which dataset contains the rules you want to delete'
            }
        
        # Find the dataset using fuzzy matching
        dataset = self._find_dataset_by_name(dataset_name)
        if not dataset:
            return {
                'success': False,
                'message': f'Dataset "{dataset_name}" not found in the database',
                'note': self._get_available_datasets_message()
            }
        
        # Build query for finding rules to delete
        query = DataQualityRule.query.filter_by(dataset_id=dataset.id)
        
        # Add field filter if specified
        if field_name:
            query = query.filter_by(field_name=field_name)
        
        # Add rule type filter if specified
        if rule_type:
            query = query.filter_by(rule_type=rule_type)
        
        rules = query.all()
        
        # Check if rules exist
        if not rules:
            # Provide helpful error message based on what was specified
            if field_name and rule_type:
                rule_desc = f'{rule_type} rule for field "{field_name}"'
            elif field_name:
                rule_desc = f'rules for field "{field_name}"'
            elif rule_type:
                rule_desc = f'{rule_type} rules'
            else:
                rule_desc = 'rules matching your criteria'
                
            # Show what rules are available
            all_rules = DataQualityRule.query.filter_by(dataset_id=dataset.id).all()
            if all_rules:
                available_info = f"Available rules in dataset: {', '.join(set([f'{r.field_name}({r.rule_type})' for r in all_rules]))}"
            else:
                available_info = "No rules exist in this dataset"
                
            return {
                'success': False,
                'message': f'No {rule_desc} found in dataset "{dataset.dataset_name}"',
                'note': available_info
            }
        
        # Prepare deletion summary
        deleted_count = len(rules)
        deleted_rules = []
        
        for rule in rules:
            deleted_rules.append({
                'id': rule.id,
                'rule_type': rule.rule_type,
                'field_name': rule.field_name,
                'severity': rule.severity,
                'description': rule.rule_description,
                'was_active': rule.is_active
            })
        
        # Delete rules
        for rule in rules:
            db.session.delete(rule)
        
        db.session.commit()
        
        # Create detailed success message
        if field_name and rule_type:
            rule_desc = f'{rule_type} rule for field "{field_name}"'
        elif field_name:
            rule_desc = f'{deleted_count} rule(s) for field "{field_name}"'
        elif rule_type:
            rule_desc = f'{deleted_count} {rule_type} rule(s)'
        else:
            rule_desc = f'{deleted_count} rule(s)'
        
        return {
            'success': True,
            'message': f'Successfully deleted {rule_desc} from dataset "{dataset.dataset_name}"',
            'data': deleted_rules,
            'summary': {
                'deleted_count': deleted_count,
                'dataset_name': dataset.dataset_name,
                'affected_fields': list(set([rule['field_name'] for rule in deleted_rules]))
            },
            'note': 'Pattern matching with database integration - Rules permanently removed'
        }
        
        rules = query.all()
        if not rules:
            rule_desc = f'rule for field "{field_name}"'
            if rule_type:
                rule_desc = f'{rule_type} rule for field "{field_name}"'
            return {
                'success': False,
                'message': f'No {rule_desc} found in dataset "{dataset_name}"',
                'note': 'Nothing to delete'
            }
        
        # Delete rules
        deleted_count = len(rules)
        deleted_rules = [rule.to_dict() for rule in rules]
        
        for rule in rules:
            db.session.delete(rule)
        
        db.session.commit()
        
        return {
            'success': True,
            'message': f'Successfully deleted {deleted_count} rule(s) for field "{field_name}" in dataset "{dataset.dataset_name}"',
            'data': deleted_rules,
            'note': 'Pattern matching with database integration'
        }

    def _generate_rule_description(self, field_name: str, rule_type: str, severity: str) -> str:
        """Generate a human-readable rule description"""
        rule_descriptions = {
            'NOT_NULL': f'{field_name} must not be null or empty',
            'LENGTH_VALIDATION': f'{field_name} must have valid length constraints',
            'FORMAT_VALIDATION': f'{field_name} must follow the correct format',
            'NUMERIC_VALIDATION': f'{field_name} must be a valid numeric value',
            'DATE_VALIDATION': f'{field_name} must be a valid date/time value',
            'BOOLEAN_VALIDATION': f'{field_name} must be a valid boolean value',
            'UNIQUENESS_VALIDATION': f'{field_name} values must be unique',
            'RANGE_CHECK': f'{field_name} must be within the specified range'
        }
        
        base_description = rule_descriptions.get(rule_type, f'{field_name} must pass {rule_type} validation')
        return f'{base_description} (Severity: {severity})'

    def _find_dataset_by_name(self, dataset_name: str) -> Optional[Dataset]:
        """Find dataset by name with fuzzy matching"""
        if not dataset_name:
            return None
            
        # First try exact match (case insensitive)
        dataset = Dataset.query.filter(Dataset.dataset_name.ilike(dataset_name)).first()
        if dataset:
            return dataset
        
        # Try partial match - check if input is contained in any dataset name
        datasets = Dataset.query.all()
        for dataset in datasets:
            if dataset_name.lower() in dataset.dataset_name.lower():
                return dataset
        
        # Try reverse - check if any dataset name is contained in input
        for dataset in datasets:
            if dataset.dataset_name.lower() in dataset_name.lower():
                return dataset
        
        # Look for partial matches of significant words
        for dataset in datasets:
            # Split dataset name into words and check if any significant word matches
            words = dataset.dataset_name.lower().split()
            input_words = dataset_name.lower().split()
            for word in words:
                if len(word) > 3 and word in input_words:  # Only match words longer than 3 chars
                    return dataset
        
        return None

    def _get_available_datasets_message(self) -> str:
        """Get formatted message of available datasets"""
        datasets = Dataset.query.all()
        if datasets:
            return 'Available datasets: ' + ', '.join([d.dataset_name for d in datasets])
        return 'No datasets available in the database'

# Initialize the pattern matching assistant
pattern_assistant = PatternMatchingAssistant()

@pattern_matching_bp.route('/chat', methods=['POST'])
def pattern_matching_chat():
    """Pattern matching-based chat endpoint"""
    try:
        data = request.get_json()
        if not data or 'message' not in data:
            return jsonify({'error': 'Message is required'}), 400

        message = data['message'].strip()
        if not message:
            return jsonify({'error': 'Message cannot be empty'}), 400

        # Extract intent using pattern matching
        intent = pattern_assistant.extract_intent(message)
        
        # Generate structured response
        parsed_result = pattern_assistant.generate_response(intent, message)
        
        # Execute operation if confidence is high enough OR if it's a view operation (to show available datasets)
        execution_result = {'success': False, 'message': 'No operation performed'}
        
        should_execute = (
            (intent.get('confidence') in ['high', 'medium'] and intent.get('action') in ['create', 'update', 'delete', 'view']) or
            (intent.get('action') == 'view')  # Always execute view operations to show available datasets
        )
        
        if should_execute:
            # Execute operations with real database integration
            try:
                action = intent.get('action')
                if action == 'view':
                    execution_result = pattern_assistant.execute_view_operation(intent)
                elif action == 'create':
                    execution_result = pattern_assistant.execute_create_operation(intent)
                elif action == 'update':
                    execution_result = pattern_assistant.execute_update_operation(intent)
                elif action == 'delete':
                    execution_result = pattern_assistant.execute_delete_operation(intent)
                else:
                    execution_result = {
                        'success': False,
                        'message': f'Action "{action}" not yet implemented',
                        'note': 'Pattern matching with database integration'
                    }
            except Exception as e:
                execution_result = {
                    'success': False,
                    'message': f'Error executing operation: {str(e)}',
                    'note': 'Pattern matching with database integration'
                }

        response = {
            'parsed_result': parsed_result,
            'execution_result': execution_result,
            'ai_response': parsed_result.get('response', ''),
            'suggestions': parsed_result.get('suggestions', []),
            'missing_info': parsed_result.get('missing_info', []),
            'model_info': {
                'type': 'pattern_matching',
                'provider': 'rule_based',
                'model': 'pattern_extraction',
                'local': True
            }
        }

        return jsonify(response), 200

    except Exception as e:
        return jsonify({
            'error': f'Pattern matching error: {str(e)}',
            'message': 'Failed to process message with pattern matching',
            'model_info': {
                'type': 'error',
                'provider': 'none'
            }
        }), 500

@pattern_matching_bp.route('/patterns', methods=['GET'])
def get_available_patterns():
    """Get information about available patterns"""
    try:
        return jsonify({
            'actions': list(pattern_assistant.action_patterns.keys()),
            'rule_types': list(pattern_assistant.rule_type_patterns.keys()),
            'severities': list(pattern_assistant.severity_patterns.keys()),
            'description': 'Pattern matching assistant for EDQ rule management',
            'capabilities': [
                'Intent extraction from natural language',
                'Entity recognition (dataset, field, rule type)',
                'Confidence scoring',
                'Structured response generation'
            ]
        }), 200
    except Exception as e:
        return jsonify({'error': f'Error getting patterns: {str(e)}'}), 500
