from datetime import datetime
import uuid
from app import db

class Dataset(db.Model):
    """Dataset model for storing dataset information"""
    
    __tablename__ = 'datasets'
    
    id = db.Column(db.Integer, primary_key=True)
    unique_dataset_id = db.Column(db.String(36), unique=True, nullable=False, default=lambda: str(uuid.uuid4()))
    dataset_name = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationship with fields
    fields = db.relationship('Field', backref='dataset', lazy=True, cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<Dataset {self.dataset_name}>'
    
    def to_dict(self):
        """Convert dataset to dictionary for JSON serialization"""
        return {
            'id': self.id,
            'unique_dataset_id': self.unique_dataset_id,
            'dataset_name': self.dataset_name,
            'description': self.description,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'fields_count': len(self.fields)
        }

class Field(db.Model):
    """Field model for storing field schema information"""
    
    __tablename__ = 'fields'
    
    id = db.Column(db.Integer, primary_key=True)
    dataset_id = db.Column(db.Integer, db.ForeignKey('datasets.id'), nullable=False)
    field_name = db.Column(db.String(255), nullable=False)
    data_type = db.Column(db.String(50), nullable=False)  # VARCHAR, INTEGER, DECIMAL, DATE, etc.
    length = db.Column(db.Integer)  # For VARCHAR, DECIMAL, etc.
    precision = db.Column(db.Integer)  # For DECIMAL
    scale = db.Column(db.Integer)  # For DECIMAL
    is_nullable = db.Column(db.Boolean, default=True)
    is_primary_key = db.Column(db.Boolean, default=False)
    is_unique = db.Column(db.Boolean, default=False)
    default_value = db.Column(db.String(255))
    description = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Unique constraint for field name within a dataset
    __table_args__ = (db.UniqueConstraint('dataset_id', 'field_name', name='unique_field_per_dataset'),)
    
    def __repr__(self):
        return f'<Field {self.field_name} ({self.data_type})>'
    
    def to_dict(self):
        """Convert field to dictionary for JSON serialization"""
        return {
            'id': self.id,
            'dataset_id': self.dataset_id,
            'field_name': self.field_name,
            'data_type': self.data_type,
            'length': self.length,
            'precision': self.precision,
            'scale': self.scale,
            'is_nullable': self.is_nullable,
            'is_primary_key': self.is_primary_key,
            'is_unique': self.is_unique,
            'default_value': self.default_value,
            'description': self.description,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
