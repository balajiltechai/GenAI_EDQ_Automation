from flask import Blueprint, request, jsonify
from app import db
from app.models import Dataset, Field
from app.edq_models import DataQualityRule, RuleViolation
from datetime import datetime

api_bp = Blueprint('api', __name__)

# Dataset routes
@api_bp.route('/datasets', methods=['POST'])
def create_dataset():
    """Create a new dataset"""
    try:
        data = request.get_json()
        
        if not data or 'dataset_name' not in data:
            return jsonify({'error': 'Dataset name is required'}), 400
        
        # Check if dataset name already exists
        existing_dataset = Dataset.query.filter_by(dataset_name=data['dataset_name']).first()
        if existing_dataset:
            return jsonify({'error': 'Dataset name already exists'}), 409
        
        dataset = Dataset(
            dataset_name=data['dataset_name'],
            description=data.get('description', '')
        )
        
        db.session.add(dataset)
        db.session.commit()
        
        return jsonify({
            'message': 'Dataset created successfully',
            'dataset': dataset.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@api_bp.route('/datasets', methods=['GET'])
def get_datasets():
    """Get all datasets"""
    try:
        datasets = Dataset.query.all()
        return jsonify({
            'datasets': [dataset.to_dict() for dataset in datasets]
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@api_bp.route('/datasets/<int:dataset_id>', methods=['GET'])
def get_dataset(dataset_id):
    """Get a specific dataset with its fields"""
    try:
        dataset = Dataset.query.get_or_404(dataset_id)
        dataset_dict = dataset.to_dict()
        dataset_dict['fields'] = [field.to_dict() for field in dataset.fields]
        
        return jsonify({'dataset': dataset_dict}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@api_bp.route('/datasets/<int:dataset_id>', methods=['PUT'])
def update_dataset(dataset_id):
    """Update a dataset"""
    try:
        dataset = Dataset.query.get_or_404(dataset_id)
        data = request.get_json()
        
        if not data:
            return jsonify({'error': 'No data provided'}), 400
        
        # Check if new name conflicts with existing datasets
        if 'dataset_name' in data and data['dataset_name'] != dataset.dataset_name:
            existing_dataset = Dataset.query.filter_by(dataset_name=data['dataset_name']).first()
            if existing_dataset:
                return jsonify({'error': 'Dataset name already exists'}), 409
        
        # Update fields
        if 'dataset_name' in data:
            dataset.dataset_name = data['dataset_name']
        if 'description' in data:
            dataset.description = data['description']
        
        dataset.updated_at = datetime.utcnow()
        db.session.commit()
        
        return jsonify({
            'message': 'Dataset updated successfully',
            'dataset': dataset.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@api_bp.route('/datasets/<int:dataset_id>', methods=['DELETE'])
def delete_dataset(dataset_id):
    """Delete a dataset and all its fields"""
    try:
        dataset = Dataset.query.get_or_404(dataset_id)
        db.session.delete(dataset)
        db.session.commit()
        
        return jsonify({'message': 'Dataset deleted successfully'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

# Field routes
@api_bp.route('/datasets/<int:dataset_id>/fields', methods=['POST'])
def create_field(dataset_id):
    """Add a new field to a dataset"""
    try:
        dataset = Dataset.query.get_or_404(dataset_id)
        data = request.get_json()
        
        if not data or 'field_name' not in data or 'data_type' not in data:
            return jsonify({'error': 'Field name and data type are required'}), 400
        
        # Check if field name already exists in this dataset
        existing_field = Field.query.filter_by(
            dataset_id=dataset_id, 
            field_name=data['field_name']
        ).first()
        if existing_field:
            return jsonify({'error': 'Field name already exists in this dataset'}), 409
        
        field = Field(
            dataset_id=dataset_id,
            field_name=data['field_name'],
            data_type=data['data_type'].upper(),
            length=data.get('length'),
            precision=data.get('precision'),
            scale=data.get('scale'),
            is_nullable=data.get('is_nullable', True),
            is_primary_key=data.get('is_primary_key', False),
            is_unique=data.get('is_unique', False),
            default_value=data.get('default_value'),
            description=data.get('description', '')
        )
        
        db.session.add(field)
        db.session.commit()
        
        return jsonify({
            'message': 'Field added successfully',
            'field': field.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@api_bp.route('/datasets/<int:dataset_id>/fields', methods=['GET'])
def get_dataset_fields(dataset_id):
    """Get all fields for a specific dataset"""
    try:
        dataset = Dataset.query.get_or_404(dataset_id)
        fields = Field.query.filter_by(dataset_id=dataset_id).all()
        
        return jsonify({
            'dataset_name': dataset.dataset_name,
            'fields': [field.to_dict() for field in fields]
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@api_bp.route('/fields/<int:field_id>', methods=['GET'])
def get_field(field_id):
    """Get a specific field"""
    try:
        field = Field.query.get_or_404(field_id)
        return jsonify({'field': field.to_dict()}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@api_bp.route('/fields/<int:field_id>', methods=['PUT'])
def update_field(field_id):
    """Update a field"""
    try:
        field = Field.query.get_or_404(field_id)
        data = request.get_json()
        
        if not data:
            return jsonify({'error': 'No data provided'}), 400
        
        # Check if new field name conflicts within the same dataset
        if 'field_name' in data and data['field_name'] != field.field_name:
            existing_field = Field.query.filter_by(
                dataset_id=field.dataset_id,
                field_name=data['field_name']
            ).first()
            if existing_field:
                return jsonify({'error': 'Field name already exists in this dataset'}), 409
        
        # Update field properties
        updatable_fields = [
            'field_name', 'data_type', 'length', 'precision', 'scale',
            'is_nullable', 'is_primary_key', 'is_unique', 'default_value', 'description'
        ]
        
        for field_name in updatable_fields:
            if field_name in data:
                if field_name == 'data_type':
                    setattr(field, field_name, data[field_name].upper())
                else:
                    setattr(field, field_name, data[field_name])
        
        field.updated_at = datetime.utcnow()
        db.session.commit()
        
        return jsonify({
            'message': 'Field updated successfully',
            'field': field.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@api_bp.route('/fields/<int:field_id>', methods=['DELETE'])
def delete_field(field_id):
    """Delete a field"""
    try:
        field = Field.query.get_or_404(field_id)
        db.session.delete(field)
        db.session.commit()
        
        return jsonify({'message': 'Field deleted successfully'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

# Data Quality Rules routes
@api_bp.route('/data-quality-rules', methods=['POST'])
def create_quality_rule():
    """Create a new data quality rule"""
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({'error': 'No data provided'}), 400
        
        required_fields = ['rule_type', 'dataset_id', 'field_name']
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'{field} is required'}), 400
        
        # Validate dataset exists
        from app.models import Dataset
        dataset = Dataset.query.get(data['dataset_id'])
        if not dataset:
            return jsonify({'error': 'Dataset not found'}), 404
        
        # Create new rule
        rule = DataQualityRule(
            rule_type=data['rule_type'],
            dataset_id=data['dataset_id'],
            field_name=data['field_name'],
            rule_description=data.get('rule_description', ''),
            severity=data.get('severity', 'MEDIUM'),
            is_active=data.get('is_active', True),
            rule_parameters=data.get('rule_parameters', {}),
            created_by=data.get('created_by', 'EDQ Framework')
        )
        
        db.session.add(rule)
        db.session.commit()
        
        return jsonify({
            'message': 'Data quality rule created successfully',
            'rule': rule.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@api_bp.route('/data-quality-rules', methods=['GET'])
def get_quality_rules():
    """Get all data quality rules"""
    try:
        dataset_id = request.args.get('dataset_id')
        rule_type = request.args.get('rule_type')
        is_active = request.args.get('is_active')
        
        query = DataQualityRule.query
        
        if dataset_id:
            query = query.filter_by(dataset_id=dataset_id)
        if rule_type:
            query = query.filter_by(rule_type=rule_type)
        if is_active is not None:
            query = query.filter_by(is_active=is_active.lower() == 'true')
        
        rules = query.all()
        
        return jsonify({
            'rules': [rule.to_dict() for rule in rules],
            'total_count': len(rules)
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@api_bp.route('/data-quality-rules/<int:rule_id>', methods=['GET'])
def get_quality_rule(rule_id):
    """Get a specific data quality rule"""
    try:
        rule = DataQualityRule.query.get_or_404(rule_id)
        return jsonify({'rule': rule.to_dict()}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@api_bp.route('/data-quality-rules/<int:rule_id>', methods=['PUT'])
def update_quality_rule(rule_id):
    """Update a data quality rule"""
    try:
        rule = DataQualityRule.query.get_or_404(rule_id)
        data = request.get_json()
        
        if not data:
            return jsonify({'error': 'No data provided'}), 400
        
        # Update rule properties
        updatable_fields = [
            'rule_description', 'severity', 'is_active', 'rule_parameters'
        ]
        
        for field in updatable_fields:
            if field in data:
                setattr(rule, field, data[field])
        
        rule.updated_at = datetime.utcnow()
        db.session.commit()
        
        return jsonify({
            'message': 'Data quality rule updated successfully',
            'rule': rule.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@api_bp.route('/data-quality-rules/<int:rule_id>', methods=['DELETE'])
def delete_quality_rule(rule_id):
    """Delete a data quality rule"""
    try:
        rule = DataQualityRule.query.get_or_404(rule_id)
        db.session.delete(rule)
        db.session.commit()
        
        return jsonify({'message': 'Data quality rule deleted successfully'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@api_bp.route('/datasets/<int:dataset_id>/validate', methods=['POST'])
def validate_dataset_quality(dataset_id):
    """Validate dataset against its quality rules"""
    try:
        from app.models import Dataset
        dataset = Dataset.query.get_or_404(dataset_id)
        
        # Get all active rules for this dataset
        rules = DataQualityRule.query.filter_by(
            dataset_id=dataset_id,
            is_active=True
        ).all()
        
        if not rules:
            return jsonify({
                'message': 'No active quality rules found for this dataset',
                'dataset_id': dataset_id,
                'validation_results': []
            }), 200
        
        validation_results = []
        
        for rule in rules:
            # Simulate rule validation (in real implementation, this would validate actual data)
            result = {
                'rule_id': rule.id,
                'rule_type': rule.rule_type,
                'field_name': rule.field_name,
                'status': 'PASS',  # This would be determined by actual validation logic
                'violations_found': 0,
                'validation_timestamp': datetime.utcnow().isoformat()
            }
            
            # Update rule validation statistics
            rule.validation_count += 1
            rule.last_validation_date = datetime.utcnow()
            rule.last_validation_status = result['status']
            
            validation_results.append(result)
        
        db.session.commit()
        
        return jsonify({
            'message': 'Dataset validation completed',
            'dataset_id': dataset_id,
            'dataset_name': dataset.dataset_name,
            'total_rules_validated': len(rules),
            'validation_results': validation_results
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@api_bp.route('/rule-violations', methods=['GET'])
def get_rule_violations():
    """Get rule violations"""
    try:
        dataset_id = request.args.get('dataset_id')
        rule_id = request.args.get('rule_id')
        status = request.args.get('status')
        
        query = RuleViolation.query
        
        if dataset_id:
            query = query.filter_by(dataset_id=dataset_id)
        if rule_id:
            query = query.filter_by(rule_id=rule_id)
        if status:
            query = query.filter_by(status=status)
        
        violations = query.order_by(RuleViolation.detected_at.desc()).all()
        
        return jsonify({
            'violations': [violation.to_dict() for violation in violations],
            'total_count': len(violations)
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@api_bp.route('/datasets/<int:dataset_id>/quality-rules', methods=['GET'])
def get_dataset_quality_rules(dataset_id):
    """Get all quality rules for a specific dataset"""
    try:
        from app.models import Dataset
        dataset = Dataset.query.get_or_404(dataset_id)
        
        # Get query parameters for filtering
        rule_type = request.args.get('rule_type')
        field_name = request.args.get('field_name')
        is_active = request.args.get('is_active')
        severity = request.args.get('severity')
        
        # Base query
        query = DataQualityRule.query.filter_by(dataset_id=dataset_id)
        
        # Apply filters
        if rule_type:
            query = query.filter(DataQualityRule.rule_type == rule_type)
        if field_name:
            query = query.filter(DataQualityRule.field_name == field_name)
        if is_active is not None:
            is_active_bool = is_active.lower() == 'true'
            query = query.filter(DataQualityRule.is_active == is_active_bool)
        if severity:
            query = query.filter(DataQualityRule.severity == severity)
        
        # Order by creation date (newest first)
        rules = query.order_by(DataQualityRule.created_at.desc()).all()
        
        # Group rules by field for better organization
        rules_by_field = {}
        for rule in rules:
            field = rule.field_name or 'Dataset Level'
            if field not in rules_by_field:
                rules_by_field[field] = []
            rules_by_field[field].append(rule.to_dict())
        
        return jsonify({
            'dataset_id': dataset_id,
            'dataset_name': dataset.dataset_name,
            'rules': [rule.to_dict() for rule in rules],
            'rules_by_field': rules_by_field,
            'total_count': len(rules),
            'summary': {
                'total_rules': len(rules),
                'active_rules': len([r for r in rules if r.is_active]),
                'inactive_rules': len([r for r in rules if not r.is_active]),
                'by_severity': {
                    'CRITICAL': len([r for r in rules if r.severity == 'CRITICAL']),
                    'HIGH': len([r for r in rules if r.severity == 'HIGH']),
                    'MEDIUM': len([r for r in rules if r.severity == 'MEDIUM']),
                    'LOW': len([r for r in rules if r.severity == 'LOW'])
                },
                'by_type': {}
            }
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@api_bp.route('/datasets/<int:dataset_id>/quality-summary', methods=['GET'])
def get_dataset_quality_summary(dataset_id):
    """Get quality summary for a dataset"""
    try:
        from app.models import Dataset
        dataset = Dataset.query.get_or_404(dataset_id)
        
        # Get rule statistics
        total_rules = DataQualityRule.query.filter_by(dataset_id=dataset_id).count()
        active_rules = DataQualityRule.query.filter_by(dataset_id=dataset_id, is_active=True).count()
        
        # Get violation statistics
        total_violations = RuleViolation.query.filter_by(dataset_id=dataset_id).count()
        open_violations = RuleViolation.query.filter_by(dataset_id=dataset_id, status='OPEN').count()
        
        # Calculate quality score (simple implementation)
        quality_score = 100
        if total_rules > 0:
            rules_with_violations = db.session.query(RuleViolation.rule_id).filter_by(
                dataset_id=dataset_id, status='OPEN'
            ).distinct().count()
            quality_score = max(0, ((active_rules - rules_with_violations) / active_rules) * 100)
        
        return jsonify({
            'dataset_id': dataset_id,
            'dataset_name': dataset.dataset_name,
            'quality_summary': {
                'quality_score': round(quality_score, 2),
                'total_rules': total_rules,
                'active_rules': active_rules,
                'total_violations': total_violations,
                'open_violations': open_violations,
                'resolved_violations': total_violations - open_violations
            },
            'generated_at': datetime.utcnow().isoformat()
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Health check route
@api_bp.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'message': 'Dataset Registration API is running'
    }), 200
