from flask import Flask, send_from_directory
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_cors import CORS
from app.config import Config

db = SQLAlchemy()
migrate = Migrate()

def create_app(config_class=Config):
    """Application factory pattern"""
    app = Flask(__name__, static_folder='../static')
    app.config.from_object(config_class)
    
    # Initialize extensions
    db.init_app(app)
    migrate.init_app(app, db)
    CORS(app)
    
    # Register blueprints
    from app.routes import api_bp
    from app.ollama_genai_assistant import ollama_genai_bp
    from app.pattern_matching_assistant import pattern_matching_bp
    
    app.register_blueprint(api_bp, url_prefix='/api')
    app.register_blueprint(ollama_genai_bp, url_prefix='/api/ollama-genai')
    app.register_blueprint(pattern_matching_bp, url_prefix='/api/pattern-matching')
    
    # Add root route for UI
    @app.route('/')
    def serve_ui():
        """Serve the main UI page"""
        return send_from_directory(app.static_folder, 'index.html')
    
    @app.route('/ollama-chat')
    def serve_ollama_chat():
        """Serve the Ollama GenAI chat interface"""
        return send_from_directory(app.static_folder, 'ollama-chat.html')
    
    @app.route('/pattern-test')
    def serve_pattern_test():
        """Serve the pattern matching test page"""
        return send_from_directory(app.static_folder, 'pattern-test.html')
    
    @app.route('/pattern-chat')
    def serve_pattern_chat():
        """Serve the dedicated pattern matching chat interface"""
        return send_from_directory(app.static_folder, 'pattern-chat-clean.html')
    
    return app

# Import models to ensure they are registered with SQLAlchemy
from app import models
from app import edq_models
