"""
Ollama-focused GenAI EDQ Assistant using Llama 3.2 3B
Provides pure LLM-based conversational AI for EDQ rule management
"""

import requests
import json
import os
import subprocess
import time
from typing import Dict, Any, Optional, List
from flask import Blueprint, request, jsonify
from app import db
from app.models import Dataset, Field
from app.edq_models import DataQualityRule
from datetime import datetime
import uuid
import re

ollama_genai_bp = Blueprint('ollama_genai_assistant', __name__)

class OllamaGenAIAssistant:
    """Ollama-focused GenAI EDQ Assistant using Llama 3.2 3B"""
    
    def __init__(self):
        self.ollama_url = 'http://localhost:11434'
        self.model_name = 'llama3.2:3b'
        self.api_url = f'{self.ollama_url}/api/generate'
        self.chat_url = f'{self.ollama_url}/api/chat'
        
        # System prompt optimized for Llama 3.2
        self.system_prompt = """You are an expert EDQ (Enterprise Data Quality) assistant helping Product Managers manage data validation rules.

CAPABILITIES:
- CREATE: Generate new validation rules for dataset fields
- UPDATE: Modify existing rule properties (severity, parameters)
- DELETE: Remove validation rules from fields
- VIEW: Display and analyze existing rules
- HELP: Provide guidance on EDQ best practices

RULE TYPES:
- NOT_NULL: Field cannot be empty/null
- LENGTH_VALIDATION: String length constraints (min/max)
- NUMERIC_VALIDATION: Number validation and range checks
- FORMAT_VALIDATION: Pattern matching (email, phone, regex)
- DATE_VALIDATION: Date/time format and range validation
- BOOLEAN_VALIDATION: True/false value validation
- UNIQUENESS_VALIDATION: Ensure field values are unique
- RANGE_CHECK: Validate values within specified ranges

SEVERITY LEVELS: CRITICAL, HIGH, MEDIUM, LOW

RESPONSE FORMAT: Always respond with valid JSON:
{
    "intent": {
        "action": "create|update|delete|view|help",
        "dataset_name": "string or null",
        "field_name": "string or null",
        "rule_type": "string or null",
        "severity": "CRITICAL|HIGH|MEDIUM|LOW or null",
        "confidence": "high|medium|low",
        "parameters": {}
    },
    "response": "Helpful natural language response",
    "missing_info": ["list of missing required information"],
    "suggestions": ["actionable suggestions"],
    "reasoning": "Brief explanation of analysis"
}

Analyze user requests intelligently and provide conversational, helpful responses."""

    def check_ollama_status(self) -> Dict[str, Any]:
        """Check Ollama service and model status"""
        status = {
            'service_running': False,
            'model_available': False,
            'model_size': None,
            'error': None
        }
        
        try:
            # Check if Ollama service is running
            response = requests.get(f'{self.ollama_url}/api/tags', timeout=5)
            if response.status_code == 200:
                status['service_running'] = True
                
                # Check if our model is available
                models = response.json().get('models', [])
                for model in models:
                    if model.get('name') == self.model_name:
                        status['model_available'] = True
                        status['model_size'] = model.get('size', 'Unknown')
                        break
                        
        except requests.exceptions.ConnectionError:
            status['error'] = 'Ollama service not running'
        except Exception as e:
            status['error'] = str(e)
            
        return status

    def install_model(self) -> Dict[str, Any]:
        """Install Llama 3.2 3B model via Ollama"""
        try:
            # First check if Ollama is installed
            result = subprocess.run(['ollama', '--version'], 
                                  capture_output=True, text=True, timeout=10)
            if result.returncode != 0:
                return {
                    'success': False,
                    'error': 'Ollama not installed. Please install from https://ollama.ai/'
                }
            
            # Pull the model
            print(f"Installing {self.model_name} model...")
            result = subprocess.run(['ollama', 'pull', self.model_name],
                                  capture_output=True, text=True, timeout=300)
            
            if result.returncode == 0:
                return {
                    'success': True,
                    'message': f'Successfully installed {self.model_name}',
                    'output': result.stdout
                }
            else:
                return {
                    'success': False,
                    'error': f'Failed to install model: {result.stderr}',
                    'output': result.stdout
                }
                
        except subprocess.TimeoutExpired:
            return {
                'success': False,
                'error': 'Model installation timed out (5 minutes)'
            }
        except FileNotFoundError:
            return {
                'success': False,
                'error': 'Ollama command not found. Please install Ollama first.'
            }
        except Exception as e:
            return {
                'success': False,
                'error': f'Installation error: {str(e)}'
            }

    def generate_llm_response(self, prompt: str, context: Dict[str, Any] = None) -> Dict[str, Any]:
        """Generate response using Ollama Llama 3.2 3B"""
        try:
            # Prepare the full prompt with context
            full_prompt = f"{self.system_prompt}\n\nUser request: {prompt}"
            
            if context:
                datasets_info = context.get('datasets', [])
                if datasets_info:
                    full_prompt += f"\n\nAvailable datasets: {[d['dataset_name'] for d in datasets_info]}"
            
            # Make request to Ollama
            payload = {
                'model': self.model_name,
                'prompt': full_prompt,
                'format': 'json',
                'stream': False,
                'options': {
                    'temperature': 0.3,
                    'top_p': 0.9,
                    'max_tokens': 1000
                }
            }
            
            response = requests.post(self.api_url, json=payload, timeout=30)
            
            if response.status_code == 200:
                result = response.json()
                response_text = result.get('response', '{}')
                
                # Try to parse JSON response
                try:
                    parsed_response = json.loads(response_text)
                    return {
                        'success': True,
                        'response': parsed_response,
                        'raw_response': response_text,
                        'model_info': {
                            'name': self.model_name,
                            'provider': 'ollama'
                        }
                    }
                except json.JSONDecodeError:
                    # Fallback: extract JSON from response or create structured response
                    return self._create_fallback_response(response_text, prompt)
            else:
                return {
                    'success': False,
                    'error': f'Ollama API error: {response.status_code}',
                    'raw_response': response.text
                }
                
        except requests.exceptions.ConnectionError:
            return {
                'success': False,
                'error': 'Cannot connect to Ollama. Is the service running?'
            }
        except requests.exceptions.Timeout:
            return {
                'success': False,
                'error': 'Request to Ollama timed out'
            }
        except Exception as e:
            return {
                'success': False,
                'error': f'Unexpected error: {str(e)}'
            }

    def _create_fallback_response(self, raw_text: str, prompt: str) -> Dict[str, Any]:
        """Create structured response when JSON parsing fails"""
        # Basic intent detection from raw response
        action = 'help'
        confidence = 'low'
        
        prompt_lower = prompt.lower()
        if any(word in prompt_lower for word in ['create', 'add', 'new']):
            action = 'create'
            confidence = 'medium'
        elif any(word in prompt_lower for word in ['update', 'modify', 'change']):
            action = 'update'
            confidence = 'medium'
        elif any(word in prompt_lower for word in ['delete', 'remove']):
            action = 'delete'
            confidence = 'medium'
        elif any(word in prompt_lower for word in ['show', 'view', 'list']):
            action = 'view'
            confidence = 'medium'
        
        return {
            'success': True,
            'response': {
                'intent': {
                    'action': action,
                    'dataset_name': None,
                    'field_name': None,
                    'rule_type': None,
                    'severity': None,
                    'confidence': confidence,
                    'parameters': {}
                },
                'response': raw_text or "I understand your request. Could you provide more specific details?",
                'missing_info': ['More specific details needed'],
                'suggestions': ['Try being more specific about the dataset and field'],
                'reasoning': 'Processed using fallback parsing'
            },
            'raw_response': raw_text,
            'model_info': {
                'name': self.model_name,
                'provider': 'ollama'
            }
        }

    def execute_rule_operation(self, intent: Dict[str, Any]) -> Dict[str, Any]:
        """Execute EDQ rule operations based on extracted intent"""
        action = intent.get('action')
        dataset_name = intent.get('dataset_name')
        field_name = intent.get('field_name')
        rule_type = intent.get('rule_type')
        severity = intent.get('severity', 'MEDIUM')
        
        try:
            if action == 'create':
                return self._create_rule(dataset_name, field_name, rule_type, severity, intent.get('parameters', {}))
            elif action == 'update':
                return self._update_rule(dataset_name, field_name, rule_type, severity, intent.get('parameters', {}))
            elif action == 'delete':
                return self._delete_rule(dataset_name, field_name, rule_type)
            elif action == 'view':
                return self._view_rules(dataset_name, field_name)
            else:
                return {
                    'success': False,
                    'error': f'Unsupported action: {action}',
                    'message': 'I can help with creating, updating, deleting, or viewing rules.'
                }
        except Exception as e:
            return {
                'success': False,
                'error': f'Operation failed: {str(e)}',
                'message': 'An error occurred while processing your request.'
            }

    def _create_rule(self, dataset_name: str, field_name: str, rule_type: str, severity: str, parameters: Dict) -> Dict[str, Any]:
        """Create a new EDQ rule"""
        if not all([dataset_name, field_name, rule_type]):
            return {
                'success': False,
                'error': 'Missing required information',
                'message': 'Please specify dataset name, field name, and rule type.'
            }
        
        # Find the dataset
        dataset = Dataset.query.filter_by(dataset_name=dataset_name).first()
        if not dataset:
            return {
                'success': False,
                'error': f'Dataset "{dataset_name}" not found',
                'message': 'Please create the dataset first or check the name.'
            }
        
        # Find the field
        field = Field.query.filter_by(dataset_id=dataset.id, field_name=field_name).first()
        if not field:
            return {
                'success': False,
                'error': f'Field "{field_name}" not found in dataset "{dataset_name}"',
                'message': 'Please create the field first or check the name.'
            }
        
        # Create the rule
        rule = DataQualityRule(
            id=str(uuid.uuid4()),
            field_id=field.id,
            rule_type=rule_type.upper(),
            rule_name=f'{rule_type.lower()}_validation_{field_name}',
            description=f'{rule_type.replace("_", " ").title()} validation for {field_name} field',
            severity=severity.upper(),
            is_active=True,
            parameters=parameters,
            created_at=datetime.utcnow(),
            updated_at=datetime.utcnow()
        )
        
        db.session.add(rule)
        db.session.commit()
        
        return {
            'success': True,
            'message': f'Successfully created {rule_type} rule for {field_name} field',
            'rule_id': rule.id,
            'details': {
                'dataset': dataset_name,
                'field': field_name,
                'rule_type': rule_type,
                'severity': severity
            }
        }

    def _update_rule(self, dataset_name: str, field_name: str, rule_type: str, severity: str, parameters: Dict) -> Dict[str, Any]:
        """Update an existing EDQ rule"""
        # Implementation similar to create but updating existing rule
        return {
            'success': False,
            'error': 'Update functionality not yet implemented',
            'message': 'Rule update feature is coming soon.'
        }

    def _delete_rule(self, dataset_name: str, field_name: str, rule_type: str) -> Dict[str, Any]:
        """Delete an EDQ rule"""
        # Implementation for deleting rules
        return {
            'success': False,
            'error': 'Delete functionality not yet implemented',
            'message': 'Rule deletion feature is coming soon.'
        }

    def _view_rules(self, dataset_name: str = None, field_name: str = None) -> Dict[str, Any]:
        """View EDQ rules"""
        try:
            rules_query = DataQualityRule.query
            
            if dataset_name:
                dataset = Dataset.query.filter_by(dataset_name=dataset_name).first()
                if dataset:
                    field_ids = [f.id for f in Field.query.filter_by(dataset_id=dataset.id).all()]
                    rules_query = rules_query.filter(DataQualityRule.field_id.in_(field_ids))
            
            rules = rules_query.all()
            
            rules_data = []
            for rule in rules:
                field = Field.query.get(rule.field_id)
                dataset = Dataset.query.get(field.dataset_id) if field else None
                
                rules_data.append({
                    'id': rule.id,
                    'dataset': dataset.dataset_name if dataset else 'Unknown',
                    'field': field.field_name if field else 'Unknown',
                    'rule_type': rule.rule_type,
                    'severity': rule.severity,
                    'is_active': rule.is_active,
                    'description': rule.description
                })
            
            return {
                'success': True,
                'message': f'Found {len(rules_data)} rules',
                'rules': rules_data,
                'total_count': len(rules_data)
            }
            
        except Exception as e:
            return {
                'success': False,
                'error': f'Error retrieving rules: {str(e)}',
                'message': 'Failed to retrieve rules from database.'
            }


# Initialize the Ollama assistant
ollama_assistant = OllamaGenAIAssistant()

@ollama_genai_bp.route('/status', methods=['GET'])
def get_ollama_status():
    """Get Ollama service and model status"""
    try:
        status = ollama_assistant.check_ollama_status()
        return jsonify({
            'ollama_service': status['service_running'],
            'model_available': status['model_available'],
            'model_name': ollama_assistant.model_name,
            'model_size': status.get('model_size'),
            'error': status.get('error'),
            'setup_required': not (status['service_running'] and status['model_available'])
        }), 200
    except Exception as e:
        return jsonify({'error': f'Status check failed: {str(e)}'}), 500

@ollama_genai_bp.route('/install-model', methods=['POST'])
def install_ollama_model():
    """Install Llama 3.2 3B model"""
    try:
        result = ollama_assistant.install_model()
        status_code = 200 if result['success'] else 400
        return jsonify(result), status_code
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'Installation failed: {str(e)}'
        }), 500

@ollama_genai_bp.route('/chat', methods=['POST'])
def ollama_genai_chat():
    """Pure Ollama LLM-powered chat endpoint"""
    try:
        data = request.get_json()
        if not data or 'message' not in data:
            return jsonify({'error': 'Message is required'}), 400

        message = data['message'].strip()
        if not message:
            return jsonify({'error': 'Message cannot be empty'}), 400

        # Check if Ollama is available
        status = ollama_assistant.check_ollama_status()
        if not status['service_running']:
            return jsonify({
                'error': 'Ollama service not running',
                'message': 'Please start Ollama service first',
                'setup_required': True,
                'instructions': 'Run: ollama serve'
            }), 503

        if not status['model_available']:
            return jsonify({
                'error': f'Model {ollama_assistant.model_name} not available',
                'message': 'Please install the model first',
                'setup_required': True,
                'instructions': f'Use the /install-model endpoint or run: ollama pull {ollama_assistant.model_name}'
            }), 503

        # Get context information
        datasets = Dataset.query.all()
        context = {
            'datasets': [{'id': d.id, 'dataset_name': d.dataset_name} for d in datasets]
        }

        # Generate LLM response
        llm_result = ollama_assistant.generate_llm_response(message, context)
        
        if not llm_result['success']:
            return jsonify({
                'error': llm_result['error'],
                'message': 'Failed to generate LLM response',
                'fallback_available': True
            }), 500

        parsed_result = llm_result['response']
        
        # Execute the operation if intent is clear
        execution_result = {'success': False, 'message': 'No operation performed'}
        intent = parsed_result.get('intent', {})
        
        if intent.get('confidence') in ['high', 'medium'] and intent.get('action') in ['create', 'update', 'delete', 'view']:
            execution_result = ollama_assistant.execute_rule_operation(intent)

        response = {
            'parsed_result': parsed_result,
            'execution_result': execution_result,
            'ai_response': parsed_result.get('response', ''),
            'suggestions': parsed_result.get('suggestions', []),
            'missing_info': parsed_result.get('missing_info', []),
            'model_info': {
                'type': 'ollama_llm',
                'provider': 'ollama',
                'model': ollama_assistant.model_name,
                'local': True
            },
            'llm_raw': llm_result.get('raw_response', '')
        }

        return jsonify(response), 200

    except Exception as e:
        return jsonify({
            'error': f'Server error: {str(e)}',
            'message': 'An unexpected error occurred',
            'model_info': {
                'type': 'error',
                'provider': 'none'
            }
        }), 500

@ollama_genai_bp.route('/setup-guide', methods=['GET'])
def get_setup_guide():
    """Get setup instructions for Ollama"""
    try:
        status = ollama_assistant.check_ollama_status()
        
        guide = {
            'status': status,
            'steps': [],
            'ready': status['service_running'] and status['model_available']
        }
        
        if not status['service_running']:
            guide['steps'].append({
                'step': 1,
                'title': 'Install Ollama',
                'description': 'Download and install Ollama from https://ollama.ai/',
                'command': 'Visit https://ollama.ai/ and follow installation instructions',
                'required': True
            })
            guide['steps'].append({
                'step': 2,
                'title': 'Start Ollama Service',
                'description': 'Start the Ollama service',
                'command': 'ollama serve',
                'required': True
            })
        
        if status['service_running'] and not status['model_available']:
            guide['steps'].append({
                'step': 3,
                'title': 'Install Model',
                'description': f'Install the {ollama_assistant.model_name} model',
                'command': f'ollama pull {ollama_assistant.model_name}',
                'api_endpoint': '/api/ollama-genai/install-model',
                'required': True
            })
        
        if guide['ready']:
            guide['steps'].append({
                'step': 'final',
                'title': 'Ready to Use!',
                'description': 'Your Ollama GenAI assistant is ready for intelligent EDQ rule management',
                'command': 'Start chatting with natural language!',
                'required': False
            })
        
        return jsonify(guide), 200
        
    except Exception as e:
        return jsonify({'error': f'Setup guide error: {str(e)}'}), 500
