from datetime import datetime
import uuid
from app import db

class DataQualityRule(db.Model):
    """Data Quality Rule model for storing validation rules"""
    
    __tablename__ = 'data_quality_rules'
    
    id = db.Column(db.Integer, primary_key=True)
    rule_id = db.Column(db.String(36), unique=True, nullable=False, default=lambda: str(uuid.uuid4()))
    dataset_id = db.Column(db.Integer, db.ForeignKey('datasets.id'), nullable=False)
    rule_type = db.Column(db.String(50), nullable=False)  # NOT_NULL, LENGTH_VALIDATION, etc.
    field_name = db.Column(db.String(255), nullable=False)
    rule_description = db.Column(db.Text)
    severity = db.Column(db.String(20), default='MEDIUM')  # CRITICAL, HIGH, MEDIUM, LOW
    is_active = db.Column(db.Boolean, default=True)
    
    # Rule parameters (stored as JSON)
    rule_parameters = db.Column(db.JSON)
    
    # Validation results tracking
    last_validation_date = db.Column(db.DateTime)
    last_validation_status = db.Column(db.String(20))  # PASS, FAIL, WARNING
    validation_count = db.Column(db.Integer, default=0)
    failure_count = db.Column(db.Integer, default=0)
    
    # Metadata
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by = db.Column(db.String(100))
    
    # Relationships
    dataset = db.relationship('Dataset', backref='quality_rules')
    
    def __repr__(self):
        return f'<DataQualityRule {self.rule_type} for {self.field_name}>'
    
    def to_dict(self):
        """Convert rule to dictionary for JSON serialization"""
        return {
            'id': self.id,
            'rule_id': self.rule_id,
            'dataset_id': self.dataset_id,
            'rule_type': self.rule_type,
            'field_name': self.field_name,
            'rule_description': self.rule_description,
            'severity': self.severity,
            'is_active': self.is_active,
            'rule_parameters': self.rule_parameters,
            'last_validation_date': self.last_validation_date.isoformat() if self.last_validation_date else None,
            'last_validation_status': self.last_validation_status,
            'validation_count': self.validation_count,
            'failure_count': self.failure_count,
            'success_rate': ((self.validation_count - self.failure_count) / self.validation_count * 100) if self.validation_count > 0 else 0,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'created_by': self.created_by
        }

class RuleViolation(db.Model):
    """Rule Violation model for tracking validation failures"""
    
    __tablename__ = 'rule_violations'
    
    id = db.Column(db.Integer, primary_key=True)
    violation_id = db.Column(db.String(36), unique=True, nullable=False, default=lambda: str(uuid.uuid4()))
    rule_id = db.Column(db.Integer, db.ForeignKey('data_quality_rules.id'), nullable=False)
    dataset_id = db.Column(db.Integer, db.ForeignKey('datasets.id'), nullable=False)
    
    # Violation details
    violation_type = db.Column(db.String(50), nullable=False)
    field_name = db.Column(db.String(255), nullable=False)
    violation_description = db.Column(db.Text)
    violation_data = db.Column(db.JSON)  # Store specific violation details
    
    # Record information
    record_identifier = db.Column(db.String(255))  # Primary key of violating record
    violation_value = db.Column(db.Text)  # The actual violating value
    
    # Resolution tracking
    status = db.Column(db.String(20), default='OPEN')  # OPEN, RESOLVED, IGNORED
    resolution_notes = db.Column(db.Text)
    resolved_at = db.Column(db.DateTime)
    resolved_by = db.Column(db.String(100))
    
    # Metadata
    detected_at = db.Column(db.DateTime, default=datetime.utcnow)
    severity = db.Column(db.String(20), default='MEDIUM')
    
    # Relationships
    rule = db.relationship('DataQualityRule', backref='violations')
    dataset = db.relationship('Dataset', backref='violations')
    
    def __repr__(self):
        return f'<RuleViolation {self.violation_type} in {self.field_name}>'
    
    def to_dict(self):
        """Convert violation to dictionary for JSON serialization"""
        return {
            'id': self.id,
            'violation_id': self.violation_id,
            'rule_id': self.rule_id,
            'dataset_id': self.dataset_id,
            'violation_type': self.violation_type,
            'field_name': self.field_name,
            'violation_description': self.violation_description,
            'violation_data': self.violation_data,
            'record_identifier': self.record_identifier,
            'violation_value': self.violation_value,
            'status': self.status,
            'resolution_notes': self.resolution_notes,
            'resolved_at': self.resolved_at.isoformat() if self.resolved_at else None,
            'resolved_by': self.resolved_by,
            'detected_at': self.detected_at.isoformat() if self.detected_at else None,
            'severity': self.severity
        }
