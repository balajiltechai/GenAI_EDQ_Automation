"""
EDQ (Enterprise Data Quality) Framework
======================================

A comprehensive framework for setting up and managing data quality rules
for registered datasets through API-driven configuration.

Author: EDQ AI Team
Date: July 30, 2025
"""

import yaml
import requests
import json
import logging
from typing import Dict, List, Any, Optional
from datetime import datetime
from pathlib import Path
import uuid

class EDQFramework:
    """
    Enterprise Data Quality Framework for managing data validation rules
    """
    
    def __init__(self, config_file: str = "config/edq_config.yaml"):
        """
        Initialize the EDQ Framework
        
        Args:
            config_file (str): Path to the YAML configuration file
        """
        self.config_file = config_file
        self.config = self._load_config()
        self.api_base_url = self.config.get('api', {}).get('base_url', 'http://localhost:5001/api')
        self.session = requests.Session()
        self.logger = self._setup_logging()
        
    def _load_config(self) -> Dict[str, Any]:
        """Load configuration from YAML file"""
        try:
            with open(self.config_file, 'r') as file:
                return yaml.safe_load(file)
        except FileNotFoundError:
            raise FileNotFoundError(f"Configuration file not found: {self.config_file}")
        except yaml.YAMLError as e:
            raise ValueError(f"Invalid YAML configuration: {e}")
    
    def _setup_logging(self) -> logging.Logger:
        """Setup logging configuration"""
        logger = logging.getLogger('EDQFramework')
        logger.setLevel(logging.INFO)
        
        if not logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )
            handler.setFormatter(formatter)
            logger.addHandler(handler)
        
        return logger
    
    def _make_api_call(self, method: str, endpoint: str, payload: Optional[Dict] = None) -> Dict[str, Any]:
        """
        Make API call to the dataset service
        
        Args:
            method (str): HTTP method (GET, POST, PUT, DELETE)
            endpoint (str): API endpoint
            payload (Dict): Request payload
            
        Returns:
            Dict: API response data
        """
        url = f"{self.api_base_url}/{endpoint.lstrip('/')}"
        headers = {'Content-Type': 'application/json'}
        
        try:
            response = self.session.request(
                method=method,
                url=url,
                headers=headers,
                json=payload if payload else None,
                timeout=30
            )
            
            self.logger.info(f"{method} {url} - Status: {response.status_code}")
            
            if response.status_code >= 400:
                error_msg = f"API call failed: {response.status_code} - {response.text}"
                self.logger.error(error_msg)
                raise requests.RequestException(error_msg)
            
            return response.json() if response.content else {}
            
        except requests.RequestException as e:
            self.logger.error(f"API call failed: {e}")
            raise
    
    def get_dataset_info(self, dataset_id: int) -> Dict[str, Any]:
        """
        Get dataset information including fields
        
        Args:
            dataset_id (int): Dataset ID
            
        Returns:
            Dict: Dataset information with fields
        """
        self.logger.info(f"Fetching dataset information for ID: {dataset_id}")
        return self._make_api_call('GET', f'datasets/{dataset_id}')
    
    def create_data_quality_rule(self, rule_config: Dict[str, Any]) -> Dict[str, Any]:
        """
        Create a new data quality rule
        
        Args:
            rule_config (Dict): Rule configuration
            
        Returns:
            Dict: Created rule information
        """
        endpoint = rule_config.get('api', {}).get('endpoint', 'data-quality-rules')
        method = rule_config.get('api', {}).get('method', 'POST')
        payload = self._build_payload(rule_config)
        
        self.logger.info(f"Creating data quality rule: {rule_config.get('rule_name')}")
        return self._make_api_call(method, endpoint, payload)
    
    def _build_payload(self, rule_config: Dict[str, Any]) -> Dict[str, Any]:
        """
        Build API payload from rule configuration
        
        Args:
            rule_config (Dict): Rule configuration
            
        Returns:
            Dict: API payload
        """
        payload_template = rule_config.get('payload', {})
        
        # Replace placeholders with actual values
        payload = self._replace_placeholders(payload_template, rule_config)
        
        # Add metadata
        payload.update({
            'rule_id': str(uuid.uuid4()),
            'created_at': datetime.utcnow().isoformat(),
            'framework_version': '1.0.0'
        })
        
        return payload
    
    def _replace_placeholders(self, template: Any, rule_config: Dict[str, Any]) -> Any:
        """
        Replace placeholders in template with actual values
        
        Args:
            template: Template with placeholders
            rule_config (Dict): Rule configuration
            
        Returns:
            Any: Template with replaced values
        """
        if isinstance(template, dict):
            return {key: self._replace_placeholders(value, rule_config) for key, value in template.items()}
        elif isinstance(template, list):
            return [self._replace_placeholders(item, rule_config) for item in template]
        elif isinstance(template, str) and template.startswith('${') and template.endswith('}'):
            # Replace placeholder like ${dataset_id} with actual value
            placeholder = template[2:-1]
            return rule_config.get('parameters', {}).get(placeholder, template)
        else:
            return template
    
    def apply_rules_from_config(self, rules_config_file: str) -> Dict[str, Any]:
        """
        Apply data quality rules from a configuration file
        
        Args:
            rules_config_file (str): Path to rules configuration file
            
        Returns:
            Dict: Summary of applied rules
        """
        self.logger.info(f"Applying rules from configuration: {rules_config_file}")
        
        # Load rules configuration
        with open(rules_config_file, 'r') as file:
            rules_config = yaml.safe_load(file)
        
        results = {
            'total_rules': 0,
            'successful_rules': 0,
            'failed_rules': 0,
            'rule_results': []
        }
        
        # Process each rule
        for rule in rules_config.get('rules', []):
            results['total_rules'] += 1
            
            try:
                result = self.create_data_quality_rule(rule)
                results['successful_rules'] += 1
                results['rule_results'].append({
                    'rule_name': rule.get('rule_name'),
                    'status': 'success',
                    'result': result
                })
                self.logger.info(f"Successfully applied rule: {rule.get('rule_name')}")
                
            except Exception as e:
                results['failed_rules'] += 1
                results['rule_results'].append({
                    'rule_name': rule.get('rule_name'),
                    'status': 'failed',
                    'error': str(e)
                })
                self.logger.error(f"Failed to apply rule {rule.get('rule_name')}: {e}")
        
        return results
    
    def validate_dataset(self, dataset_id: int, validation_config: Dict[str, Any]) -> Dict[str, Any]:
        """
        Validate a dataset against configured rules
        
        Args:
            dataset_id (int): Dataset ID to validate
            validation_config (Dict): Validation configuration
            
        Returns:
            Dict: Validation results
        """
        self.logger.info(f"Validating dataset ID: {dataset_id}")
        
        # Get dataset information
        dataset_info = self.get_dataset_info(dataset_id)
        
        validation_results = {
            'dataset_id': dataset_id,
            'dataset_name': dataset_info.get('dataset', {}).get('dataset_name'),
            'validation_timestamp': datetime.utcnow().isoformat(),
            'field_validations': [],
            'overall_status': 'PASS'
        }
        
        # Validate each field based on rules
        for field in dataset_info.get('dataset', {}).get('fields', []):
            field_validation = self._validate_field(field, validation_config)
            validation_results['field_validations'].append(field_validation)
            
            if field_validation['status'] == 'FAIL':
                validation_results['overall_status'] = 'FAIL'
        
        return validation_results
    
    def _validate_field(self, field: Dict[str, Any], validation_config: Dict[str, Any]) -> Dict[str, Any]:
        """
        Validate a single field against rules
        
        Args:
            field (Dict): Field information
            validation_config (Dict): Validation configuration
            
        Returns:
            Dict: Field validation result
        """
        field_name = field.get('field_name')
        field_type = field.get('data_type')
        
        validation_result = {
            'field_name': field_name,
            'field_type': field_type,
            'rules_applied': [],
            'status': 'PASS',
            'violations': []
        }
        
        # Apply validation rules based on field type and configuration
        for rule in validation_config.get('field_rules', []):
            if self._rule_applies_to_field(rule, field):
                rule_result = self._apply_validation_rule(rule, field)
                validation_result['rules_applied'].append(rule_result)
                
                if not rule_result['passed']:
                    validation_result['status'] = 'FAIL'
                    validation_result['violations'].append(rule_result['violation_message'])
        
        return validation_result
    
    def _rule_applies_to_field(self, rule: Dict[str, Any], field: Dict[str, Any]) -> bool:
        """
        Check if a rule applies to a specific field
        
        Args:
            rule (Dict): Validation rule
            field (Dict): Field information
            
        Returns:
            bool: True if rule applies to field
        """
        # Check field type constraints
        applicable_types = rule.get('applicable_types', [])
        if applicable_types and field.get('data_type') not in applicable_types:
            return False
        
        # Check field name patterns
        field_patterns = rule.get('field_patterns', [])
        if field_patterns:
            field_name = field.get('field_name', '')
            return any(pattern in field_name.lower() for pattern in field_patterns)
        
        return True
    
    def _apply_validation_rule(self, rule: Dict[str, Any], field: Dict[str, Any]) -> Dict[str, Any]:
        """
        Apply a validation rule to a field
        
        Args:
            rule (Dict): Validation rule
            field (Dict): Field information
            
        Returns:
            Dict: Rule application result
        """
        rule_type = rule.get('rule_type')
        rule_name = rule.get('rule_name')
        
        result = {
            'rule_name': rule_name,
            'rule_type': rule_type,
            'passed': True,
            'violation_message': None
        }
        
        # Apply specific rule logic
        if rule_type == 'not_null':
            if field.get('is_nullable', True):
                result['passed'] = False
                result['violation_message'] = f"Field {field.get('field_name')} allows NULL values but should be NOT NULL"
        
        elif rule_type == 'length_check':
            max_length = rule.get('parameters', {}).get('max_length')
            field_length = field.get('length')
            
            if max_length and field_length and field_length > max_length:
                result['passed'] = False
                result['violation_message'] = f"Field {field.get('field_name')} length {field_length} exceeds maximum {max_length}"
        
        elif rule_type == 'data_type_check':
            expected_type = rule.get('parameters', {}).get('expected_type')
            actual_type = field.get('data_type')
            
            if expected_type and actual_type != expected_type:
                result['passed'] = False
                result['violation_message'] = f"Field {field.get('field_name')} type {actual_type} does not match expected {expected_type}"
        
        return result
    
    def generate_quality_report(self, dataset_id: int, output_file: Optional[str] = None) -> Dict[str, Any]:
        """
        Generate a comprehensive data quality report
        
        Args:
            dataset_id (int): Dataset ID
            output_file (str): Optional output file path
            
        Returns:
            Dict: Quality report
        """
        self.logger.info(f"Generating quality report for dataset ID: {dataset_id}")
        
        # Load validation configuration
        validation_config = self.config.get('validation', {})
        
        # Perform validation
        validation_results = self.validate_dataset(dataset_id, validation_config)
        
        # Generate report
        report = {
            'report_id': str(uuid.uuid4()),
            'generated_at': datetime.utcnow().isoformat(),
            'dataset_info': validation_results,
            'summary': {
                'total_fields': len(validation_results['field_validations']),
                'passed_fields': len([f for f in validation_results['field_validations'] if f['status'] == 'PASS']),
                'failed_fields': len([f for f in validation_results['field_validations'] if f['status'] == 'FAIL']),
                'overall_score': 0
            }
        }
        
        # Calculate quality score
        if report['summary']['total_fields'] > 0:
            report['summary']['overall_score'] = (
                report['summary']['passed_fields'] / report['summary']['total_fields']
            ) * 100
        
        # Save report if output file specified
        if output_file:
            with open(output_file, 'w') as file:
                json.dump(report, file, indent=2)
            self.logger.info(f"Quality report saved to: {output_file}")
        
        return report
