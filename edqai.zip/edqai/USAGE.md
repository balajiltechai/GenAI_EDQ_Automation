# Dataset Registration and Fields Management API - Usage Examples

This document provides practical examples of how to use the Dataset Registration API and Web UI.

## 🖥️ Web UI Interface

### **Quick Start with UI:**

1. **Start the application**:
   ```bash
   python app.py
   ```

2. **Open the web interface**:
   - Navigate to: `http://localhost:5001`
   - You'll see the Dataset Registration dashboard

3. **Load sample data** (optional):
   ```bash
   python load_sample_data.py
   ```

### **Using the Web Interface:**

#### **Dashboard Overview:**
- View total datasets and fields statistics
- See all registered datasets with field counts
- Real-time data updates

#### **Adding a New Dataset:**
1. Click "Add New Dataset" button
2. Fill in:
   - **Dataset Name** (required): e.g., "Customer Database"
   - **Description** (optional): e.g., "Customer information and contact details"
3. Click "Create Dataset"

#### **Adding Fields to a Dataset:**
1. Click "Add Field" button next to any dataset
2. Configure field properties:
   - **Field Name** (required): e.g., "customer_id"
   - **Data Type** (required): INTEGER, VARCHAR, DATE, etc.
   - **Length**: For VARCHAR, INTEGER (e.g., 255)
   - **Precision/Scale**: For DECIMAL types
   - **Constraints**:
     - ☑️ Nullable (allows NULL values)
     - ☑️ Primary Key (unique identifier)
     - ☑️ Unique (unique constraint)
   - **Default Value**: Optional default value
   - **Description**: Field documentation
3. Click "Add Field"

#### **Viewing Field Details:**
1. Click "View Fields" next to any dataset
2. See detailed field schema with:
   - Field names and data types
   - Constraint badges (PK, UNIQUE, NOT NULL)
   - Descriptions and default values

## 🔧 API Usage Examples (Command Line)

### 1. Register a New Dataset

**Request:**
```bash
curl -X POST http://localhost:5000/api/datasets \
  -H "Content-Type: application/json" \
  -d '{
    "dataset_name": "Customer Database",
    "description": "Main customer information dataset"
  }'
```

**Response:**
```json
{
  "message": "Dataset created successfully",
  "dataset": {
    "id": 1,
    "unique_dataset_id": "f47ac10b-58cc-4372-a567-0e02b2c3d479",
    "dataset_name": "Customer Database",
    "description": "Main customer information dataset",
    "created_at": "2025-01-29T10:30:00.000000",
    "updated_at": "2025-01-29T10:30:00.000000",
    "fields_count": 0
  }
}
```

### 2. Add Fields to a Dataset

**Customer ID Field:**
```bash
curl -X POST http://localhost:5000/api/datasets/1/fields \
  -H "Content-Type: application/json" \
  -d '{
    "field_name": "customer_id",
    "data_type": "INTEGER",
    "length": 11,
    "is_nullable": false,
    "is_primary_key": true,
    "description": "Unique customer identifier"
  }'
```

**Customer Name Field:**
```bash
curl -X POST http://localhost:5000/api/datasets/1/fields \
  -H "Content-Type: application/json" \
  -d '{
    "field_name": "customer_name",
    "data_type": "VARCHAR",
    "length": 255,
    "is_nullable": false,
    "description": "Customer full name"
  }'
```

**Email Field:**
```bash
curl -X POST http://localhost:5000/api/datasets/1/fields \
  -H "Content-Type: application/json" \
  -d '{
    "field_name": "email",
    "data_type": "VARCHAR",
    "length": 255,
    "is_nullable": true,
    "is_unique": true,
    "description": "Customer email address"
  }'
```

**Registration Date Field:**
```bash
curl -X POST http://localhost:5000/api/datasets/1/fields \
  -H "Content-Type: application/json" \
  -d '{
    "field_name": "registration_date",
    "data_type": "DATE",
    "is_nullable": false,
    "description": "Customer registration date"
  }'
```

### 3. Retrieve Dataset Information

**Get All Datasets:**
```bash
curl http://localhost:5000/api/datasets
```

**Get Specific Dataset with Fields:**
```bash
curl http://localhost:5000/api/datasets/1
```

**Response:**
```json
{
  "dataset": {
    "id": 1,
    "unique_dataset_id": "f47ac10b-58cc-4372-a567-0e02b2c3d479",
    "dataset_name": "Customer Database",
    "description": "Main customer information dataset",
    "created_at": "2025-01-29T10:30:00.000000",
    "updated_at": "2025-01-29T10:30:00.000000",
    "fields_count": 4,
    "fields": [
      {
        "id": 1,
        "dataset_id": 1,
        "field_name": "customer_id",
        "data_type": "INTEGER",
        "length": 11,
        "is_nullable": false,
        "is_primary_key": true,
        "is_unique": false,
        "description": "Unique customer identifier",
        "created_at": "2025-01-29T10:31:00.000000",
        "updated_at": "2025-01-29T10:31:00.000000"
      },
      // ... other fields
    ]
  }
}
```

### 4. Update Dataset or Field Information

**Update Dataset:**
```bash
curl -X PUT http://localhost:5000/api/datasets/1 \
  -H "Content-Type: application/json" \
  -d '{
    "dataset_name": "Updated Customer Database",
    "description": "Updated description for customer dataset"
  }'
```

**Update Field:**
```bash
curl -X PUT http://localhost:5000/api/fields/1 \
  -H "Content-Type: application/json" \
  -d '{
    "length": 15,
    "description": "Updated customer identifier with increased length"
  }'
```

### 5. Data Type Examples

The system supports various data types with appropriate length specifications:

- **INTEGER**: `{"data_type": "INTEGER", "length": 11}`
- **VARCHAR**: `{"data_type": "VARCHAR", "length": 255}`
- **TEXT**: `{"data_type": "TEXT"}`
- **DATE**: `{"data_type": "DATE"}`
- **DATETIME**: `{"data_type": "DATETIME"}`
- **DECIMAL**: `{"data_type": "DECIMAL", "precision": 10, "scale": 2}`
- **BOOLEAN**: `{"data_type": "BOOLEAN"}`

### 6. Field Constraints

You can specify various constraints for fields:

- **Primary Key**: `"is_primary_key": true`
- **Unique**: `"is_unique": true`
- **Not Null**: `"is_nullable": false`
- **Default Value**: `"default_value": "0"`

## Testing the API

Run the included test script to verify functionality:

```bash
python test_demo.py
```

Run unit tests:

```bash
pytest tests/
```

## Health Check

Verify the API is running:

```bash
curl http://localhost:5000/api/health
```

Response:
```json
{
  "status": "healthy",
  "message": "Dataset Registration API is running"
}
```
