#!/usr/bin/env python3
"""
Check current EDQ rules
"""

import requests
import json

API_BASE_URL = 'http://localhost:5001/api'

def check_rules():
    """Check current rules"""
    response = requests.get(f"{API_BASE_URL}/data-quality-rules")
    if response.ok:
        data = response.json()
        print("Current EDQ Rules:")
        print("=" * 80)
        for rule in data['rules']:
            print(f"Rule ID: {rule['id']}")
            print(f"  Description: {rule.get('rule_description', 'No description')}")
            print(f"  Type: {rule['rule_type']}")
            print(f"  Field: {rule['field_name']}")
            print(f"  Dataset ID: {rule['dataset_id']}")
            print(f"  Active: {rule['is_active']}")
            print(f"  Severity: {rule['severity']}")
            print("-" * 80)
        
        print(f"\nTotal rules: {len(data['rules'])}")
    else:
        print(f"Failed to get rules: {response.status_code}")

if __name__ == "__main__":
    check_rules()
